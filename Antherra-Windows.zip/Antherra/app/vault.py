"""Everything private, encrypted at rest.

AES-256-CBC then HMAC-SHA256 (encrypt-then-MAC), using the system's own cryptography. A random master key is wrapped twice:
by the passphrase (scrypt) and by a recovery code (160 random bits). Case records live in memory while unlocked and each is
written to disk as its own sealed record; evidence files are sealed one by one under names that reveal nothing."""
import base64, ctypes, ctypes.util, hashlib, hmac, json, os, re, secrets, sqlite3, sys, threading, time

BINARY = getattr(os, "O_BINARY", 0)  # without it Windows would rewrite line endings inside evidence
MIN = 12


class Locked(Exception):
    pass


class BadSecret(ValueError):
    pass


class Damaged(ValueError):
    pass


# ---------------------------------------------------------------- AES-256-CBC from the operating system

if sys.platform == "darwin":
    _lib = ctypes.CDLL("/usr/lib/libSystem.B.dylib")
    _lib.CCCrypt.argtypes = [ctypes.c_uint32] * 3 + [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]

    def _aes(enc, key, iv, data):
        out, n = ctypes.create_string_buffer(len(data) + 16), ctypes.c_size_t()
        if _lib.CCCrypt(0 if enc else 1, 0, 1, key, 32, iv, data, len(data), out, len(out), ctypes.byref(n)):  # AES, PKCS7
            raise Damaged("could not decrypt")
        return ctypes.string_at(out, n.value)
elif os.name == "nt":
    _b = ctypes.WinDLL("bcrypt")
    _V, _U = ctypes.c_void_p, ctypes.c_ulong
    _b.BCryptOpenAlgorithmProvider.argtypes = [ctypes.POINTER(_V), ctypes.c_wchar_p, ctypes.c_wchar_p, _U]
    _b.BCryptSetProperty.argtypes = [_V, ctypes.c_wchar_p, ctypes.c_wchar_p, _U, _U]
    _b.BCryptGenerateSymmetricKey.argtypes = [_V, ctypes.POINTER(_V), _V, _U, ctypes.c_char_p, _U, _U]
    _b.BCryptDestroyKey.argtypes = [_V]
    for _f in (_b.BCryptEncrypt, _b.BCryptDecrypt):
        _f.argtypes = [_V, ctypes.c_char_p, _U, _V, _V, _U, _V, _U, ctypes.POINTER(_U), _U]
    _alg = _V()
    if _b.BCryptOpenAlgorithmProvider(ctypes.byref(_alg), "AES", None, 0):
        raise RuntimeError("Windows could not provide AES")
    if _b.BCryptSetProperty(_alg, "ChainingMode", "ChainingModeCBC", 32, 0):
        raise RuntimeError("Windows could not provide AES-CBC")

    def _aes(enc, key, iv, data):
        k, n = _V(), _U()
        if _b.BCryptGenerateSymmetricKey(_alg, ctypes.byref(k), None, 0, key, 32, 0):
            raise Damaged("could not prepare the key")
        try:
            ivb, out = ctypes.create_string_buffer(iv, 16), ctypes.create_string_buffer(len(data) + 16)
            if (_b.BCryptEncrypt if enc else _b.BCryptDecrypt)(k, data, len(data), None, ivb, 16, out, len(out), ctypes.byref(n), 1):  # 1: PKCS7
                raise Damaged("could not decrypt")
            return ctypes.string_at(out, n.value)
        finally:
            _b.BCryptDestroyKey(k)
else:
    _n = ctypes.util.find_library("crypto")
    if not _n:
        raise RuntimeError("Antherra needs OpenSSL's libcrypto to encrypt your cases. Install it and start again.")
    _c = ctypes.CDLL(_n)
    _c.EVP_CIPHER_CTX_new.restype = _c.EVP_aes_256_cbc.restype = ctypes.c_void_p
    _c.EVP_CIPHER_CTX_free.argtypes = [ctypes.c_void_p]
    _c.EVP_CipherInit_ex.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
    _c.EVP_CipherUpdate.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.c_char_p, ctypes.c_int]
    _c.EVP_CipherFinal_ex.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)]

    def _aes(enc, key, iv, data):
        x = _c.EVP_CIPHER_CTX_new()
        try:
            out, n, f = ctypes.create_string_buffer(len(data) + 32), ctypes.c_int(), ctypes.c_int()
            if not (_c.EVP_CipherInit_ex(x, _c.EVP_aes_256_cbc(), None, key, iv, int(enc)) and _c.EVP_CipherUpdate(x, out, ctypes.byref(n), data, len(data))
                    and _c.EVP_CipherFinal_ex(x, ctypes.byref(out, n.value), ctypes.byref(f))):
                raise Damaged("could not decrypt")
            return ctypes.string_at(out, n.value + f.value)
        finally:
            _c.EVP_CIPHER_CTX_free(x)


def sub(master, label):
    return hmac.new(master, b"antherra-vault-v1:" + label.encode(), hashlib.sha256).digest()


def seal(master, label, aad, data):
    """label picks the key; aad ties the result to its place, so sealed pieces cannot be swapped around."""
    ke, km, iv = sub(master, label + ":enc"), sub(master, label + ":mac"), os.urandom(16)
    ct = _aes(True, ke, iv, bytes(data))
    return iv + ct + _tag(km, aad, iv, ct)


def unseal(master, label, aad, blob):
    if len(blob) < 64:
        raise Damaged("a sealed record is cut short")
    iv, ct, tag = blob[:16], blob[16:-32], blob[-32:]
    if not hmac.compare_digest(tag, _tag(sub(master, label + ":mac"), aad, iv, ct)):
        raise Damaged("a sealed record was changed or damaged")
    return _aes(False, sub(master, label + ":enc"), iv, ct)


def _tag(km, aad, iv, ct):
    m = hmac.new(km, len(aad).to_bytes(8, "big") + aad + iv, hashlib.sha256)
    m.update(ct)
    return m.digest()


# ---------------------------------------------------------------- passphrases

COMMON = re.compile(r"^(.)\1+$|^(?:password|passphrase|antherra|thestudentstatesman|studentstatesman|qwerty\w*|letmein|welcome|abc|123)[\W\d_]*$|^(?:0?1234567890?|abcdefghijkl\w*)+$", re.I)


def weak(p):
    if not isinstance(p, str) or len(p) < MIN:
        return "Use at least %d characters. Four or five random words work well." % MIN
    if len(p) > 1000:
        return "That is too long."
    if len(set(p.lower())) < 6 or COMMON.match(re.sub(r"\s+", "", p)) or (p.isdigit() and len(p) < 20):
        return "That is too easy to guess. Four or five random words work well."
    return None


def kdf_new():
    if hasattr(hashlib, "scrypt"):
        return {"name": "scrypt", "n": 1 << 17, "r": 8, "p": 1, "salt": secrets.token_hex(16)}
    return {"name": "pbkdf2-sha512", "rounds": 1000000, "salt": secrets.token_hex(16)}


def kdf(p, k):
    import unicodedata
    pw, salt = unicodedata.normalize("NFKC", p).encode(), bytes.fromhex(k["salt"])
    if k["name"] == "scrypt":
        if not hasattr(hashlib, "scrypt"):
            raise ValueError("this was protected by a newer Python. Use the Antherra app, or a newer Python.")
        n, r, pp = int(k["n"]), int(k["r"]), int(k["p"])
        if not (1 << 14 <= n <= 1 << 20 and r == 8 and 1 <= pp <= 4):  # a planted file must not exhaust memory or weaken the work
            raise Damaged("the protection settings are not valid")
        return hashlib.scrypt(pw, salt=salt, n=n, r=r, p=pp, maxmem=256 * n * r, dklen=32)
    if k["name"] == "pbkdf2-sha512" and 600000 <= int(k["rounds"]) <= 10000000:
        return hashlib.pbkdf2_hmac("sha512", pw, salt, int(k["rounds"]), 32)
    raise Damaged("the protection settings are not valid")


def new_code():
    s = base64.b32encode(secrets.token_bytes(20)).decode()
    return "-".join(s[i:i + 4] for i in range(0, 32, 4))


def _code_key(code, salt):
    c = re.sub(r"[^A-Z2-7]", "", (code or "").upper().replace("0", "O").replace("1", "I").replace("8", "B"))
    return hashlib.pbkdf2_hmac("sha256", c.encode(), bytes.fromhex(salt), 200000, 32) if len(c) == 32 else None


# ---------------------------------------------------------------- protected case archives

MAGIC = b"ANTHERRA-SEALED-1\n"


def seal_archive(data, passphrase):
    k = kdf_new()
    head = json.dumps(k, sort_keys=True).encode()
    return MAGIC + head + b"\n" + seal(kdf(passphrase, k), "archive", head, data)


def open_archive(data, passphrase):
    head, _, body = data[len(MAGIC):].partition(b"\n")
    try:
        k = json.loads(head)
        key = kdf(passphrase, k)
    except (KeyError, TypeError, ValueError) as e:
        raise Damaged(str(e) if isinstance(e, Damaged) else "that archive is damaged")
    try:
        return unseal(key, "archive", head, body)
    except Damaged:
        raise BadSecret("That passphrase does not open this archive.")


# ---------------------------------------------------------------- files

def write(path, data):
    tmp = path + ".tmp"
    with os.fdopen(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | BINARY, 0o600), "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def wipe(path):
    """Overwrite then delete. On an SSD, or where snapshots exist, older copies can survive outside our reach."""
    try:
        n = os.path.getsize(path)
        with open(path, "r+b") as f:
            while n > 0:
                f.write(os.urandom(min(n, 1 << 20)))
                n -= 1 << 20
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass
    try:
        os.remove(path)
    except OSError:
        pass


class Vault:
    def __init__(self, home, schema):
        self.home, self.schema = home, schema
        self.lock, self.master, self.mem, self.disk, self._settings, self._lockf, self.after, self.depth = threading.RLock(), None, None, None, {}, None, [], 0

    def p(self, *a):
        return os.path.join(self.home, *a)

    @property
    def exists(self):
        return os.path.exists(self.p("vault.json")) or self._spare() is not None

    def _spare(self):
        """A second copy of vault.json, kept inside vault.db in case the first is lost."""
        if not os.path.exists(self.p("vault.db")):
            return None
        try:
            c = sqlite3.connect(self.p("vault.db"), timeout=30)
            try:
                return json.loads(c.execute("SELECT v FROM head").fetchone()[0])
            finally:
                c.close()
        except (sqlite3.Error, TypeError, ValueError):
            return None

    @property
    def legacy(self):
        return any(os.path.exists(self.p(n)) for n in ("antherra.db", "settings.json"))

    @property
    def unlocked(self):
        return self.master is not None

    # ---- keys

    def _head(self):
        try:
            if not os.path.exists(self.p("vault.json")) and self._spare():
                write(self.p("vault.json"), json.dumps(self._spare(), indent=1).encode())
            with open(self.p("vault.json"), encoding="utf-8") as f:
                h = json.load(f)
            return h if h.get("v") == 1 else 1 / 0
        except ZeroDivisionError:
            raise Damaged("this storage was made by a newer Antherra")
        except (OSError, ValueError, AttributeError):
            raise Damaged("the file vault.json is missing or damaged. Restore it from a backup.")

    @staticmethod
    def _wrap(kek, what, master):
        return seal(kek, "wrap", what.encode(), master).hex()

    def _save_head(self, h):
        b = json.dumps(h, indent=1).encode()
        write(self.p("vault.json"), b)
        self.disk.execute("CREATE TABLE IF NOT EXISTS head(one INTEGER PRIMARY KEY, v TEXT)")
        self.disk.execute("INSERT OR REPLACE INTO head VALUES(1,?)", (b.decode(),))
        self.disk.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        if os.path.isdir(self.p("backups")):  # an old passphrase must not open old copies either
            for n in os.listdir(self.p("backups")):
                if re.match(r"^vault-before-.*\.json$", n):
                    write(self.p("backups", n), b)
                elif re.match(r"^vault-before-.*\.db$", n):
                    c = sqlite3.connect(self.p("backups", n), timeout=30)
                    try:
                        c.execute("PRAGMA secure_delete=ON")
                        c.execute("CREATE TABLE IF NOT EXISTS head(one INTEGER PRIMARY KEY, v TEXT)")
                        c.execute("INSERT OR REPLACE INTO head VALUES(1,?)", (b.decode(),))
                        c.commit()
                    except sqlite3.Error:
                        pass
                    finally:
                        c.close()

    def _header(self, master, passphrase, code):
        k, s = kdf_new(), secrets.token_hex(16)
        return {"v": 1, "kdf": k, "wrap": self._wrap(kdf(passphrase, k), "passphrase", master), "rsalt": s, "rwrap": self._wrap(_code_key(code, s), "recovery", master)}

    def _single(self):
        """Two copies open at once would overwrite each other's changes."""
        f = open(self.p("vault.lock"), "a+")
        try:
            if os.name == "nt":
                import msvcrt
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            f.close()
            raise ValueError("Antherra is already unlocked in another window or copy. Close or lock that one first.")
        self._lockf = f

    def create(self, passphrase):
        with self.lock:
            if self.exists or self.unlocked:
                raise ValueError("a passphrase is already set")
            w = weak(passphrase)
            if w:
                raise ValueError(w)
            self._single()
            try:
                code, master = new_code(), secrets.token_bytes(32)
                head = self._header(master, passphrase, code)
                t = time.strftime("%Y%m%d-%H%M%S")
                for n in ("vault.db", "vault.db-wal", "vault.db-shm"):  # left by a setup that never finished. Set aside, never deleted
                    if os.path.exists(self.p(n)):
                        os.replace(self.p(n), self.p(n.replace("vault", "unfinished-" + t)))
                self._open(master, fresh=True)
                done = self.migrate(wiping=False)
                self._save_head(head)  # only now does the vault exist: an interrupted setup starts again from the untouched originals
                self.clean_legacy(done)
                return code
            except BaseException:
                self.close()
                raise

    def secret(self, passphrase=None, code=None):
        h = self._head()
        try:
            if code is not None:
                kek = _code_key(code, h["rsalt"])
                if kek is None:
                    raise BadSecret("A recovery code has 32 letters and digits.")
                return unseal(kek, "wrap", b"recovery", bytes.fromhex(h["rwrap"]))
            return unseal(kdf(passphrase or "", h["kdf"]), "wrap", b"passphrase", bytes.fromhex(h["wrap"]))
        except KeyError:
            raise Damaged("the file vault.json is damaged. Restore it from a backup.")
        except BadSecret:
            raise
        except Damaged:
            raise BadSecret("That recovery code is not right." if code is not None else "That passphrase is not right.")

    def unlock(self, passphrase=None, code=None):
        master = self.secret(passphrase, code)
        with self.lock:
            if self.unlocked:
                return  # another tab of this same copy
            self._single()
            try:
                self._open(master)
                if self.legacy:  # an older Antherra was run here since
                    self.clean_legacy(self.migrate(wiping=False))
            except BaseException:
                self.close()
                raise

    def rekey(self, new, passphrase=None, code=None):
        """New passphrase and new recovery code. The records themselves need no rewriting."""
        w = weak(new)
        if w:
            raise ValueError(w)
        with self.lock:
            c = new_code()
            self._save_head(self._header(self.secret(passphrase, code), new, c))
            return c

    def close(self):
        with self.lock:
            for c in (self.mem, self.disk):
                if c is not None:
                    try:
                        c.close()
                    except sqlite3.Error:
                        pass
            self.mem = self.disk = self.master = None
            self._settings = {}
            if self._lockf:
                self._lockf.close()
                self._lockf = None

    # ---- records

    def _open(self, master, fresh=False):
        try:
            self._load(master, fresh)
        except (sqlite3.Error, TypeError, KeyError, UnicodeDecodeError, json.JSONDecodeError):
            raise Damaged("the file vault.db is damaged. Restore it from a backup.")

    def _load(self, master, fresh):
        os.makedirs(self.p("blobs"), mode=0o700, exist_ok=True)
        if not fresh and not os.path.exists(self.p("vault.db")):
            raise Damaged("the file vault.db is missing. Restore it from a backup.")
        self.master = master
        self.disk = sqlite3.connect(self.p("vault.db"), timeout=30, check_same_thread=False, isolation_level=None)
        os.chmod(self.p("vault.db"), 0o600)
        self.disk.execute("PRAGMA journal_mode=WAL")
        self.disk.execute("PRAGMA synchronous=FULL")
        self.disk.execute("PRAGMA secure_delete=ON")
        self.disk.execute("CREATE TABLE IF NOT EXISTS r(k BLOB PRIMARY KEY, v BLOB) WITHOUT ROWID")
        mem = self.mem = sqlite3.connect(":memory:", check_same_thread=False)
        mem.row_factory = sqlite3.Row
        mem.execute("PRAGMA temp_store=MEMORY")
        mem.executescript(self.schema)
        self.kname, self.kacc = sub(master, "name"), sub(master, "acc")
        self.mk = self._k("manifest", "")
        count, acc, want = 0, 0, None
        for k, v in self.disk.execute("SELECT k,v FROM r"):
            k = bytes(k)
            x = json.loads(unseal(master, "row", k, bytes(v)))
            if k == self.mk:
                want = x["n"], x["acc"]
                continue
            count, acc = count + 1, (acc + self._h(k, bytes(v))) % (1 << 256)
            if x["t"] == "settings":
                self._settings = x["row"]
            else:
                mem.execute("INSERT INTO %s VALUES(%s)" % (x["t"], ",".join("?" * len(x["row"]))), x["row"])
        if (count, "%064x" % acc) != (want or (0, "%064x" % 0)) or (want is None and not fresh):
            raise Damaged("some records were removed or replaced outside Antherra. Restore vault.db from a backup.")
        self.n, self.acc = count, acc
        mem.execute("CREATE TEMP TABLE dirty(t TEXT, id, PRIMARY KEY(t,id))")
        for t, i in (("docs", "id"), ("log", "n")):
            for ev, ref in (("INSERT", "NEW"), ("UPDATE", "NEW"), ("DELETE", "OLD")):
                mem.execute("CREATE TEMP TRIGGER d_%s_%s AFTER %s ON %s BEGIN INSERT OR REPLACE INTO dirty VALUES('%s',%s.%s); END" % (t, ev, ev, t, t, ref, i))
        mem.commit()

    def _k(self, t, i):
        return hmac.new(self.kname, ("%s:%s" % (t, i)).encode(), hashlib.sha256).digest()[:20]

    def _h(self, k, v):
        return int.from_bytes(hmac.new(self.kacc, k + v[-32:], hashlib.sha256).digest(), "big")

    def _put(self, k, obj):
        j = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode()
        j += b" " * (-len(j) % 256)  # sizes give away a little less
        return seal(self.master, "row", k, j)

    def _flush(self, rows):
        """rows: (key, object or None). One disk transaction, so a crash leaves either all of it or none."""
        n, acc, d = self.n, self.acc, self.disk
        d.execute("BEGIN IMMEDIATE")
        try:
            for k, obj in rows:
                old = d.execute("SELECT v FROM r WHERE k=?", (k,)).fetchone()
                if old:
                    n, acc = n - 1, acc - self._h(k, bytes(old[0]))
                if obj is None:
                    d.execute("DELETE FROM r WHERE k=?", (k,))
                else:
                    v = self._put(k, obj)
                    d.execute("INSERT OR REPLACE INTO r VALUES(?,?)", (k, v))
                    n, acc = n + 1, acc + self._h(k, v)
            acc %= 1 << 256
            d.execute("INSERT OR REPLACE INTO r VALUES(?,?)", (self.mk, self._put(self.mk, {"n": n, "acc": "%064x" % acc})))
            d.execute("COMMIT")
        except BaseException:
            d.execute("ROLLBACK")
            raise
        self.n, self.acc = n, acc

    def __enter__(self):
        self.lock.acquire()
        if self.mem is None:
            self.lock.release()
            raise Locked()
        self.depth += 1
        return self.mem

    def __exit__(self, t, e, tb):
        try:
            self.depth -= 1
            if self.depth or self.mem is None:
                return False
            if t:
                self.mem.rollback()
                self.after.clear()
                return False
            try:
                rows = []
                for tab, i in self.mem.execute("SELECT t,id FROM dirty").fetchall():
                    r = self.mem.execute("SELECT * FROM %s WHERE %s=?" % (tab, "id" if tab == "docs" else "n"), (i,)).fetchone()
                    rows.append((self._k(tab, i), None if r is None else {"t": tab, "row": list(r)}))
                if rows:
                    self._flush(rows)
                self.mem.execute("DELETE FROM dirty")
                self.mem.commit()
            except BaseException:
                self.mem.rollback()
                self.after.clear()
                raise
            todo, self.after[:] = list(self.after), []
            for f in todo:
                f()
            return False
        finally:
            self.lock.release()

    def settings(self):
        with self.lock:
            if not self.unlocked:
                raise Locked()
            return json.loads(json.dumps(self._settings))

    def save_settings(self, s):
        with self.lock:
            if not self.unlocked:
                raise Locked()
            s = json.loads(json.dumps(s))
            self._flush([(self._k("settings", ""), {"t": "settings", "row": s})])
            self._settings = s

    # ---- evidence files

    def _blob(self, sha):
        return self.p("blobs", hmac.new(sub(self._need(), "blobname"), sha.encode(), hashlib.sha256).hexdigest())

    def _need(self):
        m = self.master
        if m is None:
            raise Locked()
        return m

    def blob_put(self, data):
        sha = hashlib.sha256(data).hexdigest()
        m, path = self._need(), self._blob(sha)
        if not os.path.exists(path):
            write(path, seal(m, "blob", sha.encode(), data))
        return sha

    def blob_get(self, sha):
        if not re.match(r"^[0-9a-f]{64}\Z", sha or ""):
            return None
        m = self._need()
        try:
            with open(self._blob(sha), "rb") as f:
                return unseal(m, "blob", sha.encode(), f.read())
        except (OSError, Damaged):
            return None

    def blob_del(self, sha):
        try:
            os.remove(self._blob(sha))  # already unreadable without the key
        except OSError:
            pass

    # ---- from the unencrypted storage of 1.4 and earlier

    def migrate(self, wiping=True):
        """Copies everything in, then reads it all back and compares, before anything is removed. Returns what may be removed."""
        gone, db = [], self.p("antherra.db")
        blobs = [n for n in os.listdir(self.p("blobs")) if re.match(r"^[0-9a-f]{64}$", n)] if os.path.isdir(self.p("blobs")) else []
        for n in blobs:
            with open(self.p("blobs", n), "rb") as f:
                b = f.read()
            if hashlib.sha256(b).hexdigest() == n:  # sealed files have names that never match their contents
                self.blob_put(b)
                if self.blob_get(n) != b:
                    raise Damaged("an evidence file did not survive encryption, so nothing was changed")
                gone.append(self.p("blobs", n))
        if os.path.exists(db):
            con = sqlite3.connect(db, timeout=30)
            try:
                have = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                docs = con.execute("SELECT id,case_id,kind,data,created,updated,deleted FROM docs").fetchall() if "docs" in have else []
                log = con.execute("SELECT case_id,ts,action,kind,doc,detail,prev,hash FROM log ORDER BY n").fetchall() if "log" in have else []
                lists = con.execute("SELECT * FROM sanctions").fetchall() if "sanctions" in have else []
            finally:
                con.close()
            with self as mem:
                known = {r[0] for r in mem.execute("SELECT DISTINCT case_id FROM docs")}
                docs, log = [d for d in docs if d[1] not in known], [x for x in log if x[0] not in known]
                mem.executemany("INSERT INTO docs VALUES(?,?,?,?,?,?,?)", docs)
                mem.executemany("INSERT INTO log(case_id,ts,action,kind,doc,detail,prev,hash) VALUES(?,?,?,?,?,?,?,?)", log)
            # read back from the disk, not from memory
            got = {}
            for k, v in self.disk.execute("SELECT k,v FROM r"):
                got[bytes(k)] = json.loads(unseal(self.master, "row", bytes(k), bytes(v)))
            for d in docs:
                if (got.get(self._k("docs", d[0])) or {}).get("row") != list(d):
                    raise Damaged("a case record did not survive encryption, so nothing was changed")
            if len([1 for x in got.values() if x.get("t") == "log"]) < len(log):
                raise Damaged("the log did not survive encryption, so nothing was changed")
            if lists:
                c = sqlite3.connect(self.p("lists.db"))  # the public sanctions lists: nothing private
                try:
                    c.execute("CREATE TABLE IF NOT EXISTS sanctions(list TEXT, uid TEXT, name TEXT, norm TEXT, type TEXT, program TEXT, detail TEXT, url TEXT)")
                    if not c.execute("SELECT count(*) FROM sanctions").fetchone()[0]:
                        c.executemany("INSERT INTO sanctions VALUES(?,?,?,?,?,?,?,?)", lists)
                    c.commit()
                finally:
                    c.close()
            gone += [db, db + "-wal", db + "-shm"]
        if os.path.exists(self.p("settings.json")):
            try:
                with open(self.p("settings.json"), encoding="utf-8") as f:
                    s = json.load(f)
            except ValueError:
                s = {}
            cur = self.settings()
            self.save_settings({**s, **cur, "keys": {**(s.get("keys") or {}), **(cur.get("keys") or {})}})
            gone += [self.p("settings.json"), self.p("settings.json.tmp")]
        if os.path.isdir(self.p("backups")):
            for n in os.listdir(self.p("backups")):
                if n.startswith("antherra-before-") and n.endswith(".db"):
                    with open(self.p("backups", n), "rb") as f:
                        b = f.read()
                    write(self.p("backups", n + ".sealed"), seal(self.master, "backup", n.encode(), b))
                    gone.append(self.p("backups", n))
        return gone

    def clean_legacy(self, gone):
        for f in gone:
            if os.path.exists(f):
                wipe(f)


if __name__ == "__main__":  # python3 vault.py open-backup FILE.sealed OUT: opens an old backup that was encrypted when the passphrase was set
    import getpass
    if len(sys.argv) != 4 or sys.argv[1] != "open-backup":
        sys.exit("usage: vault.py open-backup FILE.sealed OUT")
    src = os.path.abspath(sys.argv[2])
    v = Vault(os.path.dirname(os.path.dirname(src)), "")
    with open(src, "rb") as f:
        write(os.path.abspath(sys.argv[3]), unseal(v.secret(getpass.getpass("Passphrase: ")), "backup", os.path.basename(src)[:-7].encode(), f.read()))
