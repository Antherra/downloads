#!/usr/bin/env python3
"""Antherra launcher. Picks the newest update that passes its checks, or the version this copy came with.
Kept small: this file and the update.py beside it are never replaced by an update."""
import importlib.util, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SHELL = 2
RESTART = 75
sys.dont_write_bytecode = True


def trusted():
    spec = importlib.util.spec_from_file_location("_boot_update", os.path.join(HERE, "update.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def run(app):
    # forget modules from any version already tried, so old and new code never mix
    for n, m in list(sys.modules.items()):
        f = os.path.abspath(getattr(m, "__file__", None) or os.sep)
        if n not in ("__main__", "_boot_update") and (os.path.dirname(f) == HERE or f.startswith(os.path.abspath(U.udir()) + os.sep)):
            del sys.modules[n]
    sys.path[:] = [app] + [p for p in sys.path if os.path.abspath(p or ".") not in (HERE, app)]
    os.environ["ANTHERRA_SHELL"] = str(SHELL)
    spec = importlib.util.spec_from_file_location("antherra_core", os.path.join(app, "core.py"))
    m = sys.modules["antherra_core"] = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m.main()


if __name__ == "__main__":
    os.umask(0o077)  # nothing Antherra writes is readable by other accounts
    os.environ.pop("SSLKEYLOGFILE", None)  # would write out the keys of every encrypted connection
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))  # a crash must not leave memory on disk
    except (ImportError, ValueError, OSError):
        pass
    U = trusted()
    try:
        ver, app = U.choose(SHELL)
    except Exception as e:  # an update must never be able to stop the app starting
        sys.stderr.write("update check skipped: %r\n" % e)
        ver, app = None, None
    code = None
    if ver:
        try:
            st = U._state()
            U.set_state(trying=ver, fails=(st.get("fails", 0) + 1) if st.get("trying") == ver else 1)
            if st.get("opened") != ver:
                U.backup_db(ver)
                U.set_state(opened=ver)
            code = run(app)
        except SystemExit:
            raise
        except BaseException as e:
            if isinstance(e, KeyboardInterrupt):
                raise
            sys.stderr.write("version %s failed, using %s: %r\n" % (ver, U.VERSION, e))
            U.mark_bad(ver, repr(e))
            ver = None
    if not ver:
        code = run(HERE)
    if isinstance(code, tuple) and code[0] == RESTART:
        args = [sys.executable, "-I", "-B", os.path.abspath(__file__), "--port", str(code[1])] + [a for a in sys.argv[1:] if a == "--watch-stdin"]
        if os.name == "nt":
            sys.exit(subprocess.call(args))
        os.execv(sys.executable, args)
