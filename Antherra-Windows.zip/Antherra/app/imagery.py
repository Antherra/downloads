"""Dated satellite imagery without keys: Sentinel-2, Sentinel-1, Landsat, Esri Wayback, NASA daily layers and heat detections."""
import calendar, csv, io, json, math, os, re, shutil, tempfile, threading, time, urllib.error, urllib.parse, urllib.request
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

import connectors as C

PC = "https://planetarycomputer.microsoft.com/api"
WB = "https://wayback.maptiles.arcgis.com/arcgis/rest/services/World_Imagery"
GIBS = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best"
_rgb = "Gamma RGB 3.7 Saturation 1.5 Sigmoidal RGB 15 0.35"
_lrgb = "gamma RGB 2.7, saturation 1.5, sigmoidal RGB 15 0.55"
_idx = lambda e: [("expression", e), ("asset_as_band", "true"), ("rescale", "-1,1"), ("colormap_name", "rdylgn"), ("nodata", "0")]
_bands = lambda *b, f=_rgb: [("assets", x) for x in b] + [("nodata", "0"), ("color_formula", f)]
MODES = {
    "sentinel-2-l2a": {"true": [("assets", "visual")], "infrared": _bands("B08", "B04", "B03"), "shortwave": _bands("B12", "B8A", "B04"),
                       "vegetation": _idx("(B08-B04)/(B08+B04)"), "burn": _idx("(B08-B12)/(B08+B12)")},
    "landsat-c2-l2": {"true": _bands("red", "green", "blue", f=_lrgb), "infrared": _bands("nir08", "red", "green", f=_lrgb), "shortwave": _bands("swir22", "nir08", "red", f=_lrgb)},
    "sentinel-1-rtc": {"radar": [("assets", "vv"), ("rescale", "0,0.5")]},
}
GIBS_LAYERS = {  # name: (tile set, deepest zoom, extension)
    "VIIRS_NOAA21_CorrectedReflectance_TrueColor": (9, "jpg"), "VIIRS_NOAA20_CorrectedReflectance_TrueColor": (9, "jpg"),
    "MODIS_Terra_CorrectedReflectance_TrueColor": (9, "jpg"), "MODIS_Aqua_CorrectedReflectance_TrueColor": (9, "jpg"),
    "VIIRS_NOAA21_DayNightBand": (7, "png"), "VIIRS_NOAA20_DayNightBand": (7, "png"),
}
_DAY = r"^\d{4}-\d\d-\d\d$"

# ---------------------------------------------------------------- tiles, with a small memory cache

_cache, _lock, _size = OrderedDict(), threading.Lock(), [0]


def forget():
    with _lock:
        _cache.clear()
        _size[0] = 0


def fetch(url, timeout=20):
    with _lock:
        if url in _cache:
            _cache.move_to_end(url)
            return _cache[url]
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": C.UA}), timeout=timeout) as r:
            if r.status != 200:  # 204: nothing here
                return None
            t, b = r.headers.get_content_type(), r.read(8 << 20)
    except (urllib.error.URLError, OSError):
        return None
    if not t.startswith("image/"):
        return None
    with _lock:
        _cache[url] = (t, b)
        _size[0] += len(b)
        while _size[0] > 120 << 20:
            _size[0] -= len(_cache.popitem(last=False)[1][1])
    return t, b


def tile(p):
    """p is the path after /tile/. Everything in it is checked before it goes into an address."""
    try:
        z, x, y = int(p[-3]), int(p[-2]), int(p[-1].split(".")[0])
    except (ValueError, IndexError):
        return None
    if not (0 <= z <= 22 and 0 <= x < 2 ** z and 0 <= y < 2 ** z):
        return None
    if p[0] == "pc" and len(p) == 7:
        col, item, mode = p[1:4]
        m = MODES.get(col, {}).get(mode)
        if not m or not re.match(r"^[\w.-]{8,120}$", item):
            return None
        q = [("collection", col), ("item", item)] + m
        return fetch("%s/data/v1/item/tiles/WebMercatorQuad/%d/%d/%d@2x?%s" % (PC, z, x, y, urllib.parse.urlencode(q)))
    if p[0] == "wb" and len(p) == 5 and p[1].isdigit():
        return fetch("%s/MapServer/tile/%s/%d/%d/%d" % (WB, p[1], z, y, x))
    if p[0] == "gibs" and len(p) == 6 and p[1] in GIBS_LAYERS and re.match(_DAY, p[2]):
        lv, ext = GIBS_LAYERS[p[1]]
        return fetch("%s/%s/default/%s/GoogleMapsCompatible_Level%d/%d/%d/%d.%s" % (GIBS, p[1], p[2], lv, z, y, x, ext)) if z <= lv else None
    return None


# ---------------------------------------------------------------- scene search

def search(q):
    col, lat, lon = q["source"], float(q["lat"]), float(q["lon"])
    if col not in MODES or not (re.match(_DAY, q["from"]) and re.match(_DAY, q["to"])):
        raise ValueError("choose a source and two dates")
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise ValueError("those coordinates are not on Earth")
    if q["from"] > q["to"]:
        raise ValueError("the first date is after the second")
    body = {"collections": [col], "intersects": {"type": "Point", "coordinates": [lon, lat]}, "datetime": "%sT00:00:00Z/%sT23:59:59Z" % (q["from"], q["to"]), "limit": 100,
            "sortby": [{"field": "properties.datetime", "direction": "desc"}]}
    if col != "sentinel-1-rtc":
        body["query"] = {"eo:cloud_cover": {"lte": float(q.get("cloud") or 100)}}
    if col == "landsat-c2-l2":
        body["query"]["landsat:collection_category"] = {"in": ["T1", "T2"]}
    d = C.Ctx({}).json(PC + "/stac/v1/search", headers={"Content-Type": "application/json"}, data=json.dumps(body), timeout=60) or {}
    seen, out = set(), []
    for f in d.get("features", []):
        p = f["properties"]
        if not p.get("datetime"):
            continue
        k = (p["datetime"][:16], p.get("platform"))  # reprocessed or overlapping copies of one pass
        if k in seen:
            continue
        seen.add(k)
        out.append({"id": f["id"], "date": p["datetime"][:16], "cloud": p.get("eo:cloud_cover"), "platform": p.get("platform"), "bbox": f.get("bbox"), "orbit": p.get("sat:orbit_state"),
                    "sun": [p.get("s2:mean_solar_azimuth", p.get("view:sun_azimuth")), 90 - p["s2:mean_solar_zenith"] if p.get("s2:mean_solar_zenith") is not None else p.get("view:sun_elevation")],
                    "url": "%s/stac/v1/collections/%s/items/%s" % (PC, col, f["id"])})
    return {"items": out, "more": len(d.get("features", [])) >= 100}


def clarity(q):
    """Share of cloud, haze or cloud shadow within about 1.5 km, from Sentinel-2's scene classification."""
    lat, lon, ids = float(q["lat"]), float(q["lon"]), [i for i in q["ids"].split(",") if re.match(r"^[\w.-]{8,120}$", i)][:24]
    dy, dx = .0135, .0135 / max(.1, math.cos(math.radians(lat)))
    ring = [[lon - dx, lat - dy], [lon + dx, lat - dy], [lon + dx, lat + dy], [lon - dx, lat + dy], [lon - dx, lat - dy]]
    body = json.dumps({"type": "Feature", "properties": {}, "geometry": {"type": "Polygon", "coordinates": [ring]}})

    def one(i):
        try:
            d = C.Ctx({}).json("%s/data/v1/item/statistics?collection=sentinel-2-l2a&item=%s&assets=SCL&categorical=true&max_size=256" % (PC, i), headers={"Content-Type": "application/json"}, data=body, timeout=40)
            st = next(iter(((d.get("properties") or {}).get("statistics") or {}).values()))
            n, v = st["histogram"]
            tot = sum(n)
            return i, round(100 * sum(a for a, b in zip(n, v) if int(b) in (0, 1, 3, 8, 9, 10)) / tot) if tot else None
        except (C.SourceError, AttributeError, StopIteration, KeyError, TypeError, ValueError):
            return i, None
    with ThreadPoolExecutor(8) as ex:
        return dict(ex.map(one, ids))


def record(url):
    """The catalogue entry for a scene, kept with the evidence."""
    if not url.startswith(PC + "/stac/v1/collections/") or not re.match(r"^[\w./:-]+$", url):
        raise ValueError("not a scene address")
    return C.Ctx({}).get(url, timeout=40)


_wb = {"at": 0, "list": []}


def _versions():
    if time.time() - _wb["at"] > 86400:
        d = json.loads(C.Ctx({}).get("https://s3-us-west-2.amazonaws.com/config.maptiles.arcgis.com/waybackconfig.json", timeout=40))
        _wb["list"] = sorted(((re.search(r"(\d{4}-\d\d-\d\d)", v["itemTitle"])[1], k, v["metadataLayerUrl"], v["itemID"]) for k, v in d.items()), reverse=True)
        _wb["at"] = time.time()
    return _wb["list"]


WBZ = 17  # Esri mixes different pictures at different zooms, so dates are always looked up at the same close level


def _wbmeta(murl, lat, lon, z):
    g = json.dumps({"x": lon, "y": lat, "spatialReference": {"wkid": 4326}})
    m = C.Ctx({}).json("%s/%d/query" % (murl, max(0, 23 - z)), {"f": "json", "where": "1=1", "outFields": "SRC_DATE2,NICE_DESC,SRC_DESC,SAMP_RES,SRC_ACC", "geometry": g, "geometryType": "esriGeometryPoint", "spatialRel": "esriSpatialRelIntersects", "returnGeometry": "false"}, timeout=25) or {}
    a = (m.get("features") or [{}])[0].get("attributes") or {}
    o = {"provider": a.get("NICE_DESC"), "sensor": a.get("SRC_DESC"), "res": a.get("SAMP_RES"), "acc": a.get("SRC_ACC")}
    if a.get("SRC_DATE2"):
        o["date"] = time.strftime("%Y-%m-%d", time.gmtime(a["SRC_DATE2"] / 1000))
    return o


def wbcheck(q):
    """The capture date actually on screen: this release, this spot, this zoom."""
    v = next((v for v in _versions() if v[1] == q["id"]), None)
    if not v:
        raise ValueError("no such version")
    return _wbmeta(v[2], float(q["lat"]), float(q["lon"]), max(10, min(19, int(float(q["z"])))))


def wayback(q):
    """Esri republishes the same picture many times. This keeps one entry per genuinely different picture at this spot."""
    lat, lon = float(q["lat"]), float(q["lon"])
    z = WBZ
    n = 2 ** z
    x, y = int((lon + 180) / 360 * n), int((1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n)
    vs = _versions()
    ix = {v[1]: i for i, v in enumerate(vs)}
    missed = []

    def walk(span):
        i, end = span
        got, tries = [], 0
        while i < end:
            try:
                d = C.Ctx({}).json("%s/MapServer/tilemap/%s/%d/%d/%d" % (WB, vs[i][1], z, y, x), timeout=25) or {}
                tries = 0
            except C.SourceError:
                tries += 1
                if tries < 3:
                    time.sleep(.6)
                    continue
                missed.append(i)  # say so rather than pass off a gap as a complete list
                tries, i = 0, i + 1
                continue
            if not (d.get("data") or [0])[0]:
                i += 1
                continue
            at = max(i, ix.get(str((d.get("select") or [vs[i][1]])[0]), i))  # the release where this picture first appeared
            got.append(at)
            i = at + 1
        return got
    size = max(1, len(vs) // 8)
    with ThreadPoolExecutor(9) as ex:
        found = sorted({at for l in ex.map(walk, [(i, min(len(vs), i + size)) for i in range(0, len(vs), size)]) for at in l})

    def meta(at):
        date, rel, murl, item = vs[at]
        o = {"id": rel, "published": date, "url": "https://livingatlas.arcgis.com/wayback/#active=%s&mapCenter=%.5f,%.5f,%d" % (rel, lon, lat, z)}
        try:
            o.update(_wbmeta(murl, lat, lon, z))
        except (C.SourceError, OverflowError, OSError):
            pass
        return o
    with ThreadPoolExecutor(8) as ex:
        items = list(ex.map(meta, found))
    out, seen = [], set()
    for o in items:
        k = (o.get("date"), o.get("sensor")) if o.get("date") else o["id"]
        if k not in seen:
            seen.add(k)
            out.append(o)
    return {"items": sorted(out, key=lambda o: o.get("date") or o["published"], reverse=True), "checked": len(vs), "missed": len(missed)}


# ---------------------------------------------------------------- heat detections (NASA FIRMS)

FIRMS = "https://firms.modaps.eosdis.nasa.gov"
FILES = {"NOAA-21": "noaa-21-viirs-c2/csv/J2_VIIRS_C2_Global_%s.csv", "NOAA-20": "noaa-20-viirs-c2/csv/J1_VIIRS_C2_Global_%s.csv"}
CACHE = os.path.join(tempfile.gettempdir(), "antherra-firms")  # core.py moves this inside the private folder
_fl = threading.Lock()


def _open_file(sat, span):
    """The public worldwide file, refetched at most hourly."""
    os.makedirs(CACHE, mode=0o700, exist_ok=True)
    f = os.path.join(CACHE, "%s-%s.csv" % (sat, span))
    with _fl:
        if not os.path.exists(f) or time.time() - os.path.getmtime(f) > 3600:
            try:
                with urllib.request.urlopen(urllib.request.Request(FIRMS + "/data/active_fire/" + FILES[sat] % span, headers={"User-Agent": C.UA}), timeout=120) as r, open(f + ".tmp", "wb") as o:
                    shutil.copyfileobj(r, o)
                os.replace(f + ".tmp", f)
            except (urllib.error.URLError, OSError) as e:
                if not os.path.exists(f):
                    raise C.SourceError("NASA FIRMS did not answer (%s)" % getattr(e, "reason", e))
    return open(f, newline="", encoding="utf-8")


def _rows(fh, sat, box):
    s, n, w, e = box
    for r in csv.DictReader(fh):
        try:
            la, lo = float(r["latitude"]), float(r["longitude"])
        except (KeyError, TypeError, ValueError):
            continue
        if s <= la <= n and w <= lo <= e:
            t = (r.get("acq_time") or "").replace(":", "").zfill(4)
            yield {"lat": la, "lon": lo, "date": "%sT%s:%s" % (r["acq_date"], t[:2], t[2:4]), "sat": sat, "frp": float(r.get("frp") or 0), "conf": r.get("confidence"), "dn": {"D": "day", "N": "night"}.get(r.get("daynight"), ""),
                   "url": "https://worldview.earthdata.nasa.gov/?v=%.3f,%.3f,%.3f,%.3f&t=%s&l=VIIRS_NOAA21_Thermal_Anomalies_375m_All,VIIRS_NOAA21_CorrectedReflectance_TrueColor" % (lo - .5, la - .4, lo + .5, la + .4, r["acq_date"])}


def fires(q, key=None):
    box = [float(q[k]) for k in "snwe"]
    if q.get("date"):  # a past date: up to 5 days ending on it, through the keyed service
        if not re.match(_DAY, q["date"]):
            raise ValueError("choose a date")
        if not key:
            raise ValueError("Heat detections older than 7 days need a free NASA FIRMS key (Settings).")
        if not re.match(r"^\w{16,64}$", key):
            raise ValueError("the FIRMS key does not look right (Settings)")
        out, start = [], time.strftime("%Y-%m-%d", time.gmtime(calendar.timegm(time.strptime(q["date"], "%Y-%m-%d")) - 4 * 86400))
        for sat, src in (("NOAA-20", "VIIRS_NOAA20_SP"), ("NOAA-20", "VIIRS_NOAA20_NRT"), ("NOAA-21", "VIIRS_NOAA21_NRT")):
            try:
                with urllib.request.urlopen(urllib.request.Request("%s/api/area/csv/%s/%s/%.3f,%.3f,%.3f,%.3f/5/%s" % (FIRMS, key, src, box[2], box[0], box[3], box[1], start), headers={"User-Agent": C.UA}), timeout=60) as r:
                    t = r.read(20 << 20).decode("utf-8", "replace")
                if not t.lstrip().lower().startswith("country_id") and not t.lstrip().lower().startswith("latitude"):
                    raise C.SourceError("NASA FIRMS refused the request. Check the key in Settings" if "key" in t[:200].lower() else "NASA FIRMS gave an unreadable answer")
                out += list(_rows(io.StringIO(t), sat, box))
            except (urllib.error.URLError, OSError):
                raise C.SourceError("NASA FIRMS did not accept the request")  # never echo the address: it contains the key
    else:
        span, out, age = "7d" if q.get("span") == "7d" else "24h", [], 0
        for sat in FILES:
            with _open_file(sat, span) as fh:
                age = max(age, time.time() - os.fstat(fh.fileno()).st_mtime)
                out += list(_rows(fh, sat, box))
    out = sorted({(p["lat"], p["lon"], p["date"], p["sat"]): p for p in out}.values(), key=lambda p: -p["frp"])
    return {"items": out[:1500], "total": len(out), "stale": int(age // 3600) if not q.get("date") and age > 7200 else 0}
