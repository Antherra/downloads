"""Fetch arbitrary public web pages without letting a hostile URL reach this computer or its network."""
import html, http.client, ipaddress, re, socket, ssl, time, urllib.error, urllib.parse, urllib.request

UA = "Mozilla/5.0 (compatible; osint-workbench/1.0)"
MAX = 25 * 1024 * 1024


class Blocked(Exception):
    pass


def public(addr):
    ip = ipaddress.ip_address(addr.split("%")[0])
    if ip.version == 6:
        if ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        elif ip in ipaddress.ip_network("64:ff9b::/96"):
            ip = ipaddress.ip_address(int(ip) & 0xFFFFFFFF)
        elif ip.sixtofour:
            ip = ip.sixtofour
    return ip.is_global and not ip.is_multicast


def check(url):
    u = urllib.parse.urlsplit(url)
    if u.scheme not in ("http", "https") or not u.hostname:
        raise Blocked("only http and https addresses can be captured")
    try:
        infos = socket.getaddrinfo(u.hostname, u.port or (443 if u.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except OSError:
        raise Blocked("that host name does not resolve")
    for i in infos:
        if not public(i[4][0]):
            raise Blocked("that address points inside a private network")
    return url


# A name can resolve to one machine when checked and another when fetched, so the live connection is checked too.
# With a system proxy the connection is to the proxy, and the proxy does the resolving.
class _Http(http.client.HTTPConnection):
    def connect(self):
        super().connect()
        _peer(self)


class _HttpsConn(http.client.HTTPSConnection):
    def connect(self):
        super().connect()
        _peer(self)


def _peer(c):
    if not urllib.request.getproxies() and not public(c.sock.getpeername()[0]):
        c.close()
        raise Blocked("that address points inside a private network")


class _HH(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_Http, req)


class _HS(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_HttpsConn, req, context=ssl.create_default_context())


class _Redir(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def safe_fetch(url, timeout=30):
    check(url)
    op = urllib.request.build_opener(_Redir, _HH, _HS)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "en"})
    try:
        r = op.open(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        r = e
    except Blocked:
        raise
    except Exception as e:
        raise Blocked("could not fetch (%s)" % getattr(e, "reason", e))
    with r:
        body = r.read(MAX + 1)
        return {"url": r.geturl(), "status": r.getcode(), "headers": {k.lower(): v for k, v in r.headers.items()},
                "body": body[:MAX], "truncated": len(body) > MAX, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}


_SKIP, _BREAK = ("script", "style", "noscript", "svg", "template"), re.compile(r"^(br|/p|/div|/li|/h\d|/tr|/td|/article|/section)\b", re.I)


def text_of(page):
    """Title and readable text. One pass with no backtracking, so a hostile page cannot stall it."""
    out, skip, title, in_title = [], None, [], False
    parts = page.split("<")
    out.append(parts[0])
    for p in parts[1:]:
        j = p.find(">")
        name = re.match(r"/?[A-Za-z][A-Za-z0-9]{0,15}", p[:17])
        name = name[0].lower() if name else ""
        if skip:
            if name == "/" + skip:
                skip = None
                out.append(" " + p[j + 1:] if j >= 0 else " ")
            continue
        if not name and not p.startswith("!") and not p.startswith("?"):
            out.append("<" + p)  # a bare less-than sign, not a tag
            continue
        rest = p[j + 1:] if j >= 0 else ""
        if name in _SKIP and not p[:j].endswith("/"):
            skip = name
            continue
        if name == "title":
            in_title = not title
        elif name == "/title":
            in_title = False
        if in_title:
            title.append(rest)
            continue
        out.append(("\n" if _BREAK.match(p[:12]) else " ") + rest)
    tidy = lambda t: re.sub(r"[ \t\r\f\v\xa0]+", " ", html.unescape(t))
    lines = (l.strip() for l in tidy("".join(out)).split("\n"))
    return " ".join(tidy("".join(title)).split())[:300], "\n".join(l for l in lines if l)[:60000]
