"""Signed updates. Nothing is run unless its signature checks out against the key below."""
import base64, hashlib, io, json, os, re, shutil, sqlite3, sys, time, urllib.error, urllib.parse, urllib.request, zipfile

VERSION = "1.5.0"
UPDATE_REPO = "Antherra/downloads"  # GitHub "owner/name"; blank turns update checks off
PUBLIC_KEY = "033d534140030ed8e792f6882b479fbc402b1efd0bd5b92e9e251117f9dbcd2a"   # Ed25519, hex
MAX_ZIP = 30 << 20
DOMAIN = b"antherra-update-v1\n"


class UpdateError(ValueError):
    pass


def home():
    return os.environ.get("ANTHERRA_HOME") or os.path.expanduser("~/Library/Application Support/Antherra" if sys.platform == "darwin" else "~/AppData/Local/Antherra" if os.name == "nt" else "~/.antherra")


def vtuple(v):
    if not isinstance(v, str) or not re.match(r"^\d{1,4}(\.\d{1,4}){1,3}$", v):
        raise UpdateError("bad version number")
    t = tuple(int(x) for x in v.split("."))
    return t + (0,) * (4 - len(t))

# ---------------------------------------------------------------- Ed25519 (RFC 8032), verification only


P = 2 ** 255 - 19
Q = 2 ** 252 + 27742317777372353535851937790883648493
D = -121665 * pow(121666, P - 2, P) % P
I = pow(2, (P - 1) // 4, P)


def _add(a, b):
    A, B = (a[1] - a[0]) * (b[1] - b[0]) % P, (a[1] + a[0]) * (b[1] + b[0]) % P
    C, E = 2 * a[3] * b[3] * D % P, 2 * a[2] * b[2] % P
    e, f, g, h = B - A, E - C, E + C, B + A
    return e * f % P, g * h % P, f * g % P, e * h % P


def _mul(s, p):
    r = (0, 1, 1, 0)
    while s:
        if s & 1:
            r = _add(r, p)
        p, s = _add(p, p), s >> 1
    return r


def _eq(a, b):
    return (a[0] * b[2] - b[0] * a[2]) % P == 0 and (a[1] * b[2] - b[1] * a[2]) % P == 0


def _decode(b):
    if len(b) != 32:
        return None
    y = int.from_bytes(b, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    if y >= P:
        return None
    x2 = (y * y - 1) * pow(D * y * y + 1, P - 2, P) % P
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P:
        x = x * I % P
    if (x * x - x2) % P or (x == 0 and sign):
        return None
    if x & 1 != sign:
        x = P - x
    return x, y, 1, x * y % P


_gy = 4 * pow(5, P - 2, P) % P
BASE = _decode(_gy.to_bytes(32, "little"))


def verify(pub, msg, sig):
    if len(pub) != 32 or len(sig) != 64:
        return False
    A, R = _decode(pub), _decode(sig[:32])
    s = int.from_bytes(sig[32:], "little")
    if A is None or R is None or s >= Q or _eq(_mul(8, A), (0, 1, 1, 0)):  # the last refuses weak keys
        return False
    k = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % Q
    return _eq(_mul(s, BASE), _add(R, _mul(k, A)))

# ---------------------------------------------------------------- manifests and packages


def open_manifest(raw, key=None):
    """Returns the signed facts about an update, or raises."""
    key = PUBLIC_KEY if key is None else key
    if not re.match(r"^[0-9a-f]{64}$", key):
        raise UpdateError("this copy has no update key")
    try:
        j = json.loads(raw)
        payload, sig = base64.b64decode(j["payload"], validate=True), bytes.fromhex(j["sig"])
    except (ValueError, KeyError, TypeError):
        raise UpdateError("the update information is unreadable")
    if not verify(bytes.fromhex(key), DOMAIN + payload, sig):
        raise UpdateError("the update is not signed by Antherra's publisher, so it was refused")
    m = json.loads(payload)
    vtuple(m["version"])
    if m.get("app") != "antherra" or not re.match(r"^[0-9a-f]{64}$", m["sha256"]) or not 0 < m["size"] <= MAX_ZIP:
        raise UpdateError("the update information is not valid")
    return m


NAME = re.compile(r"^(?:[A-Za-z0-9_][\w.-]*/){0,4}[A-Za-z0-9_][\w.-]*$")


def members(data, m):
    if len(data) != m["size"] or hashlib.sha256(data).hexdigest() != m["sha256"]:
        raise UpdateError("the update file does not match its signature, so it was refused")
    out = {}
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for i in z.infolist():
            if i.is_dir():
                continue
            if not NAME.match(i.filename) or (i.external_attr >> 16) & 0o170000 == 0o120000 or i.file_size > MAX_ZIP:
                raise UpdateError("the update contains an unsafe file name")
            out[i.filename] = z.read(i)
    if "core.py" not in out or "update.py" not in out or "web/index.html" not in out:
        raise UpdateError("the update is incomplete")
    return out


def udir(*a):
    return os.path.join(home(), "updates", *a)


def _state():
    try:
        with open(udir("state.json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_state(**kw):
    s = _state()
    s.update(kw)
    os.makedirs(udir(), mode=0o700, exist_ok=True)
    with os.fdopen(os.open(udir("state.json.tmp"), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
        json.dump(s, f)
    os.replace(udir("state.json.tmp"), udir("state.json"))
    return s


def store(raw, data):
    """Writes a checked update beside the user's data. Takes effect at the next start."""
    m = open_manifest(raw)
    files = members(data, m)
    if vtuple(m["version"]) <= vtuple(VERSION):
        raise UpdateError("that update is not newer than this version")
    tmp, final = udir("." + m["version"]), udir(m["version"])
    shutil.rmtree(tmp, ignore_errors=True)
    for n, b in files.items():
        p = os.path.join(tmp, "app", *n.split("/"))
        os.makedirs(os.path.dirname(p), mode=0o700, exist_ok=True)
        with open(p, "wb") as f:
            f.write(b)
    for n, b in (("update.json", raw if isinstance(raw, bytes) else raw.encode()), ("update.zip", data)):
        with open(os.path.join(tmp, n), "wb") as f:
            f.write(b)
    shutil.rmtree(final, ignore_errors=True)
    os.rename(tmp, final)
    bad = [v for v in _state().get("bad", []) if v != m["version"]]
    set_state(bad=bad, trying=None, fails=0)
    return m


def check_stored(v, shell):
    """Re-checks a stored update at every start: signature, package, and each unpacked file."""
    d = udir(v)
    with open(os.path.join(d, "update.json"), "rb") as f:
        m = open_manifest(f.read())
    if m["version"] != v or m.get("min_shell", 1) > shell:
        raise UpdateError("not for this copy")
    with open(os.path.join(d, "update.zip"), "rb") as f:
        files = members(f.read(MAX_ZIP + 1), m)
    app, seen = os.path.join(d, "app"), set()
    for n, b in files.items():
        p = os.path.join(app, *n.split("/"))
        with open(p, "rb") as f:
            if os.path.islink(p) or f.read() != b:
                raise UpdateError("an unpacked file was changed")
        seen.add(os.path.normcase(os.path.realpath(p)))
    for base, _, names in os.walk(app):
        for n in names:
            if os.path.normcase(os.path.realpath(os.path.join(base, n))) not in seen:
                raise UpdateError("an extra file was added")
    return app


def choose(shell):
    """The newest stored update that is newer than the built-in version and passes every check."""
    st, best = _state(), None
    try:
        names = os.listdir(udir())
    except OSError:
        return None, None
    vs = []
    for n in names:
        try:
            vs.append((vtuple(n), n))
        except UpdateError:
            pass
    for t, v in sorted(vs, reverse=True):
        if t <= vtuple(VERSION):
            shutil.rmtree(udir(v), ignore_errors=True)  # the app itself has caught up
        elif best is None and v not in st.get("bad", []):
            if st.get("trying") == v and st.get("fails", 0) >= 2:  # did not reach a working page twice
                mark_bad(v, "did not start")
                continue
            try:
                best = v, check_stored(v, shell)
            except (UpdateError, OSError, zipfile.BadZipFile, KeyError, ValueError) as e:
                mark_bad(v, str(e))
    return best or (None, None)


def mark_bad(v, why):
    s = _state()
    set_state(bad=sorted(set(s.get("bad", []) + [v])), why=str(why)[:200], trying=None, fails=0)


def backup_db(label):
    """A copy of the case database before a different version first opens it. Keeps the last three."""
    d = os.path.join(home(), "backups")
    for name in ("vault.db", "antherra.db"):  # the first is encrypted; the second is from 1.4 and earlier, before a passphrase is set
        src = os.path.join(home(), name)
        if not os.path.exists(src):
            continue
        os.makedirs(d, mode=0o700, exist_ok=True)
        dst = os.path.join(d, "%s-before-%s-%s.db" % (name[:-3], label, time.strftime("%Y%m%d-%H%M%S")))
        os.close(os.open(dst, os.O_WRONLY | os.O_CREAT, 0o600))
        a, b = sqlite3.connect(src), sqlite3.connect(dst)
        try:
            a.backup(b)
        finally:
            a.close(), b.close()
        if name == "vault.db":  # a copy of the records is no use without the matching wrapped key
            shutil.copyfile(os.path.join(home(), "vault.json"), dst[:-3] + ".json")
            os.chmod(dst[:-3] + ".json", 0o600)
    if not os.path.isdir(d):
        return
    kept = sorted((os.path.join(d, n) for n in os.listdir(d)), key=os.path.getmtime)
    for old in kept[:-6]:
        os.remove(old)

# ---------------------------------------------------------------- network


class _Https(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not (newurl.startswith("https://") or newurl.startswith("http://127.0.0.1:") and os.environ.get("ANTHERRA_TEST_FEED")):
            raise UpdateError("the update address redirected somewhere insecure")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def feed():
    t = os.environ.get("ANTHERRA_TEST_FEED", "")  # testing only, and only on this computer; signatures still apply
    if re.match(r"^http://127\.0\.0\.1:\d+/$", t):
        return t
    if re.match(r"^[\w-]{1,39}/[\w.-]{1,100}$", UPDATE_REPO):
        return "https://github.com/%s/releases/latest/download/" % UPDATE_REPO
    return None


def _get(name, limit):
    u = feed()
    if not u:
        raise UpdateError("this copy has no update address")
    try:
        with urllib.request.build_opener(_Https).open(urllib.request.Request(u + name, headers={"User-Agent": "osint-workbench/1.0"}), timeout=60) as r:
            b = r.read(limit + 1)
    except urllib.error.HTTPError as e:
        raise UpdateError("no update can be fetched automatically. Antherra is shared by invitation, so look on its download page" if e.code == 404 else "the update server answered %d" % e.code)
    except (urllib.error.URLError, OSError) as e:
        raise UpdateError("could not reach the update server (%s)" % getattr(e, "reason", e))
    if len(b) > limit:
        raise UpdateError("the update is larger than it should be")
    return b


def check(shell):
    raw = _get("antherra-update.json", 1 << 20)
    m = open_manifest(raw)
    newer = vtuple(m["version"]) > vtuple(VERSION)
    return {"version": m["version"], "newer": newer, "notes": str(m.get("notes", ""))[:4000], "released": m.get("released"), "full": newer and m.get("min_shell", 1) > shell,
            "page": "https://github.com/%s/releases/latest" % UPDATE_REPO if UPDATE_REPO else None}, raw


def install(shell):
    info, raw = check(shell)
    if not info["newer"]:
        raise UpdateError("you already have the newest version")
    if info["full"]:
        raise UpdateError("this update needs a full download")
    return store(raw, _get("antherra-update.zip", MAX_ZIP))
