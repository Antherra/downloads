"""Lookup connectors. Every connector is a function (q, ctx) -> list of items.

item = {title, type, sub, url, fields:[[k,v]], lat, lon, date, related:[{type,title,rel,url}], dates:[{date,title}]}
ctx.get/ctx.json fetch over HTTP and keep the raw response so a citation can be re-checked later.
"""
import hashlib, json, re, threading, time, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor

UA = "osint-workbench/1.0"
MAX_BODY = 8 * 1024 * 1024
_rate_lock, _rate = threading.Lock(), {}
SPACING = {"api.gdeltproject.org": 6, "nominatim.openstreetmap.org": 1.1, "www.wikidata.org": .4, "en.wikipedia.org": .4, "commons.wikimedia.org": .4}


class SourceError(Exception):
    pass


def _space(host):
    gap = SPACING.get(host)
    if not gap:
        return
    with _rate_lock:
        now = time.time()
        at = max(now, _rate.get(host, 0) + gap)
        _rate[host] = at
    time.sleep(max(0, at - now))


class _Redir(urllib.request.HTTPRedirectHandler):
    """A redirect never carries an API key to another host, and never drops to an unencrypted connection."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        n = super().redirect_request(req, fp, code, msg, headers, newurl)
        a, b = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        if a.scheme == "https" and b.scheme != "https":
            raise SourceError("the source redirected to an unencrypted address, so it was not followed")
        if n is not None and (a.scheme, a.netloc) != (b.scheme, b.netloc):
            for k in ("Authorization", "X-api-key", "Cookie"):
                n.headers.pop(k, None)
        return n


_OPEN = urllib.request.build_opener(_Redir)
_SECRET = re.compile(r"([?&](?:api[-_]?key|key|token|apikey)=)[^&#]*", re.I)


class Ctx:
    def __init__(self, settings, db=None):
        self.settings, self.db, self.raw = settings, db, []
        self.lock = threading.Lock()

    def get(self, url, params=None, headers=None, data=None, timeout=20, ok=(200,)):
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
        h = {"User-Agent": UA, "Accept": "application/json, text/html;q=0.8, */*;q=0.5"}
        h.update(headers or {})
        body = data.encode() if isinstance(data, str) else data
        _space(urllib.parse.urlsplit(url).hostname)
        host = urllib.parse.urlsplit(url).hostname
        for attempt in (0, 1):
            req = urllib.request.Request(url, data=body, headers=h)
            try:
                with _OPEN.open(req, timeout=timeout) as r:
                    status, out = r.status, r.read(MAX_BODY)
            except urllib.error.HTTPError as e:
                status, out = e.code, e.read(65536)
            except SourceError:
                raise
            except Exception as e:
                reason = getattr(e, "reason", e)
                raise SourceError("could not reach the source (%s)" % reason)
            if status != 429 or attempt or host not in SPACING:
                break
            time.sleep(max(3, SPACING[host]))
            _space(host)
        with self.lock:
            self.raw.append({"url": _SECRET.sub(r"\1REMOVED", url), "status": status, "sha256": hashlib.sha256(out).hexdigest(),
                             "body": out.decode("utf-8", "replace")})
        if status not in ok:
            if status == 404:
                return None
            if status == 429:
                raise SourceError("rate limited by the source; wait and try again")
            raise SourceError("source answered HTTP %d" % status)
        return out.decode("utf-8", "replace")

    def json(self, url, params=None, **kw):
        t = self.get(url, params, **kw)
        if t is None:
            return None
        try:
            return json.loads(t)
        except ValueError:
            raise SourceError("source returned something that is not JSON")

    def key(self, name):
        k = (self.settings.get("keys") or {}).get(name)
        if not k:
            raise SourceError("needs an API key (Settings)")
        return k


REG = []


def source(id, name, host, types, group, key=None, direct=False, local=False):
    def deco(fn):
        REG.append(dict(id=id, name=name, host=host, types=types, group=group, key=key, direct=direct, local=local, fn=fn))
        return fn
    return deco


def F(*pairs):
    out = []
    for k, v in pairs:
        if isinstance(v, (list, tuple)):
            v = ", ".join(str(x) for x in v if x)
        if v not in (None, "", [], {}):
            out.append([k, str(v)[:1200]])
    return out


def strip(s):
    import html
    return html.unescape(re.sub(r"<[^<>]*>", "", s or "")).strip()


def quote(s):
    return urllib.parse.quote(s, safe="")


def iso(ts):
    return time.strftime("%Y-%m-%d", time.gmtime(ts))


NAMEY = ["company", "person", "text"]

# ------------------------------------------------------------------ domains

def _rdap_entities(d):
    out = []
    for e in d.get("entities", []):
        v = (e.get("vcardArray") or [None, []])[1]
        name = next((x[3] for x in v if x[0] in ("fn", "org") and x[3]), None)
        if name and isinstance(name, str):
            out.append((", ".join(e.get("roles", [])), name))
        out += _rdap_entities(e)
    return out


def _rdap_events(d):
    return {e.get("eventAction"): (e.get("eventDate") or "")[:10] for e in d.get("events", [])}


@source("rdap", "Registration record (RDAP)", "rdap.org", ["domain", "ip"], "Infrastructure")
def rdap(q, ctx):
    kind = "ip" if re.match(r"^[\d.]+$|:", q) else "domain"
    d = ctx.json("https://rdap.org/%s/%s" % (kind, quote(q)))
    if not d:
        return []
    ev, ents = _rdap_events(d), _rdap_entities(d)
    ns = [n.get("ldhName", "").lower() for n in d.get("nameservers", [])]
    dates = [{"date": v, "title": "%s: %s" % (q, k)} for k, v in ev.items()
             if v and k in ("registration", "expiration", "transfer", "last changed")]
    return [dict(title=q, type=kind, sub="Registry record", url="https://rdap.org/%s/%s" % (kind, q),
                 fields=F(("Registered", ev.get("registration")), ("Expires", ev.get("expiration")),
                          ("Last changed", ev.get("last changed")), ("Status", d.get("status")),
                          ("Name servers", ns), ("Network", d.get("name") if kind == "ip" else None),
                          ("Range", "%s to %s" % (d.get("startAddress"), d.get("endAddress")) if kind == "ip" else None),
                          ("Country", d.get("country")), *[(r.title() or "Contact", n) for r, n in ents[:8]]),
                 related=[dict(type="company", title=n, rel=r or "contact") for r, n in ents[:6] if "registrar" in r or kind == "ip"],
                 dates=dates)]


@source("dns", "DNS records", "dns.google", ["domain"], "Infrastructure")
def dns(q, ctx):
    def one(t):
        try:
            d = ctx.json("https://dns.google/resolve", {"name": q, "type": t})
            return t, [a["data"] for a in (d or {}).get("Answer", []) if a.get("type") in (1, 2, 5, 6, 15, 16, 28, 257)]
        except SourceError:
            return t, []
    with ThreadPoolExecutor(6) as ex:
        rec = dict(ex.map(one, ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "CAA"]))
    if not any(rec.values()):
        return []
    rel = [dict(type="ip", title=a, rel="resolves to") for a in rec["A"][:6] if re.match(r"^[\d.]+$", a)]
    rel += [dict(type="domain", title=m.split()[-1].rstrip("."), rel="mail handled by") for m in rec["MX"][:4]
            if m.split()[-1].rstrip(".")]
    return [dict(title=q, type="domain", sub="Current DNS", fields=F(*[(k, " | ".join(v)) for k, v in rec.items() if v]), related=rel,
                 url="https://dns.google/query?name=" + quote(q))]


@source("ct", "Certificates and subdomains", "api.certspotter.com", ["domain"], "Infrastructure")
def ct(q, ctx):
    d = ctx.json("https://api.certspotter.com/v1/issuances",
                 [("domain", q), ("include_subdomains", "true"), ("expand", "dns_names"), ("expand", "issuer")]) or []
    names = {}
    for c in d:
        for n in c.get("dns_names", []):
            n = n.lower()
            if n.lstrip("*.").endswith(q.lower()):
                names.setdefault(n, (c.get("not_before") or "")[:10])
    if not names:
        return []
    subs = sorted(n for n in names if not n.startswith("*") and n != q.lower())
    return [dict(title="%d names on certificates" % len(names), type="domain", sub=q, value=q, url="https://crt.sh/?q=" + quote(q),
                 fields=F(("Names", sorted(names)[:80]), ("Certificates seen", len(d)), ("Earliest shown", min(names.values()))),
                 related=[dict(type="domain", title=s, rel="subdomain") for s in subs[:20]])]


@source("wayback", "Wayback Machine", "web.archive.org", ["domain", "url"], "Archives")
def wayback(q, ctx):
    d = ctx.json("https://web.archive.org/cdx/search/cdx",
                 {"url": q, "output": "json", "fl": "timestamp,original,statuscode,digest", "collapse": "timestamp:6", "limit": "400"}, timeout=40)
    rows = (d or [])[1:]
    if not rows:
        return []
    def dd(t): return "%s-%s-%s" % (t[:4], t[4:6], t[6:8])
    years = {}
    for r in rows:
        years[r[0][:4]] = years.get(r[0][:4], 0) + 1
    pick = [rows[0]] + rows[len(rows) // 3:len(rows) // 3 + 1] + rows[2 * len(rows) // 3:2 * len(rows) // 3 + 1] + [rows[-1]]
    out = [dict(title="%d monthly snapshots" % len(rows), type="url" if "/" in q else "domain", value=q, sub="%s to %s" % (dd(rows[0][0]), dd(rows[-1][0])),
                url="https://web.archive.org/web/*/" + q,
                fields=F(("First archived", dd(rows[0][0])), ("Latest archived", dd(rows[-1][0])),
                         ("Per year", "  ".join("%s:%d" % x for x in sorted(years.items()))),
                         ("Note", "Capped at 400 snapshots" if len(rows) >= 400 else None)),
                dates=[{"date": dd(rows[0][0]), "title": "%s first archived" % q}])]
    seen = set()
    for r in pick:
        if r[0] in seen:
            continue
        seen.add(r[0])
        out.append(dict(title="Snapshot %s" % dd(r[0]), type="url", value="https://web.archive.org/web/%s/%s" % (r[0], r[1]),
                        sub="HTTP %s" % r[2], url="https://web.archive.org/web/%s/%s" % (r[0], r[1]), date=dd(r[0]), fields=[]))
    return out


@source("urlscan", "urlscan.io public scans", "urlscan.io", ["domain", "ip"], "Infrastructure")
def urlscan(q, ctx):
    f = "ip:%s" % q if re.match(r"^[\d.]+$|:", q) else "domain:%s" % q
    d = ctx.json("https://urlscan.io/api/v1/search/", {"q": f, "size": "8"}) or {}
    out = []
    for r in d.get("results", []):
        p, t = r.get("page", {}), r.get("task", {})
        out.append(dict(title=p.get("title") or p.get("url") or t.get("url"), type="url", value=p.get("url") or t.get("url"),
                        sub=(t.get("time") or "")[:10], date=(t.get("time") or "")[:10], url="https://urlscan.io/result/%s/" % r.get("_id"),
                        fields=F(("URL", p.get("url")), ("IP", p.get("ip")), ("Server", p.get("server")), ("Host", p.get("asnname")), ("Country", p.get("country"))),
                        related=[dict(type="ip", title=p["ip"], rel="served from")] if p.get("ip") else []))
    return out


@source("site", "Read the live site", "the target itself", ["domain"], "Infrastructure", direct=True)
def site(q, ctx):
    from net import safe_fetch
    r = safe_fetch("https://" + q)
    body = r["body"][:600000].decode("utf-8", "replace")
    ctx.raw.append({"url": r["url"], "status": r["status"], "sha256": hashlib.sha256(r["body"]).hexdigest(), "body": body})
    from net import text_of
    g = lambda p: strip((re.search(p, body, re.I) or [None, ""])[1])
    ids = sorted(set(re.findall(r"\b(UA-\d{4,10}-\d+|G-[A-Z0-9]{8,12}|GTM-[A-Z0-9]{5,8}|ca-pub-\d{12,18})\b", body)))
    mails = sorted(set(m for m in re.findall(r"[\w.+-]{1,64}@[\w-]{1,63}\.[a-z]{2,10}", body, re.I) if not re.search(r"\.(png|jpe?g|webp|svg|gif)$", m, re.I)))[:10]
    soc = sorted(set(re.findall(r"https?://(?:www\.)?(?:twitter|x|facebook|instagram|linkedin|t|youtube|tiktok)\.(?:com|me)/[\w@./-]{2,60}", body)))[:12]
    return [dict(title=text_of(body)[0] or q, type="domain", value=q, sub=r["url"], url=r["url"],
                 fields=F(("Server", r["headers"].get("server")), ("Powered by", r["headers"].get("x-powered-by")),
                          ("Generator", g(r'<meta name="generator" content="([^"]{1,300})"')), ("Description", g(r'<meta name="description" content="([^"]+)"')),
                          ("Tracking IDs", ids), ("Emails on page", mails), ("Social links", soc)),
                 related=[dict(type="email", title=m, rel="published on site") for m in mails] +
                         [dict(type="tracker", title=i, rel="uses tracking ID") for i in ids])]


# ------------------------------------------------------------------ IP

@source("ipwho", "IP location", "ipwho.is", ["ip"], "Infrastructure")
def ipwho(q, ctx):
    d = ctx.json("https://ipwho.is/" + quote(q)) or {}
    if not d.get("success"):
        return []
    c = d.get("connection", {})
    return [dict(title=q, type="ip", sub="%s, %s" % (d.get("city"), d.get("country")), url="https://ipwho.is/" + q,
                 lat=d.get("latitude"), lon=d.get("longitude"),
                 fields=F(("Location", [d.get("city"), d.get("region"), d.get("country")]), ("Network", c.get("org")), ("ISP", c.get("isp")),
                          ("ASN", c.get("asn")), ("Domain", c.get("domain")),
                          ("Caution", "IP geolocation is approximate and often points at the network owner, not the user")),
                 related=[dict(type="company", title=c["org"], rel="network operated by")] if c.get("org") else [])]


@source("internetdb", "Exposed services (Shodan InternetDB)", "internetdb.shodan.io", ["ip"], "Infrastructure")
def internetdb(q, ctx):
    d = ctx.json("https://internetdb.shodan.io/" + quote(q))
    if not d or "ip" not in d:
        return []
    return [dict(title=q, type="ip", sub="Last public scan data", url="https://www.shodan.io/host/" + q,
                 fields=F(("Open ports", d.get("ports")), ("Hostnames", d.get("hostnames")), ("Software", d.get("cpes")), ("Tags", d.get("tags")), ("Known CVEs", d.get("vulns"))),
                 related=[dict(type="domain", title=h, rel="hostname") for h in d.get("hostnames", [])[:10]])]


@source("ripe", "Routing (RIPEstat)", "stat.ripe.net", ["ip"], "Infrastructure")
def ripe(q, ctx):
    d = (ctx.json("https://stat.ripe.net/data/prefix-overview/data.json", {"resource": q}) or {}).get("data", {})
    if not d.get("asns"):
        return []
    return [dict(title=d.get("resource"), type="ip", value=q, sub="Announced prefix", url="https://stat.ripe.net/" + q,
                 fields=F(("Announced by", ["AS%s %s" % (a["asn"], a["holder"]) for a in d["asns"]])),
                 related=[dict(type="company", title=a["holder"], rel="announced by") for a in d["asns"][:3]])]


@source("ptr", "Reverse DNS", "dns.google", ["ip"], "Infrastructure")
def ptr(q, ctx):
    import ipaddress
    d = ctx.json("https://dns.google/resolve", {"name": ipaddress.ip_address(q).reverse_pointer, "type": "PTR"}) or {}
    names = [a["data"].rstrip(".") for a in d.get("Answer", []) if a.get("type") == 12]
    return [dict(title=n, type="domain", sub="PTR for " + q, fields=[], related=[]) for n in names]


# ------------------------------------------------------------------ email, usernames, phone

@source("mailpolicy", "Mail domain", "dns.google", ["email"], "People")
def mailpolicy(q, ctx):
    dom = q.split("@")[-1]
    def a(n, t):
        d = ctx.json("https://dns.google/resolve", {"name": n, "type": t}) or {}
        return [x["data"].strip('"') for x in d.get("Answer", [])]
    mx, txt, dm = a(dom, "MX"), a(dom, "TXT"), a("_dmarc." + dom, "TXT")
    return [dict(title=dom, type="domain", sub="Accepts mail" if mx else "No mail server: address cannot receive mail",
                 fields=F(("MX", mx), ("SPF", [t for t in txt if "spf1" in t]), ("DMARC", dm)), related=[])]


@source("gravatar", "Gravatar profile", "gravatar.com", ["email"], "People")
def gravatar(q, ctx):
    h = hashlib.md5(q.strip().lower().encode()).hexdigest()
    d = ctx.json("https://gravatar.com/%s.json" % h)
    out = []
    for e in (d or {}).get("entry", []) if isinstance(d, dict) else []:
        acc = e.get("accounts", [])
        out.append(dict(title=e.get("displayName") or e.get("preferredUsername"), type="person", sub="Public profile", url=e.get("profileUrl"),
                        fields=F(("Username", e.get("preferredUsername")), ("About", e.get("aboutMe")), ("Location", e.get("currentLocation")),
                                 ("Role", e.get("job_title")), ("Company", e.get("company")), ("Accounts", [a.get("url") for a in acc])),
                        related=[dict(type="username", title=a.get("display") or a.get("username"), rel=a.get("name") or "account", url=a.get("url")) for a in acc if a.get("username") or a.get("display")]))
    return out


@source("ghmail", "GitHub accounts by public email", "api.github.com", ["email"], "People")
def ghmail(q, ctx):
    d = ctx.json("https://api.github.com/search/users", {"q": q + " in:email"}) or {}
    return [dict(title=u["login"], type="username", sub="GitHub", url=u["html_url"], fields=[]) for u in d.get("items", [])[:5]]


def _acc(fn):
    return fn


SITES = [
    ("GitHub", "https://api.github.com/users/{}", "https://github.com/{}", lambda d: F(("Name", d.get("name")), ("Bio", d.get("bio")), ("Company", d.get("company")), ("Location", d.get("location")), ("Website", d.get("blog")), ("Joined", (d.get("created_at") or "")[:10]), ("Repositories", d.get("public_repos")))),
    ("Bluesky", "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor={}.bsky.social", "https://bsky.app/profile/{}.bsky.social", lambda d: F(("Name", d.get("displayName")), ("Bio", d.get("description")), ("Followers", d.get("followersCount")), ("Joined", (d.get("createdAt") or "")[:10]))),
    ("Mastodon (mastodon.social)", "https://mastodon.social/api/v1/accounts/lookup?acct={}", "https://mastodon.social/@{}", lambda d: F(("Name", d.get("display_name")), ("Bio", strip(d.get("note"))), ("Joined", (d.get("created_at") or "")[:10]), ("Links", [strip(f.get("value")) for f in d.get("fields", [])]))),
    ("Hacker News", "https://hacker-news.firebaseio.com/v0/user/{}.json", "https://news.ycombinator.com/user?id={}", lambda d: F(("About", strip(d.get("about"))), ("Karma", d.get("karma")), ("Joined", iso(d["created"]) if d.get("created") else None)) if d else None),
    ("Keybase", "https://keybase.io/_/api/1.0/user/lookup.json?usernames={}&fields=basics,profile,proofs_summary", "https://keybase.io/{}", lambda d: (lambda t: F(("Name", (t.get("profile") or {}).get("full_name")), ("Bio", (t.get("profile") or {}).get("bio")), ("Proven accounts", [p.get("service_url") or p.get("nametag") for p in (t.get("proofs_summary") or {}).get("all", [])]), ("Joined", iso(t["basics"]["ctime"]))) if t else None)((d.get("them") or [None])[0])),
    ("Lichess", "https://lichess.org/api/user/{}", "https://lichess.org/@/{}", lambda d: F(("Name", (d.get("profile") or {}).get("realName")), ("Country", (d.get("profile") or {}).get("flag")), ("Bio", (d.get("profile") or {}).get("bio")), ("Joined", iso(d["createdAt"] / 1000) if d.get("createdAt") else None)) if not d.get("disabled") else None),
    ("Chess.com", "https://api.chess.com/pub/player/{}", "https://www.chess.com/member/{}", lambda d: F(("Name", d.get("name")), ("Location", d.get("location")), ("Country", (d.get("country") or "").split("/")[-1]), ("Joined", iso(d["joined"]) if d.get("joined") else None))),
    ("Codeforces", "https://codeforces.com/api/user.info?handles={}", "https://codeforces.com/profile/{}", lambda d: (lambda r: F(("Name", "%s %s" % (r.get("firstName", ""), r.get("lastName", ""))), ("Country", r.get("country")), ("Organisation", r.get("organization")), ("Joined", iso(r["registrationTimeSeconds"]))))(d["result"][0]) if d.get("status") == "OK" else None),
    ("DEV Community", "https://dev.to/api/users/by_username?url={}", "https://dev.to/{}", lambda d: F(("Name", d.get("name")), ("Bio", d.get("summary")), ("Location", d.get("location")), ("Joined", d.get("joined_at")))),
    ("Docker Hub", "https://hub.docker.com/v2/users/{}/", "https://hub.docker.com/u/{}", lambda d: F(("Name", d.get("full_name")), ("Company", d.get("company")), ("Location", d.get("location")), ("Joined", (d.get("date_joined") or "")[:10]))),
    ("Wikimedia projects", "https://meta.wikimedia.org/w/api.php?action=query&meta=globaluserinfo&guiuser={}&guiprop=editcount&format=json", "https://meta.wikimedia.org/wiki/Special:CentralAuth/{}", lambda d: (lambda g: None if "missing" in g else F(("Edits", g.get("editcount")), ("Home wiki", g.get("home")), ("Joined", (g.get("registration") or "")[:10])))(d["query"]["globaluserinfo"])),
    ("OpenStreetMap", "https://api.openstreetmap.org/api/0.6/changesets.json?display_name={}&limit=1", "https://www.openstreetmap.org/user/{}", lambda d: (lambda c: F(("Latest edit", (c.get("created_at") or "")[:10]), ("Comment", (c.get("tags") or {}).get("comment"))) if c else F(("Account", "exists, no public edits")))((d.get("changesets") or [None])[0])),
]


@source("accounts", "Account sweep (12 public profile APIs)", "12 sites, listed per hit", ["username"], "People")
def accounts(q, ctx):
    q = q.lstrip("@")
    if not re.match(r"^[\w.-]{1,40}$", q):
        raise SourceError("not a plausible username")
    def one(s):
        name, api, page, fn = s
        try:
            t = ctx.get(api.format(quote(q)), timeout=12, ok=(200,))
        except SourceError as e:
            return None, ("%s: %s" % (name, e) if not re.search("HTTP 4(00|04|10)", str(e)) else None)
        if not t:
            return None, None
        try:
            d = json.loads(t)
            f = fn(d) if d else None
        except Exception:
            return None, "%s: unreadable answer" % name
        if f is None:
            return None, None
        j = dict(f).get("Joined")
        return dict(title="%s on %s" % (q, name), value="%s (%s)" % (q, name), type="username", sub=name, url=page.format(quote(q)), fields=f,
                    dates=[{"date": j[:10], "title": "%s joined %s" % (q, name)}] if j and re.match(r"\d{4}-", j) else []), None
    with ThreadPoolExecutor(8) as ex:
        res = list(ex.map(one, SITES))
    out = [r[0] for r in res if r[0]]
    errs = [r[1] for r in res if r[1]]
    if out or errs:
        out.append(dict(note="Same name does not mean same person. Checked %d sites, %d with an account.%s" %
                             (len(SITES), len(out), " Could not check: " + "; ".join(errs) if errs else "")))
    return out


DIAL = {"1": "United States, Canada, Caribbean", "7": "Russia, Kazakhstan", "20": "Egypt", "27": "South Africa", "30": "Greece", "31": "Netherlands", "32": "Belgium", "33": "France", "34": "Spain", "36": "Hungary", "39": "Italy, Vatican", "40": "Romania", "41": "Switzerland", "43": "Austria", "44": "United Kingdom", "45": "Denmark", "46": "Sweden", "47": "Norway", "48": "Poland", "49": "Germany", "51": "Peru", "52": "Mexico", "53": "Cuba", "54": "Argentina", "55": "Brazil", "56": "Chile", "57": "Colombia", "58": "Venezuela", "60": "Malaysia", "61": "Australia", "62": "Indonesia", "63": "Philippines", "64": "New Zealand", "65": "Singapore", "66": "Thailand", "81": "Japan", "82": "South Korea", "84": "Vietnam", "86": "China", "90": "Turkey", "91": "India", "92": "Pakistan", "93": "Afghanistan", "94": "Sri Lanka", "95": "Myanmar", "98": "Iran", "211": "South Sudan", "212": "Morocco, Western Sahara", "213": "Algeria", "216": "Tunisia", "218": "Libya", "220": "Gambia", "221": "Senegal", "222": "Mauritania", "223": "Mali", "224": "Guinea", "225": "Côte d'Ivoire", "226": "Burkina Faso", "227": "Niger", "228": "Togo", "229": "Benin", "230": "Mauritius", "231": "Liberia", "232": "Sierra Leone", "233": "Ghana", "234": "Nigeria", "235": "Chad", "236": "Central African Republic", "237": "Cameroon", "238": "Cape Verde", "239": "São Tomé and Príncipe", "240": "Equatorial Guinea", "241": "Gabon", "242": "Congo-Brazzaville", "243": "DR Congo", "244": "Angola", "245": "Guinea-Bissau", "248": "Seychelles", "249": "Sudan", "250": "Rwanda", "251": "Ethiopia", "252": "Somalia", "253": "Djibouti", "254": "Kenya", "255": "Tanzania", "256": "Uganda", "257": "Burundi", "258": "Mozambique", "260": "Zambia", "261": "Madagascar", "262": "Réunion, Mayotte", "263": "Zimbabwe", "264": "Namibia", "265": "Malawi", "266": "Lesotho", "267": "Botswana", "268": "Eswatini", "269": "Comoros", "290": "Saint Helena", "291": "Eritrea", "297": "Aruba", "298": "Faroe Islands", "299": "Greenland", "350": "Gibraltar", "351": "Portugal", "352": "Luxembourg", "353": "Ireland", "354": "Iceland", "355": "Albania", "356": "Malta", "357": "Cyprus", "358": "Finland", "359": "Bulgaria", "370": "Lithuania", "371": "Latvia", "372": "Estonia", "373": "Moldova", "374": "Armenia", "375": "Belarus", "376": "Andorra", "377": "Monaco", "378": "San Marino", "380": "Ukraine", "381": "Serbia", "382": "Montenegro", "383": "Kosovo", "385": "Croatia", "386": "Slovenia", "387": "Bosnia and Herzegovina", "389": "North Macedonia", "420": "Czechia", "421": "Slovakia", "423": "Liechtenstein", "501": "Belize", "502": "Guatemala", "503": "El Salvador", "504": "Honduras", "505": "Nicaragua", "506": "Costa Rica", "507": "Panama", "509": "Haiti", "590": "Guadeloupe", "591": "Bolivia", "592": "Guyana", "593": "Ecuador", "594": "French Guiana", "595": "Paraguay", "596": "Martinique", "597": "Suriname", "598": "Uruguay", "670": "Timor-Leste", "673": "Brunei", "675": "Papua New Guinea", "679": "Fiji", "687": "New Caledonia", "689": "French Polynesia", "850": "North Korea", "852": "Hong Kong", "853": "Macau", "855": "Cambodia", "856": "Laos", "880": "Bangladesh", "886": "Taiwan", "960": "Maldives", "961": "Lebanon", "962": "Jordan", "963": "Syria", "964": "Iraq", "965": "Kuwait", "966": "Saudi Arabia", "967": "Yemen", "968": "Oman", "970": "Palestine", "971": "United Arab Emirates", "972": "Israel", "973": "Bahrain", "974": "Qatar", "975": "Bhutan", "976": "Mongolia", "977": "Nepal", "992": "Tajikistan", "993": "Turkmenistan", "994": "Azerbaijan", "995": "Georgia", "996": "Kyrgyzstan", "998": "Uzbekistan"}


@source("phone", "Phone numbering plan", "on this computer", ["phone"], "People", local=True)
def phone(q, ctx):
    d = re.sub(r"\D", "", q)
    d = d[2:] if d.startswith("00") else d
    for n in (3, 2, 1):
        if d[:n] in DIAL:
            nat = d[n:]
            kind = None
            if d[:n] == "44" and nat[:1] == "7": kind = "UK mobile (or 070 personal number)"
            if d[:n] == "33" and nat[:1] in "67" and nat: kind = "French mobile"
            if d[:n] == "33" and nat[:1] == "9": kind = "French VoIP"
            return [dict(title="+%s %s" % (d[:n], nat), type="phone", value="+" + d, sub=DIAL[d[:n]], url=None,
                         fields=F(("Country code", "+" + d[:n]), ("Region", DIAL[d[:n]]), ("Kind", kind), ("Digits", len(d)),
                                  ("Caution", "A prefix says where the number was issued, not where the holder is")))]
    return []


# ------------------------------------------------------------------ crypto

@source("btc", "Bitcoin ledger", "blockstream.info", ["btc"], "Money")
def btc(q, ctx):
    d = ctx.json("https://blockstream.info/api/address/" + quote(q))
    if not d:
        return []
    s = d["chain_stats"]
    txs = ctx.json("https://blockstream.info/api/address/%s/txs" % quote(q)) or []
    when = [t["status"]["block_time"] for t in txs if t["status"].get("block_time")]
    cp = {}
    for t in txs[:25]:
        outs = [o.get("scriptpubkey_address") for o in t["vout"]]
        ins = [(i.get("prevout") or {}).get("scriptpubkey_address") for i in t["vin"]]
        for a in set(x for x in (outs if q in ins else ins) if x and x != q):
            cp[a] = cp.get(a, 0) + 1
    top = sorted(cp.items(), key=lambda x: -x[1])[:8]
    return [dict(title=q, type="btc", sub="%.8f BTC held" % ((s["funded_txo_sum"] - s["spent_txo_sum"]) / 1e8), url="https://blockstream.info/address/" + q,
                 fields=F(("Received", "%.8f BTC" % (s["funded_txo_sum"] / 1e8)), ("Sent", "%.8f BTC" % (s["spent_txo_sum"] / 1e8)),
                          ("Transactions", s["tx_count"]), ("Latest activity", iso(max(when)) if when else None), ("Counterparties in latest 25", len(cp))),
                 related=[dict(type="btc", title=a, rel="transacted with") for a, _ in top])]


@source("eth", "Ethereum ledger", "eth.blockscout.com", ["eth"], "Money")
def eth(q, ctx):
    d = ctx.json("https://eth.blockscout.com/api/v2/addresses/" + quote(q))
    if not d:
        return []
    t = (ctx.json("https://eth.blockscout.com/api/v2/addresses/%s/transactions" % quote(q)) or {}).get("items", [])
    cp = {}
    for x in t[:40]:
        for s in ("from", "to"):
            a = x.get(s) or {}
            if a.get("hash") and a["hash"].lower() != q.lower():
                cp[a["hash"]] = a.get("name") or a.get("ens_domain_name")
    return [dict(title=d.get("ens_domain_name") or q, type="eth", value=q, sub="%.5f ETH held" % (int(d.get("coin_balance") or 0) / 1e18), url="https://eth.blockscout.com/address/" + q,
                 fields=F(("ENS", d.get("ens_domain_name")), ("Contract", "yes, %s" % (d.get("name") or "unnamed") if d.get("is_contract") else "no"),
                          ("Created by", d.get("creator_address_hash")), ("Tags", [x.get("display_name") for x in d.get("public_tags") or []]),
                          ("Flagged as scam", "yes" if d.get("is_scam") else None), ("Latest activity", (t[0].get("timestamp") or "")[:10] if t else None)),
                 related=[dict(type="eth", title=a, rel="transacted with" + (" (%s)" % n if n else "")) for a, n in list(cp.items())[:8]])]


# ------------------------------------------------------------------ people, companies, general text

WD = {"P569": "Born", "P570": "Died", "P571": "Founded", "P576": "Dissolved", "P27": "Citizenship", "P39": "Position", "P108": "Employer", "P102": "Party", "P69": "Educated at",
      "P112": "Founder", "P127": "Owned by", "P749": "Parent", "P355": "Subsidiary", "P169": "Chief executive", "P488": "Chair", "P159": "Headquarters",
      "P17": "Country", "P625": "Coordinates", "P856": "Website", "P1278": "LEI", "P458": "IMO", "P137": "Operator", "P8047": "Flag", "P176": "Built by", "P585": "Date", "P793": "Significant event", "P19": "Birthplace", "P26": "Spouse", "P463": "Member of", "P1830": "Owner of"}
WD_REL = {"P108": "company", "P112": "person", "P127": "company", "P749": "company", "P355": "company", "P169": "person", "P488": "person", "P159": "place", "P137": "company", "P463": "company", "P1830": "company", "P102": "company"}


def wd_time(v):
    t = v.get("time", "")
    p = v.get("precision", 11)
    m = re.match(r"^\+(\d{4})-(\d\d)-(\d\d)", t)
    if not m:
        return None
    return m[1] if p <= 9 else "%s-%s" % (m[1], m[2]) if p == 10 else "%s-%s-%s" % m.groups()


def wd_details(ids, ctx):
    d = ctx.json("https://www.wikidata.org/w/api.php", {"action": "wbgetentities", "ids": "|".join(ids), "props": "labels|descriptions|claims|aliases|sitelinks", "languages": "en|fr", "format": "json"}) or {}
    ents = d.get("entities", {})
    need = set()
    for e in ents.values():
        for p in WD:
            for c in e.get("claims", {}).get(p, [])[:8]:
                v = (c.get("mainsnak", {}).get("datavalue") or {}).get("value")
                if isinstance(v, dict) and "id" in v:
                    need.add(v["id"])
    need |= {c["mainsnak"]["datavalue"]["value"]["id"] for e in ents.values() for c in e.get("claims", {}).get("P31", [])[:3] if c["mainsnak"].get("datavalue")}
    labels, need = {}, sorted(need)
    for i in range(0, len(need), 50):
        l = ctx.json("https://www.wikidata.org/w/api.php", {"action": "wbgetentities", "ids": "|".join(need[i:i + 50]), "props": "labels", "languages": "en|fr", "format": "json"}) or {}
        for k, v in l.get("entities", {}).items():
            lb = v.get("labels", {})
            labels[k] = (lb.get("en") or lb.get("fr") or {}).get("value", k)
    out = []
    for qid in ids:
        e = ents.get(qid)
        if not e or "missing" in e:
            continue
        lab = lambda k: (e.get(k, {}).get("en") or e.get(k, {}).get("fr") or {}).get("value", "")
        cl = e.get("claims", {})
        p31 = [c["mainsnak"]["datavalue"]["value"]["id"] for c in cl.get("P31", []) if c["mainsnak"].get("datavalue")]
        kinds = " ".join(labels.get(k, "") for k in p31).lower()
        typ = "person" if "Q5" in p31 else "vessel" if "P458" in cl or re.search(r"\bship|vessel", kinds) else \
            "company" if re.search(r"company|business|enterprise|organi[sz]ation|agency|bank|corporation|party|ministry|newspaper|university|group", kinds) or "P1278" in cl else \
            "place" if "P625" in cl else "text"
        fields, rel, dates, lat, lon = [], [], [], None, None
        for p, name in WD.items():
            vals = []
            for c in cl.get(p, [])[:8]:
                v = (c.get("mainsnak", {}).get("datavalue") or {}).get("value")
                if v is None:
                    continue
                if isinstance(v, dict) and "id" in v:
                    s = labels.get(v["id"], v["id"])
                    vals.append(s)
                    if p in WD_REL:
                        rel.append(dict(type=WD_REL[p], title=s, rel=name.lower(), url="https://www.wikidata.org/wiki/" + v["id"]))
                elif isinstance(v, dict) and "time" in v:
                    t = wd_time(v)
                    if t:
                        vals.append(t)
                        dates.append({"date": t, "title": "%s: %s" % (lab("labels"), name.lower())})
                elif isinstance(v, dict) and "latitude" in v:
                    lat, lon = v["latitude"], v["longitude"]
                    vals.append("%.5f, %.5f" % (lat, lon))
                elif isinstance(v, str):
                    vals.append(v)
            if vals:
                fields.append([name, "; ".join(dict.fromkeys(vals))])
        al = [a["value"] for a in e.get("aliases", {}).get("en", [])][:8]
        if al:
            fields.append(["Also known as", ", ".join(al)])
        wp = e.get("sitelinks", {}).get("enwiki", {}).get("title")
        out.append(dict(title=lab("labels") or qid, type=typ, sub=lab("descriptions"), url="https://www.wikidata.org/wiki/" + qid, lat=lat, lon=lon,
                        fields=fields + ([["Wikipedia", "https://en.wikipedia.org/wiki/" + quote(wp.replace(" ", "_"))]] if wp else []), related=rel[:24], dates=dates))
    return out


@source("wikidata", "Wikidata", "wikidata.org", NAMEY + ["vessel", "place", "lei"], "Reference")
def wikidata(q, ctx):
    if re.match(r"^(IMO ?)?\d{7}$", q, re.I):
        s = "haswbstatement:P458=" + re.sub(r"\D", "", q)
    elif re.match(r"^[A-Z0-9]{18}\d\d$", q):
        s = "haswbstatement:P1278=" + q
    else:
        s = None
    if s:
        d = ctx.json("https://www.wikidata.org/w/api.php", {"action": "query", "list": "search", "srsearch": s, "srlimit": "3", "format": "json"}) or {}
        ids = [x["title"] for x in d.get("query", {}).get("search", [])]
    else:
        d = ctx.json("https://www.wikidata.org/w/api.php", {"action": "wbsearchentities", "search": q, "language": "en", "uselang": "en", "format": "json", "limit": "5"}) or {}
        ids = [x["id"] for x in d.get("search", [])]
    return wd_details(ids, ctx) if ids else []


@source("wikipedia", "Wikipedia", "en.wikipedia.org", NAMEY + ["vessel", "place"], "Reference")
def wikipedia(q, ctx):
    d = ctx.json("https://en.wikipedia.org/w/api.php", {"action": "query", "list": "search", "srsearch": q, "srlimit": "6", "format": "json"}) or {}
    return [dict(title=s["title"], type="text", sub=strip(s["snippet"]), url="https://en.wikipedia.org/wiki/" + quote(s["title"].replace(" ", "_")),
                 fields=F(("Last edited", s["timestamp"][:10]))) for s in d.get("query", {}).get("search", [])]


@source("gleif", "Legal entity register (GLEIF)", "api.gleif.org", ["company", "text", "lei"], "Companies")
def gleif(q, ctx):
    p = {"filter[lei]": q} if re.match(r"^[A-Z0-9]{18}\d\d$", q) else {"filter[entity.legalName]": q}
    p["page[size]"] = "8"
    d = ctx.json("https://api.gleif.org/api/v1/lei-records", p) or {}
    out = []
    for r in d.get("data", []):
        a = r["attributes"]
        e = a["entity"]
        ad = lambda x: [*(x.get("addressLines") or []), x.get("city"), x.get("postalCode"), x.get("country")] if x else []
        out.append(dict(title=e["legalName"]["name"], type="company", sub="%s, %s" % (e.get("jurisdiction"), (e.get("status") or "").lower()), url="https://search.gleif.org/#/record/" + a["lei"],
                        fields=F(("LEI", a["lei"]), ("Legal address", ad(e.get("legalAddress"))), ("Headquarters", ad(e.get("headquartersAddress"))), ("Register number", e.get("registeredAs")),
                                 ("Created", (e.get("creationDate") or "")[:10]), ("Former names", [n["name"] for n in e.get("otherNames", [])]), ("LEI status", a["registration"].get("status"))),
                        dates=[{"date": e["creationDate"][:10], "title": "%s incorporated" % e["legalName"]["name"]}] if e.get("creationDate") else []))
    if len(out) == 1:
        for rel, name in (("direct-parent", "direct parent"), ("ultimate-parent", "ultimate parent")):
            try:
                x = ctx.json("https://api.gleif.org/api/v1/lei-records/%s/%s" % (d["data"][0]["id"], rel))
                if x and x.get("data"):
                    out[0].setdefault("related", []).append(dict(type="company", title=x["data"]["attributes"]["entity"]["legalName"]["name"], rel=name))
            except SourceError:
                pass
    return out


@source("frent", "French company register", "recherche-entreprises.api.gouv.fr", ["company", "person", "text", "siren"], "Companies")
def frent(q, ctx):
    d = ctx.json("https://recherche-entreprises.api.gouv.fr/search", {"q": q, "per_page": "6"}, ok=(200, 400)) or {}
    out = []
    for r in d.get("results", []):
        s = r.get("siege") or {}
        ppl = r.get("dirigeants") or []
        nm = lambda p: (p.get("denomination") or " ".join(x for x in [(p.get("prenoms") or "").title(), (p.get("nom") or "").title()] if x)).strip()
        try: lat, lon = float(s.get("latitude")), float(s.get("longitude"))
        except (TypeError, ValueError): lat = lon = None
        out.append(dict(title=r.get("nom_complet"), type="company", sub="SIREN %s, %s" % (r.get("siren"), "active" if r.get("etat_administratif") == "A" else "closed"),
                        url="https://annuaire-entreprises.data.gouv.fr/entreprise/" + str(r.get("siren")), lat=lat, lon=lon,
                        fields=F(("SIREN", r.get("siren")), ("Address", s.get("adresse")), ("Created", r.get("date_creation")), ("Closed", r.get("date_fermeture")), ("Activity code", r.get("activite_principale")),
                                 ("Directors", ["%s (%s)" % (nm(p), p.get("qualite") or "") for p in ppl]), ("Establishments", r.get("nombre_etablissements"))),
                        related=[dict(type="company" if p.get("denomination") else "person", title=nm(p), rel=(p.get("qualite") or "director").lower()) for p in ppl[:12] if nm(p)],
                        dates=[{"date": r["date_creation"], "title": "%s created" % r.get("nom_complet")}] if r.get("date_creation") else []))
    return out


@source("ch", "UK Companies House", "api.company-information.service.gov.uk", ["company", "person", "text"], "Companies", key="companieshouse")
def ch(q, ctx):
    import base64
    h = {"Authorization": "Basic " + base64.b64encode((ctx.key("companieshouse") + ":").encode()).decode()}
    d = ctx.json("https://api.company-information.service.gov.uk/search", {"q": q, "items_per_page": "10"}, headers=h) or {}
    out = []
    for r in d.get("items", []):
        off = "officer" in (r.get("kind") or "")
        out.append(dict(title=r.get("title"), type="person" if off else "company", sub=r.get("description"), url="https://find-and-update.company-information.service.gov.uk" + (r.get("links") or {}).get("self", ""),
                        fields=F(("Number", r.get("company_number")), ("Status", r.get("company_status")), ("Created", r.get("date_of_creation")), ("Address", r.get("address_snippet"))),
                        dates=[{"date": r["date_of_creation"], "title": "%s incorporated" % r.get("title")}] if r.get("date_of_creation") else []))
    return out


@source("edgar", "US filings (SEC EDGAR full text)", "efts.sec.gov", NAMEY, "Companies")
def edgar(q, ctx):
    d = ctx.json("https://efts.sec.gov/LATEST/search-index", {"q": '"%s"' % q.strip('"')}) or {}
    out = []
    for h in d.get("hits", {}).get("hits", [])[:8]:
        s = h["_source"]
        acc, _, doc = h["_id"].partition(":")
        cik = (s.get("ciks") or ["0"])[0].lstrip("0")
        out.append(dict(title="%s: %s" % (s.get("form") or s.get("file_type"), (s.get("display_names") or ["?"])[0]), type="document", sub=s.get("file_date"), date=s.get("file_date"),
                        url="https://www.sec.gov/Archives/edgar/data/%s/%s/%s" % (cik, acc.replace("-", ""), doc), fields=F(("Filed", s.get("file_date")), ("Filers", s.get("display_names")), ("Document", s.get("file_description") or s.get("file_type")))))
    return out


@source("icij", "Offshore Leaks (ICIJ)", "offshoreleaks.icij.org", NAMEY, "Companies")
def icij(q, ctx):
    d = ctx.json("https://offshoreleaks.icij.org/api/v1/reconcile", headers={"Content-Type": "application/json"}, data=json.dumps({"query": q}), ok=(200, 201)) or {}
    return [dict(title=r["name"], type="person" if any("officer" in str(t).lower() for t in r.get("types", r.get("type", []))) else "company",
                 sub=strip(r.get("description") or ""), url=r["id"] if str(r["id"]).startswith("http") else "https://offshoreleaks.icij.org/nodes/%s" % r["id"],
                 fields=F(("Match score", r.get("score")), ("Node types", [t.get("name") if isinstance(t, dict) else t for t in r.get("types", r.get("type", []))]),
                          ("Caution", "Appearing in this database is not evidence of wrongdoing")))
            for r in d.get("result", [])[:8]]


@source("littlesis", "Power networks (LittleSis)", "littlesis.org", NAMEY, "Companies")
def littlesis(q, ctx):
    d = ctx.json("https://littlesis.org/api/entities/search", {"q": q}) or {}
    toks = [t for t in q.lower().split() if len(t) > 2]
    out = []
    for r in d.get("data", []):
        a = r["attributes"]
        if not all(t in (a.get("name", "") + " " + " ".join(a.get("aliases") or [])).lower() for t in toks):
            continue
        out.append(dict(title=a["name"], type="person" if a.get("primary_ext") == "Person" else "company", sub=a.get("blurb"), url=(r.get("links") or {}).get("self") or "https://littlesis.org/entities/%s" % a["id"],
                        fields=F(("Summary", a.get("summary")), ("Types", a.get("types")), ("Start", a.get("start_date")), ("Website", a.get("website")))))
    return out[:6]


@source("sanctions", "Sanctions lists (OFAC, UN, UK)", "on this computer", NAMEY + ["vessel"], "Companies", local=True)
def sanctions(q, ctx):
    import sanctions as S
    n = S.count(ctx.db)
    if not n:
        raise SourceError("lists not downloaded yet (Settings)")
    return [dict(title=r["name"], type=r["type"], sub="%s: %s" % (r["list"], r["program"]), url=r["url"],
                 fields=F(("List", r["list"]), ("Reference", r["uid"]), ("Regime", r["program"]), ("Match", "%d%%" % round(r["score"] * 100)), ("Details", r["detail"]),
                          ("Caution", "A name match is not an identification. Check date of birth, nationality and identifiers"))) for r in S.search(ctx.db, q)]


@source("opensanctions", "OpenSanctions (PEPs and sanctions)", "api.opensanctions.org", NAMEY, "Companies", key="opensanctions")
def opensanctions(q, ctx):
    d = ctx.json("https://api.opensanctions.org/search/default", {"q": q, "limit": "8"}, headers={"Authorization": "ApiKey " + ctx.key("opensanctions")}) or {}
    return [dict(title=r["caption"], type="person" if r["schema"] == "Person" else "company", sub=", ".join(r.get("properties", {}).get("topics", [])), url="https://www.opensanctions.org/entities/%s/" % r["id"],
                 fields=F(*[(k, v) for k, v in r.get("properties", {}).items() if k in ("country", "position", "birthDate", "program", "notes", "alias")])) for r in d.get("results", [])]


@source("aleph", "OCCRP Aleph", "aleph.occrp.org", NAMEY, "Companies", key="aleph")
def aleph(q, ctx):
    d = ctx.json("https://aleph.occrp.org/api/2/entities", {"q": q, "filter:schemata": "Thing", "limit": "10"}, headers={"Authorization": "ApiKey " + ctx.key("aleph")}) or {}
    return [dict(title=(r.get("properties", {}).get("name") or [r.get("caption") or "?"])[0], type="person" if r["schema"] == "Person" else "company" if r["schema"] in ("Company", "Organization", "LegalEntity") else "document",
                 sub=(r.get("collection") or {}).get("label"), url=(r.get("links") or {}).get("ui"), fields=F(("Schema", r["schema"]), ("Dataset", (r.get("collection") or {}).get("label")))) for r in d.get("results", [])]


@source("court", "US courts (CourtListener)", "courtlistener.com", NAMEY, "Law and parliament", key="courtlistener")
def court(q, ctx):
    d = ctx.json("https://www.courtlistener.com/api/rest/v4/search/", {"q": '"%s"' % q}, headers={"Authorization": "Token " + ctx.key("courtlistener")}) or {}
    return [dict(title=r.get("caseName"), type="document", sub=r.get("court"), date=r.get("dateFiled"), url="https://www.courtlistener.com" + (r.get("absolute_url") or ""), fields=F(("Filed", r.get("dateFiled")), ("Docket", r.get("docketNumber")))) for r in d.get("results", [])[:10]]


@source("guardian", "The Guardian archive", "content.guardianapis.com", NAMEY + ["place"], "News", key="guardian")
def guardian(q, ctx):
    d = ctx.json("https://content.guardianapis.com/search", {"q": '"%s"' % q, "api-key": ctx.key("guardian"), "page-size": "10", "order-by": "newest"}) or {}
    return [dict(title=r["webTitle"], type="document", sub=r.get("sectionName"), date=r["webPublicationDate"][:10], url=r["webUrl"], fields=F(("Published", r["webPublicationDate"][:10]))) for r in d.get("response", {}).get("results", [])]


@source("gdelt", "World news, last 3 months (GDELT)", "api.gdeltproject.org", NAMEY + ["place", "vessel"], "News")
def gdelt(q, ctx):
    t = ctx.get("https://api.gdeltproject.org/api/v2/doc/doc", {"query": '"%s"' % q if " " in q else q, "mode": "artlist", "format": "json", "maxrecords": "15", "sort": "datedesc"}, timeout=40)
    try: d = json.loads(t)
    except ValueError: raise SourceError((t or "no answer").strip()[:140])
    return [dict(title=a["title"], type="document", sub="%s, %s" % (a.get("domain"), a.get("sourcecountry")), url=a["url"], date="%s-%s-%s" % (a["seendate"][:4], a["seendate"][4:6], a["seendate"][6:8]),
                 fields=F(("Seen", a["seendate"]), ("Language", a.get("language")))) for a in d.get("articles", [])]


@source("openalex", "Academic work (OpenAlex)", "api.openalex.org", NAMEY, "Reference")
def openalex(q, ctx):
    d = ctx.json("https://api.openalex.org/works", {"search": q, "per-page": "6"}) or {}
    return [dict(title=w.get("title") or "(untitled)", type="document", sub="%s, cited %s times" % (w.get("publication_year"), w.get("cited_by_count")), date=w.get("publication_date"), url=w.get("doi") or w.get("id"),
                 fields=F(("Authors", [a["author"]["display_name"] for a in w.get("authorships", [])[:6]]), ("Open copy", (w.get("open_access") or {}).get("oa_url")))) for w in d.get("results", [])]


@source("members", "UK Parliament members", "members-api.parliament.uk", ["person", "text"], "Law and parliament")
def members(q, ctx):
    d = ctx.json("https://members-api.parliament.uk/api/Members/Search", {"Name": q, "take": "5"}) or {}
    return [dict(title=v["nameDisplayAs"], type="person", sub="%s, %s" % ((v.get("latestParty") or {}).get("name"), (v.get("latestHouseMembership") or {}).get("membershipFrom")),
                 url="https://members.parliament.uk/member/%s" % v["id"], fields=F(("Member since", ((v.get("latestHouseMembership") or {}).get("membershipStartDate") or "")[:10]), ("Full title", v.get("nameFullTitle"))))
            for v in (x["value"] for x in d.get("items", []))]


@source("hansard", "Hansard", "hansard-api.parliament.uk", NAMEY + ["place"], "Law and parliament")
def hansard(q, ctx):
    d = ctx.json("https://hansard-api.parliament.uk/search.json", {"queryParameters.searchTerm": '"%s"' % q, "queryParameters.take": "8", "queryParameters.orderBy": "SittingDateDesc"}, timeout=30) or {}
    out = [dict(title=c.get("DebateSection") or "Contribution", type="document", sub="%s: %s" % (c.get("AttributedTo") or c.get("MemberName"), strip(c.get("ContributionText"))[:240]), date=(c.get("SittingDate") or "")[:10],
                url="https://hansard.parliament.uk/search/Contributions?searchTerm=" + quote(q), fields=F(("House", c.get("House")), ("Date", (c.get("SittingDate") or "")[:10])))
           for c in d.get("Contributions", [])[:8]]
    if out:
        out.append(dict(note="%s contributions in total" % d.get("TotalContributions")))
    return out


# ------------------------------------------------------------------ places, aircraft

@source("nominatim", "Place search (OpenStreetMap)", "nominatim.openstreetmap.org", ["place", "text", "coords"], "Places")
def nominatim(q, ctx):
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$", q)
    if m:
        d = ctx.json("https://nominatim.openstreetmap.org/reverse", {"lat": m[1], "lon": m[2], "format": "jsonv2"}) or {}
        d = [d] if d.get("display_name") else []
    else:
        d = ctx.json("https://nominatim.openstreetmap.org/search", {"q": q, "format": "jsonv2", "limit": "6"}) or []
    return [dict(title=r["display_name"].split(",")[0], type="place", sub=r["display_name"], lat=float(r["lat"]), lon=float(r["lon"]),
                 url="https://www.openstreetmap.org/%s/%s" % (r.get("osm_type"), r.get("osm_id")), fields=F(("Kind", "%s / %s" % (r.get("category"), r.get("type"))), ("Coordinates", "%s, %s" % (r["lat"], r["lon"])))) for r in d]


@source("nearphotos", "Geotagged photos nearby (Commons)", "commons.wikimedia.org", ["coords"], "Places")
def nearphotos(q, ctx):
    lat, lon = [float(x) for x in q.split(",")]
    d = ctx.json("https://commons.wikimedia.org/w/api.php", {"action": "query", "generator": "geosearch", "ggscoord": "%f|%f" % (lat, lon), "ggsradius": "2000", "ggsnamespace": "6", "ggslimit": "20",
                 "prop": "imageinfo|coordinates", "iiprop": "url|extmetadata", "iiurlwidth": "320", "format": "json"}) or {}
    out = []
    for p in (d.get("query") or {}).get("pages", {}).values():
        i, c = (p.get("imageinfo") or [{}])[0], (p.get("coordinates") or [{}])[0]
        m = i.get("extmetadata", {})
        out.append(dict(title=p["title"][5:], type="document", sub=strip((m.get("ImageDescription") or {}).get("value", ""))[:200], url=i.get("descriptionurl"), thumb=i.get("thumburl"), lat=c.get("lat"), lon=c.get("lon"),
                        fields=F(("Taken", strip((m.get("DateTimeOriginal") or {}).get("value", ""))), ("Author", strip((m.get("Artist") or {}).get("value", ""))), ("Licence", (m.get("LicenseShortName") or {}).get("value")))))
    return out


@source("nearwiki", "Places described nearby (Wikipedia)", "en.wikipedia.org", ["coords"], "Places")
def nearwiki(q, ctx):
    lat, lon = [float(x) for x in q.split(",")]
    d = ctx.json("https://en.wikipedia.org/w/api.php", {"action": "query", "list": "geosearch", "gscoord": "%f|%f" % (lat, lon), "gsradius": "10000", "gslimit": "12", "format": "json"}) or {}
    return [dict(title=g["title"], type="place", sub="%d m away" % g["dist"], lat=g["lat"], lon=g["lon"], url="https://en.wikipedia.org/?curid=%s" % g["pageid"], fields=[]) for g in d.get("query", {}).get("geosearch", [])]


@source("aircraft", "Live aircraft (adsb.lol)", "api.adsb.lol", ["aircraft"], "Transport")
def aircraft(q, ctx):
    c = q.strip().replace(" ", "")
    paths = ["hex/" + c.lower()] if re.match(r"^[0-9a-f]{6}$", c, re.I) else ["reg/" + c.upper(), "callsign/" + c.upper()]
    out = []
    for p in paths:
        for a in (ctx.json("https://api.adsb.lol/v2/" + p) or {}).get("ac", []):
            out.append(dict(title=a.get("r") or a["hex"], type="aircraft", sub="%s %s, live now" % (a.get("t", ""), (a.get("flight") or "").strip()), lat=a.get("lat"), lon=a.get("lon"),
                            url="https://globe.adsb.lol/?icao=" + a["hex"], fields=F(("Hex", a["hex"]), ("Registration", a.get("r")), ("Type", a.get("t")), ("Altitude", a.get("alt_baro")), ("Speed (kt)", a.get("gs")), ("Squawk", a.get("squawk")))))
    return out


@source("hexdb", "Aircraft registry (hexdb)", "hexdb.io", ["aircraft"], "Transport")
def hexdb(q, ctx):
    c = q.strip()
    if not re.match(r"^[0-9a-f]{6}$", c, re.I):
        c = (ctx.get("https://hexdb.io/reg-hex", {"reg": c.upper()}) or "").strip()
        if not re.match(r"^[0-9a-f]{6}$", c, re.I):
            return []
    d = ctx.json("https://hexdb.io/api/v1/aircraft/" + c)
    if not d or "ModeS" not in d:
        return []
    return [dict(title=d.get("Registration"), type="aircraft", sub=d.get("Type"), url="https://hexdb.io/hex-reg?hex=" + c, fields=F(("Hex", d["ModeS"]), ("Type", d.get("Type")), ("Manufacturer", d.get("Manufacturer")), ("Owner", d.get("RegisteredOwners"))),
                 related=[dict(type="company", title=d["RegisteredOwners"], rel="registered owner")] if d.get("RegisteredOwners") else [])]


def public_list():
    return [{k: v for k, v in s.items() if k != "fn"} for s in REG]


def run(src, q, settings, db):
    ctx, t0 = Ctx(settings, db), time.time()
    res = dict(id=src["id"], name=src["name"], host=src["host"], group=src["group"], items=[], notes=[], status="ok")
    try:
        for it in src["fn"](q, ctx) or []:
            (res["notes"].append(it["note"]) if "note" in it else res["items"].append(it))
        if not res["items"]:
            res["status"] = "empty"
    except SourceError as e:
        res["status"], res["error"] = "error", str(e)
    except ValueError as e:
        res["status"], res["error"] = "error", "unexpected answer from the source (%s)" % str(e)[:120]
    except Exception as e:
        if type(e).__name__ == "Blocked":
            res["status"], res["error"] = "error", str(e)
            res["ms"] = int((time.time() - t0) * 1000)
            return res, ctx.raw
        res["status"], res["error"] = "error", "unexpected answer from the source (%s)" % type(e).__name__
    res["ms"] = int((time.time() - t0) * 1000)
    return res, ctx.raw
