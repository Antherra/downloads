"""Sends a case to a WordPress site running the Project Antherra plugin. Creates and updates drafts only."""
import base64, json, os, re, socket, urllib.error, urllib.parse, urllib.request

UA = "osint-workbench/1.0"
KIND = "investigation"


class WPError(ValueError):
    pass


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    # following a redirect would hand the password to another address
    def redirect_request(self, *a):
        return None


_open = urllib.request.build_opener(_NoRedirect)


def clean_site(s):
    s = (s or "").strip().rstrip("/")
    if not re.match(r"^https?://", s):
        s = "https://" + s
    u = urllib.parse.urlsplit(s)
    test = os.environ.get("ANTHERRA_TEST_WP") and u.hostname == "127.0.0.1"
    if not u.hostname or u.username or u.query or u.fragment:
        raise WPError("that is not a site address")
    if u.scheme != "https" and not test:
        raise WPError("the site must use https, so the password is never sent in the clear")
    return "%s://%s%s" % (u.scheme, u.netloc, u.path)


def call(cfg, method, path, body=None, headers=None, raw=None):
    url = cfg["site"] + "/wp-json/wp/v2/" + path
    h = {"User-Agent": UA, "Accept": "application/json", "Authorization": "Basic " + base64.b64encode(("%s:%s" % (cfg["user"], cfg["password"])).encode()).decode()}
    data = raw
    if body is not None:
        data, h["Content-Type"] = json.dumps(body).encode(), "application/json"
    h.update(headers or {})
    try:
        with _open.open(urllib.request.Request(url, data=data, headers=h, method=method), timeout=90) as r:
            out = r.read(16 << 20)
    except urllib.error.HTTPError as e:
        out = e.read(1 << 20)
        try:
            j = json.loads(out)
            code, msg = j.get("code", ""), j.get("message", "")
        except ValueError:
            code, msg = "", ""
        if 300 <= e.code < 400:
            raise WPError("the site redirects to %s. Enter that address instead." % (e.headers.get("Location") or "another address").split("/wp-json")[0])
        if e.code == 401:
            raise WPError("WordPress did not accept that username and application password." if code != "rest_not_logged_in" else
                          "WordPress did not see the password. Check it, or ask your host whether a security plugin removes the Authorization header.")
        err = WPError("WordPress answered %d%s" % (e.code, ": " + re.sub("<[^>]+>", "", msg)[:300] if msg else ""))
        err.code = e.code
        raise err
    except (urllib.error.URLError, socket.timeout, OSError) as e:
        raise WPError("could not reach the site (%s)" % getattr(e, "reason", e))
    try:
        return json.loads(out)
    except ValueError:
        raise WPError("the site answered with something other than WordPress data")


def connect(site, user, password):
    if not (user or "").strip() or not (password or "").strip():
        raise WPError("enter the username and the application password")
    cfg = {"site": clean_site(site), "user": user.strip(), "password": re.sub(r"\s+", "", password)}
    me = call(cfg, "GET", "users/me?context=edit")
    cap = me.get("capabilities") or {}
    if not cap.get("edit_posts"):
        raise WPError("that account cannot write posts on this site")
    try:
        call(cfg, "GET", "types/" + KIND)
    except WPError as e:
        if getattr(e, "code", 0) == 404:
            raise WPError("the Project Antherra plugin is not active on this site")
        raise
    cfg.update(name=me.get("name"), upload=bool(cap.get("upload_files")))
    return cfg


def regions(cfg):
    return [r["name"] for r in call(cfg, "GET", "region?per_page=100&_fields=name")]


def _region(cfg, name, warn):
    if not name:
        return []
    for r in call(cfg, "GET", "region?per_page=100&search=" + urllib.parse.quote(name)):
        if r["name"].lower() == name.lower():
            return [r["id"]]
    try:
        return [call(cfg, "POST", "region", {"name": name})["id"]]
    except WPError:
        warn.append("Could not create the region “%s”. Choose one in WordPress." % name)
        return []


def check_existing(cfg, prev, force):
    """Returns the id of a draft we may update, or None to create a new one."""
    if not prev or prev.get("site") != cfg["site"]:
        return None
    try:
        p = call(cfg, "GET", "%s/%d?context=edit&_fields=id,status,modified_gmt" % (KIND, int(prev["id"])))
    except WPError as e:
        if getattr(e, "code", 0) in (404, 410):
            return None
        raise
    if p["status"] == "trash":
        return None
    if p["status"] != "draft":
        raise WPError("That investigation is now “%s” in WordPress, so Antherra will not change it. Edit it there, or start a separate draft." % {"publish": "published", "future": "scheduled", "pending": "pending review"}.get(p["status"], p["status"]))
    if p.get("modified_gmt") != prev.get("modified_gmt") and not force:
        e = WPError("The draft was edited in WordPress after Antherra last sent it.")
        e.conflict = True
        raise e
    return p["id"]


def upload(cfg, m, known):
    """m: {key, sha, name, alt, caption, data}. Pictures already sent are reused."""
    k = known.get(m["sha"])
    if k:
        try:
            call(cfg, "GET", "media/%d?_fields=id" % k["id"])
            return k
        except WPError as e:
            if getattr(e, "code", 0) not in (404, 410):
                raise
    b = base64.b64decode(m["data"], validate=True)
    if b[:3] != b"\xff\xd8\xff" or len(b) > 20 << 20:
        raise WPError("a picture was not a JPEG under 20 MB")
    name = re.sub(r"[^a-z0-9-]+", "-", m["name"].lower()).strip("-")[:60] or "image"
    r = call(cfg, "POST", "media", raw=b, headers={"Content-Type": "image/jpeg", "Content-Disposition": 'attachment; filename="%s.jpg"' % name})
    if m.get("alt") or m.get("caption"):
        call(cfg, "POST", "media/%d" % r["id"], {"alt_text": m.get("alt", ""), "caption": m.get("caption", "")})
    return {"id": r["id"], "url": r["source_url"]}


def send_post(cfg, post, existing, warn):
    body = {"title": post["title"], "content": post["content"], "excerpt": post.get("excerpt", ""), "region": _region(cfg, post.get("region"), warn),
            "meta": {k: str(v) for k, v in (post.get("meta") or {}).items() if k in ("antherra_topic", "antherra_finding", "antherra_authors", "antherra_coords")}}
    if post.get("featured"):
        body["featured_media"] = int(post["featured"])
    if not existing:
        body["status"] = "draft"  # the only status Antherra ever sets
    r = call(cfg, "POST", "%s/%d" % (KIND, existing) if existing else KIND, body)
    if r.get("status") != "draft":
        warn.append("WordPress reports this as “%s”, not a draft. Check it now." % r.get("status"))
    return {"id": r["id"], "modified_gmt": r.get("modified_gmt"), "status": r.get("status"), "link": r.get("link")}
