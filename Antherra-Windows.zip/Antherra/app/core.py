"""Antherra: local investigation workbench. Standard library only. Listens on 127.0.0.1. Started by server.py."""
import argparse, hashlib, html, io, json, mimetypes, os, re, secrets, sqlite3, sys, threading, time, urllib.parse, urllib.request, uuid, zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import connectors as C, imagery as I, net, sanctions as S, update as U, vault, wordpress as W  # noqa: E402

VERSION = U.VERSION
SHELL = int(os.environ.get("ANTHERRA_SHELL", "1"))
HOME = U.home()
CODE = [secrets.token_urlsafe(24)]  # handed only to the window this copy opens, and used once, to choose the first passphrase
HEX = re.compile(r"\b[0-9a-f]{64}\b")
KINDS = ("case", "entity", "link", "event", "evidence", "note", "shape", "finding")
now = lambda: time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
P = lambda *a: os.path.join(HOME, *a)


# ---------------------------------------------------------------- storage

SCHEMA = """
CREATE TABLE IF NOT EXISTS docs(id TEXT PRIMARY KEY, case_id TEXT, kind TEXT, data TEXT, created TEXT, updated TEXT, deleted INT DEFAULT 0);
CREATE INDEX IF NOT EXISTS docs_case ON docs(case_id, deleted);
CREATE TABLE IF NOT EXISTS log(n INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT, ts TEXT, action TEXT, kind TEXT, doc TEXT, detail TEXT, prev TEXT, hash TEXT);
"""
VT = vault.Vault(HOME, SCHEMA)


def db():
    """Use as `with db() as con`: one change at a time, saved encrypted when the block ends. Raises Locked."""
    return VT


def lists():
    """The public sanctions lists. They hold nothing private, so they are not encrypted."""
    con = sqlite3.connect(P("lists.db"), timeout=30)
    con.row_factory = sqlite3.Row
    return con


def init():
    os.makedirs(HOME, mode=0o700, exist_ok=True)
    if os.name != "nt":
        for d in (HOME, P("updates"), P("backups"), P("blobs")):
            if os.path.isdir(d):
                os.chmod(d, 0o700)
    I.CACHE = P("cache")


settings, save_settings, blob_put, blob_get = VT.settings, VT.save_settings, VT.blob_put, VT.blob_get


def link_hash(prev, *parts):
    return hashlib.sha256("\x1f".join([prev or "", *[p or "" for p in parts]]).encode()).hexdigest()


def log(con, case, action, kind="", doc="", detail=""):
    r = con.execute("SELECT hash FROM log WHERE case_id=? ORDER BY n DESC LIMIT 1", (case,)).fetchone()
    prev, ts = (r["hash"] if r else ""), now()
    con.execute("INSERT INTO log(case_id,ts,action,kind,doc,detail,prev,hash) VALUES(?,?,?,?,?,?,?,?)",
                (case, ts, action, kind, doc, detail, prev, link_hash(prev, case, ts, action, kind, doc, detail)))


def verify_log(con, case):
    prev = ""
    rows = con.execute("SELECT * FROM log WHERE case_id=? ORDER BY n", (case,)).fetchall()
    for r in rows:
        if r["prev"] != prev or r["hash"] != link_hash(prev, r["case_id"], r["ts"], r["action"], r["kind"], r["doc"], r["detail"]):
            return {"ok": False, "at": r["n"], "entries": len(rows)}
        prev = r["hash"]
    return {"ok": True, "entries": len(rows), "head": prev}


def out(r):
    d = json.loads(r["data"])
    d.update(id=r["id"], case_id=r["case_id"], kind=r["kind"], created=r["created"], updated=r["updated"])
    return d


def title_of(d):
    return str(d.get("title") or d.get("name") or d.get("text") or d.get("rel") or "")[:120]


def upsert(con, d, quiet=False):
    d = dict(d)
    kind = d.pop("kind", None)
    if kind not in KINDS:
        raise ValueError("unknown kind")
    id, cid = d.pop("id", None) or uuid.uuid4().hex[:12], d.pop("case_id", None)
    d.pop("created", None), d.pop("updated", None)
    if kind == "case":
        cid = id
        if not isinstance(d.get("title"), str) or not d["title"].strip():
            raise ValueError("an investigation needs a headline")
    if not cid:
        raise ValueError("case_id missing")
    if kind != "case" and not con.execute("SELECT 1 FROM docs WHERE id=? AND kind='case'", (cid,)).fetchone():
        raise ValueError("no such case")
    old = con.execute("SELECT * FROM docs WHERE id=?", (id,)).fetchone()
    if old and (old["kind"] != kind or old["case_id"] != cid):
        raise ValueError("id belongs to something else")
    t = now()
    con.execute("INSERT INTO docs VALUES(?,?,?,?,?,?,0) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated=excluded.updated, deleted=0",
                (id, cid, kind, json.dumps(d, ensure_ascii=False), old["created"] if old else t, t))
    if not quiet:
        ch = ""
        if old:
            o = json.loads(old["data"])
            ch = ", ".join(sorted(k for k in set(o) | set(d) if o.get(k) != d.get(k) and not k.startswith("_")))
        if not old or ch:
            log(con, cid, "edited" if old else "added", kind, id, title_of(d) + (" (%s)" % ch if ch else ""))
    return out(con.execute("SELECT * FROM docs WHERE id=?", (id,)).fetchone())


def case_docs(con, cid):
    return [out(r) for r in con.execute("SELECT * FROM docs WHERE case_id=? AND deleted=0 ORDER BY created", (cid,))]


# ---------------------------------------------------------------- live layers for the map

def live(kind, q):
    ctx = C.Ctx(settings())
    n = lambda k: float(q[k])
    if kind == "aircraft":
        import math
        la, lo = (n("s") + n("n")) / 2, (n("w") + n("e")) / 2
        rad = min(250, max(5, 60 * math.hypot(n("n") - n("s"), (n("e") - n("w")) * math.cos(math.radians(la))) / 2))
        d = ctx.json("https://api.adsb.lol/v2/lat/%.4f/lon/%.4f/dist/%d" % (la, lo, rad)) or {}
        return [dict(lat=a["lat"], lon=a["lon"], title=(a.get("flight") or a.get("r") or a["hex"]).strip(), type="aircraft", heading=a.get("track"), url="https://globe.adsb.lol/?icao=" + a["hex"],
                     fields=C.F(("Hex", a["hex"]), ("Registration", a.get("r")), ("Type", a.get("t")), ("Altitude", a.get("alt_baro")), ("Speed (kt)", a.get("gs")))) for a in d.get("ac", []) if "lat" in a]
    if kind == "quakes":
        d = ctx.json("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojson") or {}
        return [dict(lat=f["geometry"]["coordinates"][1], lon=f["geometry"]["coordinates"][0], title=f["properties"]["title"], type="quake", url=f["properties"]["url"], date=C.iso(f["properties"]["time"] / 1000),
                     fields=C.F(("Magnitude", f["properties"]["mag"]), ("Depth (km)", f["geometry"]["coordinates"][2]))) for f in d.get("features", [])]
    if kind == "hazards":
        d = ctx.json("https://eonet.gsfc.nasa.gov/api/v3/events", {"status": "open", "limit": "300"}, timeout=40) or {}
        res = []
        for e in d.get("events", []):
            g = (e.get("geometry") or [None])[-1]
            if g and g["type"] == "Point":
                res.append(dict(lat=g["coordinates"][1], lon=g["coordinates"][0], title=e["title"], type="hazard", url=(e["sources"] or [{}])[0].get("url") or e["link"], date=g["date"][:10],
                                fields=C.F(("Kind", [c["title"] for c in e["categories"]]), ("Seen", g["date"][:10]))))
        return res
    if kind == "photos":
        return [dict(i) for i in C.nearphotos("%f,%f" % (n("lat"), n("lon")), ctx) if i.get("lat")]
    raise ValueError("unknown layer")


def weather(q):
    d = C.Ctx({}).json("https://archive-api.open-meteo.com/v1/archive", {"latitude": float(q["lat"]), "longitude": float(q["lon"]), "start_date": q["date"], "end_date": q["date"],
                       "hourly": "temperature_2m,precipitation,cloud_cover,wind_speed_10m,wind_direction_10m,snow_depth", "timezone": "auto"}, ok=(200, 400)) or {}
    if d.get("error"):
        raise ValueError(d.get("reason"))
    return d


CARTO = {"dark": "dark_all", "light": "light_all", "voyager": "rastertiles/voyager"}


def carto_tile(style, z, x, y):
    """Tiles for still maps, and CARTO's, pass through here so the API key stays out of the page."""
    if style == "osm" and z.isdigit() and x.isdigit() and re.match(r"^\d{1,7}\.png$", y):
        url = "https://tile.openstreetmap.org/%s/%s/%s" % (z, x, y)
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": C.UA}), timeout=20) as r:
                return r.read(4 << 20)
        except Exception:
            return None
    key = (settings().get("keys") or {}).get("carto")
    m = re.match(r"^(\d{1,7})(@2x)?\.png$", y)
    if not key or style not in CARTO or not m or not (z.isdigit() and x.isdigit()):
        return None
    url = "https://basemaps.cartocdn.com/%s/%s/%s/%s.png?key=%s" % (CARTO[style], z, x, m[1] + (m[2] or ""), urllib.parse.quote(key, safe=""))
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": C.UA}), timeout=20) as r:
            return r.read(4 << 20)
    except Exception:
        return None  # never report the address: it contains the key


def wp_status():
    w = settings().get("wp")
    return {k: w.get(k) for k in ("site", "user", "name", "upload")} if w else {}


def wp_publish(req):
    """Pictures first, then the post. What was sent is recorded at each step, so a failed try can be repeated without duplicates."""
    cfg = settings().get("wp")
    if not cfg:
        raise ValueError("connect to WordPress first")
    cid, warn = req["case_id"], []

    def remember(**kw):
        with db() as con:
            r = con.execute("SELECT * FROM docs WHERE id=? AND kind='case'", (cid,)).fetchone()
            if not r:
                raise ValueError("no such case")
            d = out(r)
            w = dict(d.get("wp") or {})
            if w.get("site") != cfg["site"]:
                w = {"site": cfg["site"]}
            w.update(kw)
            d["wp"] = w
            return upsert(con, d, quiet=True)
    with db() as con:
        row = con.execute("SELECT * FROM docs WHERE id=? AND kind='case'", (cid,)).fetchone()
    if not row:
        raise ValueError("no such case")
    prev = json.loads(row["data"]).get("wp") or {}
    if prev.get("site") != cfg["site"]:
        prev = {}
    existing = W.check_existing(cfg, prev if prev.get("id") and not req.get("separate") else None, req.get("force"))
    media, post = dict(prev.get("media") or {}), dict(req["post"])
    if req.get("media") and not cfg.get("upload"):
        raise ValueError("that WordPress account cannot upload pictures; untick them or use another account")
    for m in req.get("media") or []:
        media[m["sha"]] = r = W.upload(cfg, m, media)
        remember(media=media)
        post["content"] = post["content"].replace('"@id:%s"' % m["key"], str(r["id"])).replace("@url:%s" % m["key"], r["url"].replace("--", "\\u002d\\u002d").replace("&", "\\u0026"))
        if post.get("featured") == m["key"]:
            post["featured"] = r["id"]
    if "@url:" in post["content"] or '"@id:' in post["content"]:
        raise ValueError("a picture is missing from the draft")
    res = W.send_post(cfg, post, existing, warn)
    edit = "%s/wp-admin/post.php?post=%d&action=edit" % (cfg["site"], res["id"])
    case = remember(id=res["id"], modified_gmt=res["modified_gmt"], edit=edit, at=now())
    with db() as con:
        log(con, cid, "sent draft", "case", cid, "%s %s, %d pictures" % (edit, "updated" if existing else "created", len(req.get("media") or [])))
    return {"edit": edit, "updated": bool(existing), "warnings": warn, "case": case}


# ---------------------------------------------------------------- capture, export, import

def capture(cid, url):
    r = net.safe_fetch(url)
    sha = blob_put(r["body"])
    ctype = r["headers"].get("content-type", "application/octet-stream")
    title, text = "", ""
    if "html" in ctype:
        m = re.search(rb"charset=[\"']?([\w-]+)", r["body"][:2048])
        try:
            page = r["body"].decode(m[1].decode() if m else "utf-8", "replace")
        except LookupError:
            page = r["body"].decode("utf-8", "replace")
        title, text = net.text_of(page[:4 << 20])
    arch = None
    try:
        a = C.Ctx({}).json("https://archive.org/wayback/available", {"url": url}, timeout=10) or {}
        arch = ((a.get("archived_snapshots") or {}).get("closest") or {}).get("url")
    except C.SourceError:
        pass
    return dict(kind="evidence", case_id=cid, title=title or url, url=url, final_url=r["url"], http=r["status"], sha256=sha, size=len(r["body"]), mime=ctype, headers=r["headers"], text=text,
                            captured=r["at"], truncated=r["truncated"], archive=arch, how="web capture", status="unverified", grade="F6")


def export_zip(con, cid):
    docs = case_docs(con, cid)
    lg = [dict(r) for r in con.execute("SELECT case_id,ts,action,kind,doc,detail,prev,hash FROM log WHERE case_id=? ORDER BY n", (cid,))]
    buf, man = io.BytesIO(), {}
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        def put(n, b):
            z.writestr(n, b)
            man[n] = hashlib.sha256(b).hexdigest()
        put("case.json", json.dumps({"antherra": VERSION, "exported": now(), "case": cid, "docs": docs, "log": lg}, ensure_ascii=False, indent=1).encode())
        for sha in sorted({d[k] for d in docs for k in ("sha256", "raw_sha") if d.get(k)} | {x["record"] for d in docs for x in d.get("scenes") or [] if x.get("record")}):
            b = blob_get(sha)
            if b is not None:
                put("blobs/" + sha, b)
        z.writestr("SHA256SUMS", "".join("%s  %s\n" % (h, n) for n, h in man.items()))
    return buf.getvalue()


def import_zip(con, data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        if sum(i.file_size for i in z.infolist()) > 2 * 1024 ** 3:
            raise ValueError("archive is too large")
        j = json.loads(z.read("case.json"))
        for n in z.namelist():
            m = re.match(r"^blobs/([0-9a-f]{64})$", n)
            if m:
                b = z.read(n)
                if hashlib.sha256(b).hexdigest() != m[1]:
                    raise ValueError("an evidence file does not match its hash: %s" % m[1][:16])
                blob_put(b)
    # fresh ids, so importing never overwrites a case you already have
    ids = {d["id"]: uuid.uuid4().hex[:12] for d in j["docs"]}
    swap = lambda v: ids.get(v, v) if isinstance(v, str) else [swap(x) for x in v] if isinstance(v, list) else {k: swap(x) for k, x in v.items()} if isinstance(v, dict) else v
    docs = sorted((swap(d) for d in j["docs"]), key=lambda d: d["kind"] != "case")
    for d in docs:
        d.pop("wp", None)  # an imported copy must never update the original's draft
        upsert(con, d, quiet=True)
    cid = ids[j["case"]]
    log(con, cid, "imported", "case", cid, "%d items, from an export made %s; original log had %d entries, head %s" % (len(docs), j.get("exported"), len(j.get("log", [])), (j["log"][-1]["hash"][:16] if j.get("log") else "none")))
    return cid


# ---------------------------------------------------------------- http

CSP = ("default-src 'self'; img-src 'self' data: blob: https://server.arcgisonline.com https://tile.openstreetmap.org "
       "https://upload.wikimedia.org https://thumb.wikimedia.org; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")


RESTART = []

# ---------------------------------------------------------------- sessions: they end when Antherra locks, and live only in memory

IDLE = 10  # minutes
SESS, SLOCK, SEEN = {}, threading.Lock(), [time.monotonic()]
FAILS = [0, 0.0]
TRY = threading.Lock()


def session(t, view=False):
    hit = False
    with SLOCK:
        for tok, v in SESS.items():  # always compares every one
            hit |= secrets.compare_digest((v if view else tok).encode(), t.encode("utf-8", "replace"))
    if hit and not view:
        SEEN[0] = time.monotonic()
    return hit


def start_session():
    t, v = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
    with SLOCK:
        SESS[t] = v
    SEEN[0] = time.monotonic()
    return {"token": t, "view": v}


def lock_now():
    with SLOCK:
        SESS.clear()
    I.forget()
    VT.close()


def idle():
    """Locks when no window has asked for anything for a while. The open page also locks itself when nobody touches it."""
    while True:
        time.sleep(5)
        try:
            if VT.unlocked and time.monotonic() - SEEN[0] > 60 * (settings().get("lock_minutes") or IDLE) + 30:
                lock_now()
        except vault.Locked:
            pass


def attempt(fn):
    """One guess at a time, and slower after each wrong one."""
    with TRY:
        wait = FAILS[1] - time.monotonic()
        if wait > 0:
            raise ValueError("Too many wrong tries. Wait %d seconds." % (wait + 1))
        try:
            r = fn()
        except vault.BadSecret:
            FAILS[0] += 1
            if FAILS[0] >= 3:
                FAILS[1] = time.monotonic() + min(300, 2 ** (FAILS[0] - 1))
            raise
        FAILS[:] = [0, 0.0]
        return r


class H(BaseHTTPRequestHandler):
    server_version = "Antherra"
    sys_version = ""
    timeout = 120

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json", extra=None):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        if "Cache-Control" not in (extra or {}):
            self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def fail(self, code, msg):
        self.send(code, {"error": msg})

    def guard(self, path):
        """Only this app's own window, after the passphrase, may reach anything private. Blocks other sites, other programs, other accounts and DNS rebinding."""
        h = self.headers
        port = self.server.server_address[1]
        if (h.get("Host") or "") not in ("127.0.0.1:%d" % port, "localhost:%d" % port):
            self.fail(403, "wrong host")
            return False
        if h.get("Sec-Fetch-Site", "none") not in ("none", "same-origin") or (h.get("Origin") or "http://" + h["Host"]) != "http://" + h["Host"]:
            self.fail(403, "wrong origin")
            return False
        if path.startswith("/open/"):  # state, setup and unlock: a header no other site can send
            if h.get("X-Antherra") != "1":
                self.fail(403, "not allowed")
                return False
            return True
        if path.startswith(("/api/", "/blob/", "/tile/")):
            if not VT.unlocked:
                self.fail(423, "Antherra is locked")
                return False
            t, view = h.get("X-Antherra-Token") or "", False
            if not t and self.command == "GET" and path.startswith(("/blob/", "/tile/")):  # pictures cannot send headers; their key opens nothing else
                t, view = (urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("t") or [""])[0], True
            if not session(t, view):
                self.fail(423, "Antherra is locked")
                return False
        return True

    def body(self, limit=1024 ** 3):
        n = int(self.headers.get("Content-Length") or 0)
        if n < 0 or n > limit:
            raise ValueError("too large")
        return self.rfile.read(n)

    def do_GET(self): self.route("GET")
    def do_POST(self): self.route("POST")
    def do_PUT(self): self.route("PUT")
    def do_DELETE(self): self.route("DELETE")

    def route(self, m):
        u = urllib.parse.urlsplit(self.path)
        path, q = urllib.parse.unquote(u.path), {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        api = path.startswith(("/api/", "/blob/", "/tile/"))
        try:
            if not self.guard(path):
                return
            if path.startswith("/open/"):
                self.open(m, path)
            elif api:
                self.api(m, [x for x in path.split("/") if x], q)
            elif m == "GET":
                self.static(path)
            else:
                self.fail(405, "no")
        except (BrokenPipeError, ConnectionResetError):
            pass
        except (ValueError, KeyError, net.Blocked, C.SourceError) as e:
            self.fail(400, str(e))
        except (TypeError, AttributeError, IndexError) as e:
            sys.stderr.write("bad request on %s: %s\n" % (path, type(e).__name__))
            self.fail(400, "that request was not understood")
        except vault.Locked:
            self.fail(423, "Antherra is locked")
        except Exception as e:
            sys.stderr.write("error on %s: %s\n" % (path, type(e).__name__))
            self.fail(500, "internal error: %s" % type(e).__name__)

    def open(self, m, path):
        """The only calls that work before the passphrase. They reveal whether one is set, and nothing else."""
        if m == "GET" and path == "/open/state":
            U.set_state(trying=None, fails=0)  # a page loaded and asked: this version works
            return self.send(200, {"set": VT.exists, "legacy": not VT.exists and VT.legacy, "version": VERSION, "min": vault.MIN})
        if m != "POST":
            return self.fail(404, "no such call")
        r = json.loads(self.body(1 << 14))
        if path == "/open/setup":
            if not CODE or not isinstance(r.get("code"), str) or not secrets.compare_digest(r["code"].encode(), CODE[0].encode()):
                raise ValueError("Set the passphrase in the window Antherra opened. Close Antherra and open it again.")
            rec = VT.create(r.get("passphrase"))
            CODE.clear()
            return self.send(200, {**start_session(), "recovery": rec})
        if path == "/open/unlock":
            attempt(lambda: VT.unlock(passphrase=str(r.get("passphrase") or "")))
            return self.send(200, start_session())
        if path == "/open/recover":  # sets a new passphrase, so a used code is replaced at once
            def go():
                VT.secret(code=str(r.get("recovery") or ""))
                w = vault.weak(r.get("passphrase"))
                if w:
                    raise ValueError(w)
                VT.unlock(code=r["recovery"])
                return VT.rekey(r["passphrase"], code=r["recovery"])
            rec = attempt(go)
            return self.send(200, {**start_session(), "recovery": rec})
        self.fail(404, "no such call")

    def static(self, path):
        if path in ("/", "/index.html"):
            with open(os.path.join(HERE, "web", "index.html"), encoding="utf-8") as f:
                page = f.read().replace("__VERSION__", VERSION)  # nothing secret is in the page itself
            return self.send(200, page.encode(), "text/html; charset=utf-8", {"Content-Security-Policy": CSP, "X-Frame-Options": "DENY", "Cross-Origin-Opener-Policy": "same-origin",
                             "Permissions-Policy": "camera=(), microphone=(), geolocation=(), usb=(), serial=(), payment=(), display-capture=()"})
        root = os.path.join(HERE, "web")
        full = os.path.realpath(os.path.join(root, path.lstrip("/")))
        if not full.startswith(os.path.realpath(root) + os.sep) or not os.path.isfile(full):
            return self.fail(404, "not found")
        with open(full, "rb") as f:
            t = {".js": "text/javascript", ".css": "text/css", ".html": "text/html", ".woff2": "font/woff2", ".svg": "image/svg+xml"}.get(os.path.splitext(full)[1]) or mimetypes.guess_type(full)[0] or "application/octet-stream"
            self.send(200, f.read(), t + ("; charset=utf-8" if t.startswith("text/") else ""))

    def blob(self, sha, q):
        b = blob_get(sha)
        if b is None:
            return self.fail(404, "no such file")
        t = q.get("type", "application/octet-stream")
        # captured pages are shown as plain text only, and nothing from the web runs in the app's origin
        t = t if re.match(r"^(image/(png|jpeg|gif|webp|bmp|avif|heic)|video/(mp4|webm|quicktime)|audio/[\w.+-]+|application/pdf)$", t) else "text/plain; charset=utf-8" if t.startswith(("text/", "application/json", "application/xhtml")) else "application/octet-stream"
        x = {"Content-Security-Policy": "sandbox; default-src 'none'"}
        if q.get("dl"):
            x["Content-Disposition"] = "attachment; filename*=UTF-8''" + urllib.parse.quote(q["dl"], safe="")
        self.send(200, b, t, x)

    def lookup(self, req):
        q, typ, ids, cid = req["q"].strip()[:300], req.get("type"), req.get("sources") or [], req.get("case_id")
        srcs = [s for s in C.REG if s["id"] in ids]
        if not q or not srcs:
            raise ValueError("nothing to look up")
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        st = settings()
        wl = threading.Lock()

        def job(s):
            con = lists()
            try:
                res, raw = C.run(s, q, st, con)
            finally:
                con.close()
            res["at"] = now()
            if raw:
                res["raw_sha"] = blob_put(json.dumps({"query": q, "source": s["name"], "retrieved": res["at"], "responses": raw}, ensure_ascii=False, indent=1).encode())
            return res
        with ThreadPoolExecutor(10) as ex:
            done = []
            for f in as_completed([ex.submit(job, s) for s in srcs]):
                r = f.result()
                done.append(r)
                try:
                    with wl:
                        self.wfile.write(json.dumps(r, ensure_ascii=False).encode() + b"\n")
                        self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    break
        if cid:
            with db() as con:
                if con.execute("SELECT 1 FROM docs WHERE id=?", (cid,)).fetchone():
                    log(con, cid, "looked up", typ or "", "", "%s: %s" % (q, ", ".join("%s %s" % (r["id"], len(r["items"]) if r["status"] != "error" else "failed") for r in done)))

    def update(self, m, what):
        s = settings()
        info = s.get("update_info") or {}
        if m == "GET":
            st = U._state()
            if info.get("version") and U.vtuple(info["version"]) <= U.vtuple(VERSION):
                info = {}
            ready = next((v for v in sorted((x for x in os.listdir(U.udir()) if re.match(r"^\d{1,4}(\.\d{1,4}){1,3}$", x)), key=U.vtuple, reverse=True) if v not in st.get("bad", []) and U.vtuple(v) > U.vtuple(VERSION)), None) if os.path.isdir(U.udir()) else None
            return self.send(200, {"version": VERSION, "on": bool(U.feed()), "page": "https://github.com/" + U.UPDATE_REPO if U.UPDATE_REPO else None, "check": s.get("updates_check", True), "last": s.get("update_at"), "info": info, "ready": ready, "bad": st.get("bad", []), "why": st.get("why") if st.get("bad") else None})
        if what == "check":
            s["update_at"] = now()  # recorded first, so a failed check also waits a day before the next one
            save_settings(s)
            res, _ = U.check(SHELL)
            s = settings()
            s["update_info"] = res
            save_settings(s)
            return self.send(200, res)
        if what == "install":
            return self.send(200, {"version": U.install(SHELL)["version"]})
        if what == "restart":
            self.send(200, {"ok": True})
            RESTART.append(True)
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return None
        self.fail(404, "no such call")

    def api(self, m, p, q):
        if p[0] == "blob":
            return self.blob(p[1], q)
        if p[0] == "tile":
            if p[1:2] and p[1] in ("pc", "wb", "gibs"):
                r = I.tile(p[1:])
                return self.send(200, r[1], r[0] if r[0].startswith("image/") else "application/octet-stream", {"Cache-Control": "no-store"}) if r else self.fail(404, "no tile")
            b = carto_tile(*p[1:5]) if len(p) == 5 else None
            return self.send(200, b, "image/png", {"Cache-Control": "no-store"}) if b else self.fail(404, "no tile")
        a = p[1]
        if m == "POST" and a == "lock":
            lock_now()
            return self.send(200, {"ok": True})
        if m == "POST" and a == "passphrase":
            r = json.loads(self.body(1 << 14))
            rec = attempt(lambda: VT.rekey(r.get("new"), passphrase=str(r.get("old") or "")))
            with SLOCK:  # other open windows must unlock again
                mine = self.headers.get("X-Antherra-Token")
                for k in [k for k in SESS if k != mine]:
                    del SESS[k]
            return self.send(200, {"recovery": rec})
        if m == "POST" and a == "lookup":
            return self.lookup(json.loads(self.body(1 << 20)))
        if m == "GET" and a == "live":
            return self.send(200, live(p[2], q))
        if m == "GET" and a == "weather":
            return self.send(200, weather(q))
        if a == "geocode":
            return self.send(200, C.nominatim(q["q"], C.Ctx({})))
        if a == "settings":
            s = settings()
            if m == "PUT":
                new = json.loads(self.body(1 << 20))
                keys = s.get("keys") or {}
                for k, v in (new.get("keys") or {}).items():
                    if v == "":
                        keys.pop(k, None)
                    elif v:
                        keys[k] = v
                s["keys"] = keys
                if "updates_check" in new:
                    s["updates_check"] = bool(new["updates_check"])
                if "off" in new:
                    s["off"] = new["off"]
                if new.get("theme") in ("light", "dark"):
                    s["theme"] = new["theme"]
                if "lock_minutes" in new:
                    s["lock_minutes"] = max(1, min(240, int(new["lock_minutes"])))
                save_settings(s)
            con = lists()
            have = con.execute("SELECT list, count(*) n FROM sanctions GROUP BY list").fetchall() if S.count(con) else []
            con.close()
            # key values never travel back to the page
            return self.send(200, {"keys": {k: True for k in s.get("keys") or {}}, "off": s.get("off") or [], "home": HOME, "theme": s.get("theme"), "lock_minutes": s.get("lock_minutes") or IDLE, "version": VERSION, "sources": C.public_list(),
                                   "sanctions": {r["list"]: r["n"] for r in have}, "sanctions_report": s.get("sanctions_report")})
        if m == "GET" and a == "imagery":
            return self.send(200, {"search": I.search, "wayback": I.wayback, "clarity": I.clarity, "wbcheck": I.wbcheck, "fires": lambda x: I.fires(x, (settings().get("keys") or {}).get("firms"))}[p[2]](q))
        if m == "POST" and a == "scene":
            r = json.loads(self.body(1 << 16))
            return self.send(200, {"sha": blob_put(json.dumps({"retrieved": now(), "url": r["url"], "record": json.loads(I.record(r["url"]) or "null")}, indent=1).encode())})
        if a == "update":
            return self.update(m, p[2] if len(p) > 2 else "")
        if a == "wp":
            if m == "GET":
                return self.send(200, wp_status())
            if m == "PUT":
                r = json.loads(self.body(1 << 16))
                cfg = W.connect(r.get("site"), r.get("user"), r.get("password"))
                s = settings()
                s["wp"] = cfg
                save_settings(s)
                return self.send(200, wp_status())
            if m == "DELETE":
                s = settings()
                s.pop("wp", None)
                save_settings(s)
                return self.send(200, {})
            if m == "POST":
                try:
                    return self.send(200, wp_publish(json.loads(self.body(400 << 20))))
                except W.WPError as e:
                    if getattr(e, "conflict", False):
                        return self.send(200, {"conflict": str(e)})
                    raise
        if m == "GET" and a == "wpregions":
            return self.send(200, W.regions(settings()["wp"]) if settings().get("wp") else [])
        if m == "POST" and a == "sanctions":
            con = lists()
            rep = S.update(con)
            con.close()
            s = settings()
            s["sanctions_report"] = rep
            save_settings(s)
            return self.send(200, rep)
        if m == "POST" and a == "capture":
            r = json.loads(self.body(1 << 20))
            doc = capture(r["case_id"], r["url"])  # slow network part stays outside the lock
            with db() as con:
                d = upsert(con, doc)
            return self.send(200, d)
        with db() as con:
            if a == "cases" and m == "GET":
                res = []
                for r in con.execute("SELECT * FROM docs WHERE kind='case' AND deleted=0 ORDER BY updated DESC").fetchall():
                    d = out(r)
                    d["counts"] = {x["kind"]: x["n"] for x in con.execute("SELECT kind, count(*) n FROM docs WHERE case_id=? AND deleted=0 GROUP BY kind", (d["id"],))}
                    last = con.execute("SELECT max(ts) t FROM log WHERE case_id=?", (d["id"],)).fetchone()["t"]
                    d["touched"] = last or d["updated"]
                    d["points"] = [[e["lat"], e["lon"]] for e in (json.loads(x["data"]) for x in con.execute("SELECT data FROM docs WHERE case_id=? AND deleted=0 AND kind IN ('entity','event','evidence')", (d["id"],))) if e.get("lat") is not None and e.get("lon") is not None][:60]
                    d["questions"] = [x["title"] for x in (json.loads(y["data"]) for y in con.execute("SELECT data FROM docs WHERE case_id=? AND deleted=0 AND kind='note' ORDER BY created DESC", (d["id"],))) if not x.get("done") and x.get("title")]
                    res.append(d)
                return self.send(200, sorted(res, key=lambda d: d["touched"], reverse=True))
            if a == "recent" and m == "GET":
                return self.send(200, [dict(r) for r in con.execute("SELECT log.case_id, log.ts, log.action, log.kind, log.detail FROM log JOIN docs ON docs.id=log.case_id AND docs.kind='case' AND docs.deleted=0 ORDER BY log.n DESC LIMIT 9")])
            if a == "case" and m == "GET":
                return self.send(200, case_docs(con, p[2]))
            if a == "case" and m == "DELETE":
                mine = set(HEX.findall(" ".join(r["data"] for r in con.execute("SELECT data FROM docs WHERE case_id=?", (p[2],)))))
                con.execute("DELETE FROM docs WHERE case_id=?", (p[2],))
                con.execute("DELETE FROM log WHERE case_id=?", (p[2],))
                for r in con.execute("SELECT data FROM docs"):  # files another case also uses are kept
                    mine -= set(HEX.findall(r["data"]))
                VT.after += [lambda x=sha: VT.blob_del(x) for sha in mine]
                return self.send(200, {"ok": True, "files": len(mine)})
            if a == "doc" and m == "PUT":
                return self.send(200, upsert(con, json.loads(self.body(64 << 20))))
            if a == "batch" and m == "POST":
                return self.send(200, [upsert(con, d) for d in json.loads(self.body(64 << 20))])
            if a == "doc" and m == "DELETE":
                r = con.execute("SELECT * FROM docs WHERE id=? AND kind!='case'", (p[2],)).fetchone()
                if r:
                    con.execute("UPDATE docs SET deleted=1, updated=? WHERE id=?", (now(), p[2]))
                    log(con, r["case_id"], "removed", r["kind"], r["id"], title_of(json.loads(r["data"])))
                    if r["kind"] == "entity":
                        for l in con.execute("SELECT * FROM docs WHERE case_id=? AND kind='link' AND deleted=0", (r["case_id"],)).fetchall():
                            d = json.loads(l["data"])
                            if r["id"] in (d.get("a"), d.get("b")):
                                con.execute("UPDATE docs SET deleted=1 WHERE id=?", (l["id"],))
                                log(con, r["case_id"], "removed", "link", l["id"], "with " + title_of(json.loads(r["data"])))
                return self.send(200, {"ok": True})
            if a == "restore" and m == "POST":
                r = con.execute("SELECT * FROM docs WHERE id=?", (p[2],)).fetchone()
                con.execute("UPDATE docs SET deleted=0 WHERE id=?", (p[2],))
                log(con, r["case_id"], "restored", r["kind"], r["id"], title_of(json.loads(r["data"])))
                return self.send(200, out(r))
            if a == "log" and m == "GET":
                return self.send(200, {"check": verify_log(con, p[2]), "rows": [dict(r) for r in con.execute("SELECT * FROM log WHERE case_id=? ORDER BY n DESC LIMIT 2000", (p[2],))]})
            if a == "upload" and m == "POST":
                b = self.body()
                sha = blob_put(b)
                mime = self.headers.get("Content-Type") or "application/octet-stream"
                return self.send(200, upsert(con, dict(kind="evidence", case_id=q["case"], title=q.get("name") or "Untitled file", filename=q.get("name"), sha256=sha, size=len(b), mime=mime,
                                                       captured=now(), how="file added", status="unverified", grade="F6")))
            if a == "verify" and m == "POST":
                r = con.execute("SELECT * FROM docs WHERE id=?", (p[2],)).fetchone()
                d = json.loads(r["data"])
                b = blob_get(d.get("sha256"))
                ok = b is not None and hashlib.sha256(b).hexdigest() == d["sha256"]
                log(con, r["case_id"], "re-hashed", "evidence", r["id"], "%s: %s" % (title_of(d), "matches" if ok else "DOES NOT MATCH" if b is not None else "file missing"))
                return self.send(200, {"ok": ok, "missing": b is None})
            if a == "export" and m == "POST":
                c = con.execute("SELECT * FROM docs WHERE id=? AND kind='case'", (p[2],)).fetchone()
                name = re.sub(r"[^\w-]+", "-", json.loads(c["data"]).get("title", "case")).strip("-").lower()[:60] or "case"
                pw = json.loads(self.body(1 << 16)).get("passphrase")
                if pw and vault.weak(pw):
                    raise ValueError(vault.weak(pw))
                log(con, p[2], "exported", "case", p[2], "case archive" + (", protected by a passphrase" if pw else ", NOT protected"))
                z = export_zip(con, p[2])
                return self.send(200, vault.seal_archive(z, pw) if pw else z, "application/octet-stream", {"X-Filename": name + (".antherra" if pw else ".antherra.zip")})
            if a == "import" and m == "POST":
                data = self.body()
                if data.startswith(vault.MAGIC):
                    pw = urllib.parse.unquote(self.headers.get("X-Passphrase") or "")
                    if not pw:
                        return self.send(400, {"error": "This archive needs its passphrase.", "need": "passphrase"})
                    data = vault.open_archive(data, pw)
                try:
                    return self.send(200, {"id": import_zip(con, data)})
                except (zipfile.BadZipFile, KeyError):
                    raise ValueError("that is not an Antherra case archive")
        self.fail(404, "no such call")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8321)
    ap.add_argument("--open", action="store_true", help="open the default browser")
    ap.add_argument("--watch-stdin", action="store_true", help="exit when the parent app closes")
    a = ap.parse_args()
    init()
    ThreadingHTTPServer.request_queue_size = 128  # the default of 5 drops connections when a page loads
    ThreadingHTTPServer.daemon_threads = True
    ThreadingHTTPServer.allow_reuse_address = os.name != "nt"  # on Windows this would let two copies share a port
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", a.port), H)
    except OSError:
        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)  # taken, perhaps by another copy: use any free port
    url = "http://127.0.0.1:%d/" % srv.server_address[1]
    if not VT.exists:
        url += "#k=" + CODE[0]
    print("READY " + url, flush=True)
    threading.Thread(target=idle, daemon=True).start()
    if a.watch_stdin:
        threading.Thread(target=lambda: (sys.stdin.read(), os._exit(0)), daemon=True).start()
    if a.open:
        import webbrowser
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    srv.server_close()
    VT.close()
    return (75, srv.server_address[1]) if RESTART else None
