"""Local copies of the OFAC, UN and UK sanctions lists, searched without sending names anywhere."""
import csv, io, re, time, unicodedata, urllib.request
import xml.etree.ElementTree as ET
from difflib import SequenceMatcher

URLS = {"OFAC": "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN.CSV",
        "OFAC aliases": "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/ALT.CSV",
        "UN": "https://scsanctions.un.org/resources/xml/en/consolidated.xml",
        "UK": "https://sanctionslist.fcdo.gov.uk/docs/UK-Sanctions-List.csv"}
DDL = "CREATE TABLE IF NOT EXISTS sanctions(list TEXT, uid TEXT, name TEXT, norm TEXT, type TEXT, program TEXT, detail TEXT, url TEXT)"


def norm(s):
    s = unicodedata.normalize("NFKD", s or "")
    return re.sub(r"[^a-z0-9]+", " ", "".join(c for c in s if not unicodedata.combining(c)).lower()).strip()


def fetch(u):
    with urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "osint-workbench/1.0"}), timeout=180) as r:
        return r.read()


def _typ(t):
    t = (t or "").lower()
    return "person" if "individual" in t else "vessel" if "ship" in t or "vessel" in t else "aircraft" if "aircraft" in t else "company"


def rows_ofac(sdn, alt):
    c = lambda x: "" if x.strip() == "-0-" else x.strip()
    main = {}
    for r in csv.reader(io.StringIO(sdn.decode("utf-8", "replace"))):
        if len(r) < 12:
            continue
        rec = ("OFAC", r[0], c(r[1]), _typ(c(r[2])) if c(r[2]) else "company", c(r[3]).replace("] [", ", "), c(r[11]), "https://sanctionssearch.ofac.treas.gov/Details.aspx?id=" + r[0])
        main[r[0]] = rec
        yield rec
    for r in csv.reader(io.StringIO(alt.decode("utf-8", "replace"))):
        if len(r) >= 4 and r[0] in main:
            m = main[r[0]]
            yield (m[0], m[1], c(r[3]), m[3], m[4], "Alias of %s. %s" % (m[2], m[5]), m[6])


def rows_un(raw):
    root = ET.fromstring(raw)
    for tag, typ in (("INDIVIDUAL", "person"), ("ENTITY", "company")):
        for e in root.iter(tag):
            t = lambda k: (e.findtext(k) or "").strip()
            name = " ".join(x for x in (t("FIRST_NAME"), t("SECOND_NAME"), t("THIRD_NAME"), t("FOURTH_NAME")) if x)
            ref, prog, det = t("REFERENCE_NUMBER"), t("UN_LIST_TYPE"), t("COMMENTS1")
            url = "https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list"
            yield ("UN", ref, name, typ, prog, det, url)
            for a in e.iter(tag + "_ALIAS"):
                al = (a.findtext("ALIAS_NAME") or "").strip()
                if al:
                    yield ("UN", ref, al, typ, prog, "Alias of %s. %s" % (name, det), url)


def rows_uk(raw):
    rd = csv.reader(io.StringIO(raw.decode("utf-8-sig", "replace")))
    for hdr in rd:
        if "Unique ID" in hdr:
            break
    ix = {h: i for i, h in enumerate(hdr)}
    seen = set()
    for r in rd:
        if len(r) < len(hdr):
            continue
        g = lambda k: r[ix[k]].strip()
        name = " ".join(x for x in [g("Name %d" % i) for i in (1, 2, 3, 4, 5, 6)] if x)
        k = (g("Unique ID"), name)
        if not name or k in seen:
            continue
        seen.add(k)
        det = "; ".join(x for x in [g("Name type"), g("D.O.B") and "born " + g("D.O.B"), g("Nationality(/ies)"), g("Position"), g("IMO number") and "IMO " + g("IMO number"), g("Other Information")[:1500]] if x)
        yield ("UK", k[0], name, _typ(g("Designation Type")), g("Regime Name"), det, "https://search-uk-sanctions-list.service.gov.uk/")


def update(con):
    """Downloads each list separately: one failing source never wipes another's rows."""
    con.execute(DDL)
    report = {}
    jobs = {"OFAC": lambda: rows_ofac(fetch(URLS["OFAC"]), fetch(URLS["OFAC aliases"])), "UN": lambda: rows_un(fetch(URLS["UN"])), "UK": lambda: rows_uk(fetch(URLS["UK"]))}
    for name, job in jobs.items():
        try:
            rows = [(a, b, n, norm(n), t, p, d[:4000], u) for a, b, n, t, p, d, u in job()]
            if len(rows) < 100:
                raise ValueError("list looked empty")
            con.execute("DELETE FROM sanctions WHERE list=?", (name,))
            con.executemany("INSERT INTO sanctions VALUES(?,?,?,?,?,?,?,?)", rows)
            con.commit()
            report[name] = {"rows": len(rows), "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        except Exception as e:
            con.rollback()
            report[name] = {"error": str(e)[:200]}
    return report


def count(con):
    con.execute(DDL)
    return con.execute("SELECT count(*) FROM sanctions").fetchone()[0]


def search(con, q, limit=12):
    con.execute(DDL)
    nq = norm(q)
    toks = [t for t in nq.split() if len(t) > 1]
    if not toks:
        return []
    cols = "list,uid,name,norm,type,program,detail,url"
    imo = re.match(r"^(?:imo )?(\d{7})$", nq)
    if imo:
        rows = con.execute("SELECT %s FROM sanctions WHERE detail LIKE ?" % cols, ("%" + imo[1] + "%",)).fetchall()
        return [dict(zip(cols.split(","), r), score=1.0) for r in rows[:limit]]
    long = sorted(toks, key=len, reverse=True)[:3]
    rows = con.execute("SELECT %s FROM sanctions WHERE %s" % (cols, " OR ".join(["norm LIKE ?"] * len(long))), ["%" + t[:max(3, len(t) - 1)] + "%" for t in long]).fetchall()
    best = {}
    for r in rows:
        rec = dict(zip(cols.split(","), r))
        a, b = " ".join(sorted(toks)), " ".join(sorted(rec["norm"].split()))
        s = SequenceMatcher(None, a, b).ratio()
        if len(toks) > 1 and all(t in rec["norm"].split() for t in toks):
            s = max(s, 0.92)
        elif len(toks) == 1 and toks[0] in rec["norm"].split():
            s = max(s, 0.8)
        if s < 0.78:
            continue
        rec["score"] = s
        k = (rec["list"], rec["uid"])
        if k not in best or best[k]["score"] < s:
            best[k] = rec
    return sorted(best.values(), key=lambda r: -r["score"])[:limit]
