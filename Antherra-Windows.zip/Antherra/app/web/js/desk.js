import { h, svg, S, get, post, api, save, saveAll, remove, all, form, btn, empty, fmt, stamp, tag, STATUS, go, caseUrl, confirmBox, dialog, toast, pickFile, today, coord, guard, oops, changed, isDate } from './core.js';
import { sample } from './sample.js';
import { still, fillMap } from './static.js';
import { banner } from './update.js';
import { exportCase, openArchive } from './archive.js';

const CASE = [{ k: 'title', label: 'Headline', req: true, full: true, spell: true, ph: 'Who owns the ferry fleet?' }, { k: 'desk', label: 'Desk or region', ph: 'Indian Ocean' }, { k: 'state', label: 'State', type: 'select', options: ['ongoing', 'verified', 'published', 'closed'] }, { k: 'standfirst', label: 'What are we trying to establish?', type: 'area', full: true, spell: true }, { k: 'byline', label: 'Reporters', full: true }];
export const editCase = async c => { const v = await form(c ? 'Edit investigation' : 'New investigation', CASE, c || { state: 'ongoing' }, c ? 'Save' : 'Start'); if (v) return save({ ...(c || {}), kind: 'case', ...v }); };

const meta = c => [c.desk, c.state].filter(Boolean).join(' · ');
const tally = c => [['entity', 'entities', 'entity'], ['event', 'events', 'event'], ['evidence', 'exhibits', 'exhibit']].map(([k, many, one]) => [c.counts[k] || 0, (c.counts[k] || 0) === 1 ? one : many]);
export function desk(box) {
  const upd = banner(); let map = null, q = '';
  const create = btn('New investigation', async () => { const c = await editCase(); if (c) go(`#/case/${c.id}/overview`); }, 'primary', 'plus'), open = btn('Open case archive', async () => { const id = await openArchive(); if (id) go(`#/case/${id}/overview`); }), smp = btn('Load the sample case', async () => { const id = await sample(); go(`#/case/${id}/overview`); });
  const draw = guard(async () => {
    const [cases, recent] = await Promise.all([get('/api/cases'), get('/api/recent')]), [lead, ...rest] = cases, name = Object.fromEntries(cases.map(c => [c.id, c.title]));
    map?.stop(); map = fillMap(lead?.points || []);
    if (!lead) return box.replaceChildren(h('section.hero.bare', map, h('div.hero-in', h('span.label', 'Project Antherra'), h('h1', 'Start with a question'), h('p', 'Evidence-led reporting from open sources. Open an investigation and everything you look up, map, date and preserve is kept with it.'), h('div.row', create, open, smp))), h('div.page', upd, h('div.howgrid', [['Look up', 'Registers, archives and networks, all at once.'], ['Map and date', 'Places, satellite scenes and a timeline that shows its gaps.'], ['Preserve', 'Pages and files, fingerprinted as they were.'], ['Verify', 'Light, weather, metadata and hidden dates.']].map(([a, b]) => h('div.step', h('b', a), h('span.mute', b))))));
    const L = `#/case/${lead.id}/`, carto = S.settings?.keys?.carto;
    const hero = h('section.hero', map, h('div.hero-in', h('span.label', meta(lead) || 'Investigation'), h('h1', { class: lead.title.length > 52 ? 'long' : '' }, h('a', { href: L + 'overview' }, lead.title)), lead.standfirst && h('p', lead.standfirst),
      h('div.row', h('a.button.primary', { href: L + 'overview' }, 'Open investigation'), [['lookup', 'Look up'], ['map', 'Map'], ['timeline', 'Timeline']].map(([k, n]) => h('a.button.ghost', { href: L + k }, n))),
      h('div.hero-foot', h('span.dot', fmt(lead.touched.slice(0, 10))), tally(lead).some(x => x[0]) ? tally(lead).filter(x => x[0]).map(([n, w]) => h('span', h('b', n), ' ', w)) : h('span', 'Nothing filed yet'))), lead.points?.length ? h('span.credit', carto ? '© OpenStreetMap © CARTO' : '© OpenStreetMap contributors') : null);
    const list = h('ul.index'), rows = () => { const hit = rest.filter(c => !q || [c.title, c.desk, c.state, c.standfirst].join(' ').toLowerCase().includes(q)); list.replaceChildren(...hit.map(c => h('li', h('a', { href: `#/case/${c.id}/overview` }, h('span.dot', fmt(c.touched.slice(0, 10))), h('span.grow', h('span.label', meta(c)), h('h3', c.title), h('span.sub', tally(c).filter(x => x[0]).map(x => x.join(' ')).join(', ') || 'Nothing filed yet')), c.points?.length ? still(c.points, 264, 176) : null))), hit.length ? '' : h('li', h('p.mute', { style: { padding: '18px 0' } }, rest.length ? 'No investigation matches that.' : 'This is your only investigation so far. Others will be listed here, most recently worked on first.'))); };
    rows();
    const asks = cases.flatMap(c => (c.questions || []).slice(0, 4).map(t => [c, t])).slice(0, 7), kind = { note: 'question', evidence: 'exhibit', shape: 'map area' }, say = r => r.kind === 'case' ? ({ added: 'Started this investigation', edited: 'Changed the case details', imported: 'Opened from an archive', exported: 'Exported the case', 'sent draft': 'Sent a draft to WordPress' }[r.action] || r.action) : r.action === 'looked up' ? 'Looked up ' + r.detail.replace(/: [^:]*$/, '') : r.kind === 'link' && !r.detail ? r.action + ' a link' : `${r.action === 're-hashed' ? 'Checked' : r.action[0].toUpperCase() + r.action.slice(1)} ${kind[r.kind] || r.kind}: ${r.detail.replace(/ \([\w, ]+\)$/, '').slice(0, 90)}`;
    box.replaceChildren(hero, h('div.page', upd, h('div.frontcols', h('section', h('div.sechead', h('h2', 'Investigations'), h('div.row', rest.length > 6 ? h('input', { placeholder: 'Filter', 'aria-label': 'Filter investigations', oninput: e => { q = e.target.value.trim().toLowerCase(); rows(); } }) : null, create, open)), list, !cases.some(c => c.sample) ? h('div', { style: { paddingTop: '18px' } }, smp) : null),
      h('aside', h('div.sechead', h('h2', 'Open questions')), asks.length ? h('ul.lines', asks.map(([c, t]) => h('li', h('a', { href: `#/case/${c.id}/overview` }, t), cases.length > 1 && h('small', c.title)))) : h('p.mute', { style: { padding: '14px 0' } }, 'None outstanding. Add them on a case’s Overview.'),
        h('div.sechead', { style: { marginTop: '34px' } }, h('h2', 'Recent work')), recent.length ? h('ul.lines', recent.map(r => h('li', h('div.row.between', { style: { flexWrap: 'nowrap', alignItems: 'baseline' } }, h('a.grow', { href: `#/case/${r.case_id}/log` }, say(r)), h('span.dot.mute', fmt(r.ts.slice(0, 10)).slice(0, 5))), cases.length > 1 && h('small', name[r.case_id])))) : h('p.mute', { style: { padding: '14px 0' } }, 'Nothing yet.')))));
  });
  draw(); return { cleanup: () => map?.stop() };
}

export function how(box) {
  const steps = [['Ask', 'Write the question as the case headline.'], ['Collect', 'Look up names, sites, numbers and places. Each answer keeps its source, time and raw response.'], ['Preserve', 'Capture pages and files before they change. Each gets a SHA-256 fingerprint.'], ['Map', 'Place it, date it and link it.'], ['Verify', 'Check light, weather, metadata and earlier copies. Grade source and claim separately.'], ['Publish', 'Export findings with the evidence behind them.']];
  box.replaceChildren(h('div.page.narrow', h('div.pagehead', h('div', h('h1', 'How we work'))),
    h('div.howgrid', steps.map(([a, b], i) => h('div.step', h('span.dot', '0' + (i + 1)), h('b', a), h('span.mute', b)))),
    h('div.stack', { style: { marginTop: '36px' } }, h('h2', 'What leaves this computer'),
      h('p', 'Cases, evidence and keys stay on this computer, encrypted with your passphrase. A lookup sends your search term to the sources you tick, and each one is listed with its host. Sources marked “contacts the target” visit the site you are investigating, which may show your IP address in its logs. Once a day Antherra asks GitHub whether there is a new version, unless you turn that off in Settings. Map tiles come from OpenStreetMap, Esri and NASA (and, under Imagery, Microsoft Planetary Computer, which is sent the place and dates you search), and from CARTO if you add a key. They can see the area you view. Previews on the Investigations and Overview pages load map tiles too.'),
      h('h2', { style: { marginTop: '18px' } }, 'What a result means'),
      h('p', 'Everything from a lookup is filed as unverified. A name match is not an identification, an IP location is not a person’s location, and appearing in a leak or register is not wrongdoing. Change a status only when you could explain why in print.'),
      h('h2', { style: { marginTop: '18px' } }, 'Grades'), h('p', 'Evidence carries a two-part grade: A to F for the source’s reliability, 1 to 6 for the claim’s credibility. They are judged separately, because a reliable source can be wrong and an unreliable one right.'))));
}

export function overview(box) {
  const draw = () => {
    const c = S.case, n = k => all(k).length, findings = all('finding'), leads = all('note');
    const pts = [...all('entity'), ...all('event'), ...all('evidence')].filter(d => d.lat != null);
    const F = [{ k: 'title', label: 'Finding', type: 'area', rows: 3, req: true, full: true, spell: true, ph: 'One sentence you could print' }, { k: 'status', label: 'Status', type: 'select', options: STATUS }, { k: 'basis', label: 'Basis', full: true, type: 'area', rows: 2, hint: 'Which evidence supports it, and what could be wrong' }];
    const editF = async f => { const v = await form(f ? 'Edit finding' : 'Add a finding', F, f || { status: 'unverified' }); if (v) save({ ...(f || {}), kind: 'finding', ...v }); };
    const inp = h('input', { placeholder: 'Add an open question', 'aria-label': 'Add an open question', spellcheck: 'true' });
    const acts = h('ul.lines');
    get('/api/log/' + c.id).then(r => acts.replaceChildren(...r.rows.slice(0, 8).map(x => h('li', h('div.row.between', h('span', { style: { overflowWrap: 'anywhere' }, class: 'grow' }, `${x.action} ${x.kind}`.trim() + ': ', h('span', { style: { color: 'var(--ink)' } }, x.detail.slice(0, 110))), h('span.dot.mute', fmt(x.ts.slice(0, 16)))))))).catch(oops);
    box.replaceChildren(h('div.page',
      h('div.cols', h('div',
        h('span.label', [c.desk, c.state].filter(Boolean).join(' · ')), h('h1', { style: { margin: '8px 0 12px' } }, c.title), c.standfirst && h('p', { style: { fontSize: '18px', fontWeight: 500, maxWidth: '62ch' } }, c.standfirst), c.byline && h('p.mute', { style: { marginTop: '10px' } }, c.byline),
        c.sample && h('p.mute', { style: { marginTop: '10px' } }, 'Sample case, compiled from public reporting to show the tools. Check every entry before relying on it.'),
        h('div.stats', [['entity', 'entities', 'Entities'], ['link', 'links', 'Links'], ['event', 'timeline', 'Events'], ['evidence', 'evidence', 'Evidence']].map(([k, v, l]) => h('a', { href: caseUrl(v) }, h('b', n(k)), l))),
        h('div.tint', h('div.row.between', { style: { marginBottom: '6px' } }, h('h2', 'Findings'), btn('Add finding', () => editF(), 'small', 'plus')),
          findings.length ? h('ul.lines', findings.map(f => h('li', h('div.row.between', { style: { alignItems: 'flex-start', flexWrap: 'nowrap' } }, h('div.grow', h('p', { style: { fontSize: '17px', color: 'var(--tint-ink)' } }, f.title), f.basis && h('small', f.basis)), tag(f.status)), h('div.row', { style: { marginTop: '6px' } }, btn('Edit', () => editF(f), 'link small'), btn('Remove', () => remove(f), 'link small'))))) : h('p.mute', 'What you can say so far, and how sure you are. Findings open the report.')),
      ), h('div.stack', { style: { gap: '28px' } },
        h('div', h('a', { href: caseUrl('map'), 'aria-label': 'Open the map', style: { display: 'block' } }, still(pts.map(p => [p.lat, p.lon])))),
        h('div', h('h2', 'Open questions'), h('form.row', { style: { margin: '10px 0 8px', flexWrap: 'nowrap' }, onsubmit: guard(async e => { e.preventDefault(); if (inp.value.trim()) await save({ kind: 'note', title: inp.value.trim(), done: false }); }) }, inp, h('button', 'Add')),
          h('ul.lines', leads.sort((a, b) => a.done - b.done).map(l => h('li', h('div.row', { style: { flexWrap: 'nowrap' } }, h('input', { type: 'checkbox', checked: !!l.done, 'aria-label': 'Answered', onchange: guard(e => save({ ...l, done: e.target.checked })) }), h('span.grow', { style: l.done ? { textDecoration: 'line-through', color: 'var(--muted)' } : {} }, l.title), btn('Remove', () => remove(l), 'link small')))))),
        h('div', h('h2', { style: { marginBottom: '10px' } }, 'Recent work'), acts),
        h('div.row', btn('Edit details', () => editCase(S.case)), btn('Export case', () => exportCase(c)),
          btn('Delete case', async () => {
            const i = h('input', { autofocus: true }); const ok = await dialog('Delete this investigation?', h('div.stack', h('p', 'This permanently deletes its entities, links, events, evidence files and log. Encrypted copies made before updates, in the backups folder, may still hold its records. Export it first if you may need it. Type the headline to confirm.'), h('code', S.case.title), i), [{ label: 'Keep it' }, { label: 'Delete permanently', primary: true, danger: true, fn: () => { if (i.value.trim() !== S.case.title.trim()) { i.style.borderColor = 'var(--bad)'; return false; } return true; } }]);
            if (ok) { await api('DELETE', '/api/case/' + S.case.id); S.case = null; go('#/'); }
          }, 'quiet'))))));
  };
  draw(); return { refresh: draw };
}
