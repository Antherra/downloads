// EXIF from JPEG (and TIFF/PNG eXIf/WebP blocks), plus a look for content credentials and XMP. Returns {tags, gps, date, notes}.
const T = { 0x10f: 'Camera make', 0x110: 'Camera model', 0x112: 'Orientation', 0x131: 'Software', 0x132: 'File modified', 0x13b: 'Artist', 0x10e: 'Description', 0x8298: 'Copyright', 0x9003: 'Taken', 0x9004: 'Digitised', 0x9010: 'Time zone', 0x9011: 'Time zone (taken)', 0x829a: 'Exposure', 0x829d: 'Aperture', 0x8827: 'ISO', 0x920a: 'Focal length', 0xa002: 'Width', 0xa003: 'Height', 0xa433: 'Lens make', 0xa434: 'Lens', 0xa431: 'Body serial', 0xa435: 'Lens serial', 0xa430: 'Owner', 0x9286: 'Comment', 0xa405: 'Focal length (35 mm)' };
const SZ = [0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8];
export function exif(buf) {
  const d = new DataView(buf), u8 = new Uint8Array(buf), out = { tags: [], gps: null, date: null, notes: [] }, txt = (o, n) => String.fromCharCode(...u8.subarray(o, o + n));
  let base = -1;
  try {
    if (d.getUint16(0) === 0xffd8) { let p = 2; while (p < d.byteLength - 10) { if (u8[p] !== 0xff) break; const m = u8[p + 1], L = d.getUint16(p + 2); if (m === 0xe1 && txt(p + 4, 4) === 'Exif') { base = p + 10; break; } if (m === 0xda) break; p += 2 + L; } }
    else if (txt(0, 2) === 'II' || txt(0, 2) === 'MM') base = 0;
    else if (txt(1, 3) === 'PNG') { let p = 8; while (p < d.byteLength - 8) { const L = d.getUint32(p), t = txt(p + 4, 4); if (t === 'eXIf') { base = p + 8; break; } if (t === 'tEXt') out.tags.push(['PNG text', txt(p + 8, Math.min(L, 300)).replace('\0', ': ')]); p += 12 + L; } }
    else if (txt(8, 4) === 'WEBP') { let p = 12; while (p < d.byteLength - 8) { const L = d.getUint32(p + 4, true); if (txt(p, 4) === 'EXIF') { base = p + 8 + (txt(p + 8, 4) === 'Exif' ? 6 : 0); break; } p += 8 + L + (L % 2); } }
    if (base >= 0) {
      const le = d.getUint16(base) === 0x4949, g = {}, seen = new Set();
      const val = (type, n, o) => { if (type === 2) return new TextDecoder().decode(u8.subarray(o, o + n)).replace(/\0.*$/s, '').trim(); const r = []; for (let i = 0; i < Math.min(n, 16); i++) { const q = o + i * SZ[type]; r.push(type === 3 ? d.getUint16(q, le) : type === 4 ? d.getUint32(q, le) : type === 9 ? d.getInt32(q, le) : type === 5 ? d.getUint32(q, le) / d.getUint32(q + 4, le) : type === 10 ? d.getInt32(q, le) / d.getInt32(q + 4, le) : u8[q]); } return n === 1 ? r[0] : r; };
      const ifd = (o, gps) => { if (seen.has(o) || o + base + 2 > d.byteLength) return; seen.add(o); const n = d.getUint16(base + o, le); for (let i = 0; i < Math.min(n, 400); i++) { const e = base + o + 2 + i * 12, id = d.getUint16(e, le), ty = d.getUint16(e + 2, le), c = d.getUint32(e + 4, le); if (!SZ[ty]) continue; const at = SZ[ty] * c > 4 ? base + d.getUint32(e + 8, le) : e + 8; if (at + SZ[ty] * Math.min(c, 16) > d.byteLength) continue; if (id === 0x8769 || id === 0x8825) { ifd(d.getUint32(e + 8, le), id === 0x8825); continue; } const v = val(ty, c, at); if (gps) g[id] = v; else if (T[id] && v !== '') out.tags.push([T[id], id === 0x829a && v < 1 ? `1/${Math.round(1 / v)} s` : id === 0x829d ? 'f/' + v : id === 0x920a ? v + ' mm' : String(Array.isArray(v) ? v.join(' ') : v)]); if (!gps && id === 0x9003) out.date = String(v).replace(/^(\d{4}):(\d\d):(\d\d) (\d\d:\d\d).*/, '$1-$2-$3T$4'); } };
      ifd(d.getUint32(base + 4, le));
      const deg = (v, r) => { const x = v[0] + v[1] / 60 + v[2] / 3600; return /[SW]/.test(r) ? -x : x; };
      if (Array.isArray(g[2]) && Array.isArray(g[4])) { const a = deg(g[2], g[1] || ''), b = deg(g[4], g[3] || ''); if (isFinite(a) && isFinite(b) && (a || b)) out.gps = [+a.toFixed(6), +b.toFixed(6)]; }
      if (g[29]) out.tags.push(['GPS date', g[29]]); if (g[17] != null) out.tags.push(['Camera bearing', (+g[17]).toFixed(1) + '°']); if (g[6] != null) out.tags.push(['Altitude', (+g[6]).toFixed(1) + ' m']);
    }
  } catch (e) { out.notes.push('Metadata is damaged or cut short.'); }
  const s = new TextDecoder('latin1').decode(u8.subarray(0, Math.min(u8.length, 3e6)));
  if (/c2pa|jumbf/.test(s)) out.notes.push('Contains a content credentials (C2PA) block. Check it at contentcredentials.org/verify.');
  const x = /<x:xmpmeta[\s\S]*?<\/x:xmpmeta>/.exec(s); if (x) { const t = /CreatorTool[=">]+([^"<]+)/.exec(x[0]); if (t) out.tags.push(['Created with (XMP)', t[1]]); if (/DigitalSourceType[^>]*trainedAlgorithmicMedia/.test(x[0])) out.notes.push('Metadata declares this as made by generative AI.'); const h = (x[0].match(/stEvt:action/g) || []).length; if (h) out.tags.push(['Edit history entries', String(h)]); }
  if (/Adobe Photoshop/.test(s)) out.notes.push('Mentions Adobe Photoshop: saved by it at some point, which is not proof of manipulation.');
  if (!out.tags.length && !out.gps) out.notes.push('No camera metadata. Social platforms strip it, so absence proves nothing.');
  return out;
}
