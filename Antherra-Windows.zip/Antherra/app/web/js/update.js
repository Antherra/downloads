import { h, get, post, putj, btn, fmt, stamp, toast, ext, dialog, oops, confirmBox } from './core.js';
let state = null, busy = false;
export const load = async () => state = await get('/api/update');
// Once a day, quietly. A failure here is never worth interrupting anyone for.
export async function daily() { try { await load(); if (state.on && state.check && (!state.last || Date.now() - Date.parse(state.last) > 864e5)) { await post('/api/update/check'); await load(); } } catch (e) { console.warn(e); } return state; }
async function restart() {
  if (!await confirmBox('Restart Antherra?', 'It closes and reopens by itself in a few seconds. Anything typed but not saved is lost.', 'Restart')) return;
  await post('/api/update/restart'); document.body.replaceChildren(h('div.page', h('h1', 'Restarting'), h('p.mute', 'Antherra is starting the new version.')));
  for (let i = 0; i < 60; i++) { await new Promise(r => setTimeout(r, 700)); try { const r = await fetch('/', { cache: 'no-store' }); if (r.ok) { location.reload(); return; } } catch { } }
  document.body.replaceChildren(h('div.page', h('h1', 'Please reopen Antherra'), h('p', 'It did not come back by itself. Close it and open it again. Your cases are safe.')));
}
async function install(done) {
  if (busy) return; const i = state.info;
  if (!await dialog(`Antherra ${i.version}`, h('div.stack', h('p.dot', fmt(i.released || '')), h('p', { style: { whiteSpace: 'pre-wrap' } }, i.notes || 'No notes were given.'), h('p', h('small', 'The update is checked against its digital signature before it is used. Your cases, evidence and keys stay where they are, and an encrypted copy of the records is made first.'))), [{ label: 'Not now' }, { label: 'Install', primary: true }])) return;
  busy = true; try { toast('Downloading'); await post('/api/update/install'); await load(); done(); await restart(); } finally { busy = false; }
}
const rd = draw => state.ready ? h('div.row', h('span', `Antherra ${state.ready} is ready. It starts next time you open Antherra.`), btn('Restart now', restart, 'small primary')) : state.info?.newer ? h('div.row', h('span', `Antherra ${state.info.version} is available.`), state.info.full ? ext(state.info.page, 'This one needs a full download') : btn('See what’s new', () => install(draw), 'small primary')) : null;
export function banner() { const b = h('div'); const draw = () => { const r = state?.on || state?.ready ? rd(draw) : null; b.replaceChildren(r ? h('div.tint', { style: { margin: '0 0 22px', padding: '14px 20px' } }, r) : ''); }; daily().then(draw); return b; }
export function section() {
  const b = h('div'); const draw = () => {
    const s = state; b.replaceChildren(h('p.mute', { style: { margin: '6px 0 12px' } }, `You have version ${s.version}. `, s.on ? 'Checking contacts GitHub, which sees your IP address but nothing about your cases. Nothing installs unless you choose it. Antherra is shared by invitation: if a check finds nothing, new versions are on the download page, which opens only for people who were invited and are signed in to GitHub.' : 'This copy has no update address, so it never checks.'),
      s.bad.length ? h('p.err', { style: { margin: '0 0 12px' } }, `Version ${s.bad.join(', ')} could not be used here, so Antherra went back to ${s.version}. ${s.why || ''}`) : '', rd(draw) || '',
      s.on ? h('div.row', { style: { margin: '12px 0 0' } }, h('label.row', { style: { gap: '8px' } }, h('input', { type: 'checkbox', checked: s.check, onchange: async e => { try { await putj('/api/settings', { updates_check: e.target.checked }); await load(); } catch (x) { oops(x); } } }), 'Check once a day'), s.page && ext(s.page, 'Open the download page', 'button small'), btn('Check now', async () => { const r = await post('/api/update/check'); await load(); draw(); if (!r.newer) toast('You have the newest version.'); }, 'small'), s.last && h('small', 'Last checked ', h('span.dot', stamp(s.last)))) : '');
  }; load().then(draw).catch(oops); return b;
}
