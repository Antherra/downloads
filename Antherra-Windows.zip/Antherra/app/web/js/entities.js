import { h, S, all, fmt, tag, tname, TYPES, btn, empty, icon, norm, download, slug, saveAll, pickFile, toast, STATUS } from './core.js';
import { openDoc, editEntity, typeTag } from './drawer.js';
import { csv, parseCsv, importRows } from './io.js';
export function entities(box) {
  let q = '', type = '', sort = 'title', dir = 1;
  const list = h('div'), sel = h('select', { 'aria-label': 'Type', onchange: e => { type = e.target.value; draw(); } });
  const inp = h('input', { placeholder: 'Filter', 'aria-label': 'Filter', style: { width: '240px' }, oninput: e => { q = norm(e.target.value); draw(); } });
  box.replaceChildren(h('div.page', h('div.pagehead', h('div', h('h1', 'Entities'), h('p', 'People, organisations, places and things in this case.')), h('div.row', btn('Import CSV', async () => { const [f] = await pickFile('.csv,text/csv'); if (f) toast(await importRows(parseCsv(await f.text()))); }), btn('Export CSV', () => download(slug(S.case.title) + '-entities.csv', csv(all('entity').map(e => ({ type: e.type, name: e.title, status: e.status, aliases: (e.aliases || []).join('; '), lat: e.lat, lon: e.lon, url: e.url, tags: (e.tags || []).join('; '), notes: e.text, details: (e.fields || []).map(f => f.join(': ')).join('; '), sources: (e.sources || []).map(s => s.name + ' ' + (s.url || '')).join('; ') }))), 'text/csv')), btn('Add entity', () => editEntity(), 'primary', 'plus'))),
    h('div.row', { style: { marginBottom: '14px' } }, inp, h('div', { style: { width: '200px' } }, sel)), list));
  const draw = () => {
    const A = all('entity'), n = {}; A.forEach(e => n[e.type] = (n[e.type] || 0) + 1);
    sel.replaceChildren(h('option', { value: '' }, `All types (${A.length})`), ...Object.keys(n).sort().map(k => h('option', { value: k, selected: k === type }, `${tname(k)} (${n[k]})`)));
    const L = {}; all('link').forEach(l => { L[l.a] = (L[l.a] || 0) + 1; L[l.b] = (L[l.b] || 0) + 1; });
    const key = { title: e => norm(e.title), type: e => tname(e.type), status: e => STATUS.indexOf(e.status), links: e => -(L[e.id] || 0), added: e => e.created }[sort];
    const rows = A.filter(e => (!type || e.type === type) && (!q || norm([e.title, ...(e.aliases || []), ...(e.tags || []), e.text].join(' ')).includes(q))).sort((a, b) => (key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0) * dir);
    if (!A.length) return list.replaceChildren(empty('Nothing filed yet', 'Look something up and add what you find, or add an entity by hand.'));
    const th = (k, l) => h('th', { tabindex: 0, 'aria-sort': sort === k ? (dir > 0 ? 'ascending' : 'descending') : null, onclick: () => { dir = sort === k ? -dir : 1; sort = k; draw(); } }, l, sort === k ? (dir > 0 ? ' ↑' : ' ↓') : '');
    list.replaceChildren(h('div.scroll', h('table', h('thead', h('tr', th('title', 'Name'), th('type', 'Type'), th('status', 'Status'), th('links', 'Links'), h('th', 'Sources'), th('added', 'Added'))), h('tbody', rows.map(e => h('tr', { tabindex: 0, onclick: () => openDoc(e), onkeydown: ev => ev.key === 'Enter' && openDoc(e) }, h('td', h('span.serif', e.title), e.tags?.length ? h('div', h('small', e.tags.join(', '))) : null), h('td', typeTag(e.type)), h('td', tag(e.status)), h('td.dot', L[e.id] || 0), h('td.dot', (e.sources || []).length), h('td.dot', fmt(e.created.slice(0, 10)))))))), !rows.length && h('p.mute', { style: { padding: '16px 0' } }, 'No entity matches that filter.'));
  };
  draw(); return { refresh: draw };
}
