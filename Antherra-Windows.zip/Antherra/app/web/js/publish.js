// Turns a case into a Project Antherra draft made of the plugin's own blocks, and sends it to WordPress.
import { h, S, all, byId, get, post, putj, api, btn, ext, safe, fmt, t0, tag, coord, stamp, field, toast, dialog, confirmBox, guard, oops, blobUrl, AUTH, norm, caseUrl, go, slug } from './core.js';
import { openDoc } from './drawer.js';
import { view, tileUrl } from './static.js';
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// For the plugin's plain-text fields: markup characters become look-alikes, so nothing scraped can act as HTML.
const plain = s => String(s ?? '').replace(/</g, '‹').replace(/>/g, '›');
const pl = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;
const ST = s => ({ unverified: 'unconfirmed' }[s] || s || 'unconfirmed'); // the plugin's word for it
// Same escaping WordPress uses for block attributes, so text can never break out of the block comment.
export const block = (name, a) => `<!-- wp:antherra/${name} ${JSON.stringify(a).replace(/\\\\/g, '\\u005c').replace(/--/g, '\\u002d\\u002d').replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026').replace(/\\"/g, '\\u0022')} /-->`;
const FIND = ['ongoing', 'verified', 'unconfirmed', 'contradicted', 'misattributed', 'updated'];
const mem = {};

export function publish(box) {
  const c = S.case, o = mem[c.id] ||= { verified: true, timeline: true, map: true, findings: true, sources: true, hero: true, prec: '5', pics: new Set(), kinds: 'all' };
  let wp = null; const pane = h('div'), side = h('div.stack', { style: { gap: '22px' } });
  const F = { title: field({ label: 'Headline' }, c.title), excerpt: field({ label: 'Standfirst', type: 'area', rows: 3 }, c.standfirst), region: field({ label: 'Region', list: 'wpregions' }, c.desk), topic: field({ label: 'Topic', ph: 'Misinformation, Conflict, Money' }, o.topic), finding: field({ label: 'Finding', type: 'select', options: FIND.map(x => [x, x]) }, FIND.includes(c.state) ? c.state : 'ongoing'), authors: field({ label: 'Authors' }, c.sample ? '' : c.byline) };
  F.title.node.classList.add('full'); F.excerpt.node.classList.add('full');
  box.replaceChildren(h('div.page', h('div.pagehead', h('div', h('h1', 'Publish'), h('p', 'Sends this case to your site as a draft investigation. Nothing goes live until someone publishes it in WordPress.'))), h('div.cols', pane, side)));

  // ---- what goes in
  const keep = d => !o.verified || d.status === 'verified', rnd = x => +(+x).toFixed(+o.prec);
  const finds = () => o.findings ? all('finding').filter(keep) : [], evs = () => all('event').filter(keep).filter(e => isFinite(t0(e.date))).sort((a, b) => t0(a.date) - t0(b.date)), evd = () => all('evidence').filter(keep), pics = () => evd().filter(e => /^image\/(?!svg)/.test(e.mime) && o.pics.has(e.id));
  function pins() {
    const m = new Map(); [...all('entity').filter(keep).filter(e => e.lat != null), ...evs().filter(e => e.lat != null)].forEach(d => { const k = rnd(d.lat) + ',' + rnd(d.lon), p = m.get(k), cap = d.kind === 'event' ? `${fmt(d.date)}: ${d.title}` : ''; if (!p) m.set(k, { lat: rnd(d.lat), lng: rnd(d.lon), label: d.kind === 'event' ? d.place || d.title : d.title, caption: cap }); else if (cap) p.caption = [p.caption, cap].filter(Boolean).join('; '); }); return [...m.values()];
  }
  function sources() {
    const out = [], seen = new Set(), dmy = s => s ? fmt(s.slice(0, 10)) : '', add = (title, url, archiveUrl, accessed, note) => { const k = safe(url) || title; if (seen.has(k)) return; seen.add(k); out.push({ title: plain(title || url), url: safe(url) || '', archiveUrl: safe(archiveUrl) || '', accessed: accessed || '', note: note || '' }); };
    evd().forEach(e => add(e.title, e.url, e.archive, dmy(e.captured), `SHA-256 ${e.sha256}`));
    const ar = new Map(all('evidence').filter(e => e.url).map(e => [e.url, e]));
    evs().forEach(e => { if (safe(e.url)) add((e.sources?.[0]?.url === e.url && e.sources[0].name) || new URL(e.url).hostname, e.url, ar.get(e.url)?.archive, dmy(e.sources?.[0]?.at)); });
    [...all('entity').filter(keep), ...evs()].forEach(d => (d.sources || []).forEach(s => safe(s.url) && add(s.name, s.url, ar.get(s.url)?.archive, dmy(s.at))));
    return out;
  }
  function build() {
    const P = o.map || o.hero ? pins() : [], main = P[0], hero = o.hero && !!main, E = o.timeline ? evs() : [], Q = pics(), src = o.sources ? sources() : [], B = [], xs = main ? coord(main.lat, main.lng) : '';
    const kicker = [F.region.el.value, F.topic.el.value].map(x => x.trim()).filter(Boolean).join(' · ');
    B.push(block('hero', { ...(hero ? { imageId: '@id:hero', imageUrl: '@url:hero', showMarker: true, markerX: 50, markerY: 50, coords: xs } : { showMarker: false }), kicker: esc(kicker), heading: '', standfirst: esc(F.excerpt.el.value.trim()) }));
    if (finds().length) B.push(block('key-findings', { title: 'Key findings', items: finds().map(f => esc(f.title) + (f.status === 'verified' ? '' : ` <em>(${ST(f.status)})</em>`)) }));
    if (o.map && P.length) B.push(block('map', { pins: P.map(p => ({ ...p, label: plain(p.label).slice(0, 80), caption: plain(p.caption).slice(0, 300) })), zoom: P.length > 1 ? 0 : 10, height: 460, caption: +o.prec < 5 ? 'Locations are approximate.' : '' }));
    Q.forEach((e, i) => B.push(block('exhibit', { imageId: '@id:' + e.id, imageUrl: '@url:' + e.id, alt: plain(o['alt' + e.id] || e.title), boxes: [], figure: `Figure ${i + 1}.`, caption: esc(e.notes || e.title), status: ST(e.status), timestamp: fmt(e.date), source: safe(e.archive) || safe(e.url) || '', sourceLabel: e.archive ? 'Archived source' : e.url ? 'Source' : '' })));
    if (E.length) B.push(block('timeline', { title: 'Timeline', entries: E.map(e => ({ date: fmt(e.date.slice(0, 10)) + (e.end ? ' to ' + fmt(e.end.slice(0, 10)) : ''), time: e.date.slice(11, 16), title: esc(e.title), text: esc(e.text) + (safe(e.url) ? `${e.text ? ' ' : ''}<a href="${esc(e.url)}">Source</a>` : ''), status: ST(e.status) })) }));
    if (src.length) B.push(block('sources', { title: 'Sources', items: src }));
    return { hero, main, P, E, Q, src, content: B.join('\n\n'), coords: xs };
  }
  // ---- pictures are redrawn, which drops camera metadata such as GPS and serial numbers
  const b64 = cv => cv.toDataURL('image/jpeg', .9).split(',')[1];
  const sha = async s => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map(x => x.toString(16).padStart(2, 0)).join('');
  const img = src => new Promise((r, j) => { const i = new Image(); i.onload = () => r(i); i.onerror = () => j(new Error('A picture could not be read.')); i.src = src; });
  async function photo(e) { const i = await img(blobUrl(e.sha256, e.mime)), s = Math.min(1, 2400 / Math.max(i.naturalWidth, i.naturalHeight)), cv = h('canvas', { width: Math.round(i.naturalWidth * s), height: Math.round(i.naturalHeight * s) }), x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.drawImage(i, 0, 0, cv.width, cv.height); const data = b64(cv); return { key: e.id, sha: await sha(data), name: e.title, alt: plain(o['alt' + e.id] || e.title), caption: '', data }; }
  async function heroMap(p) {
    const W = 1600, H = 900, v = view([[p.lat, p.lng]], W, H), cv = h('canvas', { width: W, height: H }), x = cv.getContext('2d'); x.fillStyle = '#0f0e13'; x.fillRect(0, 0, W, H); const carto = S.settings.keys.carto; if (!carto) x.filter = 'grayscale(1) invert(1) brightness(.78) contrast(1.15)';
    let got = 0; await Promise.all(v.tiles.map(async t => { try { const i = await img(tileUrl(t)); x.drawImage(i, t.x, t.y, 256.6, 256.6); got++; } catch { } })); x.filter = 'none'; if (got < v.tiles.length) throw new Error('Some of the map did not load. Try again, or untick the map picture.');
    x.font = '500 18px Manrope, sans-serif'; const cr = carto ? '© OpenStreetMap contributors © CARTO' : '© OpenStreetMap contributors', w = x.measureText(cr).width; x.fillStyle = 'rgba(15,14,19,.75)'; x.fillRect(W - w - 32, 16, w + 20, 30); x.fillStyle = '#cfced6'; x.fillText(cr, W - w - 22, 37);
    const data = b64(cv); return { key: 'hero', sha: await sha(`hero ${p.lat},${p.lng},${carto ? 'carto' : 'osm'}`), name: 'map-' + slug(F.title.el.value || 'case'), alt: 'Map centred on ' + coord(p.lat, p.lng), caption: cr, data };
  }
  async function send(x = {}) {
    if (!F.title.el.value.trim()) return toast('Write a headline first.');
    const b = build(), n = b.Q.length + (b.hero ? 1 : 0), unc = [...finds(), ...b.E].filter(d => d.status !== 'verified').length;
    if (!x.force && !await confirmBox(x.separate ? 'Send a separate draft?' : 'Send this draft?', `To ${wp.site.replace(/^https?:\/\//, '')} as ${wp.name || wp.user}. ${pl(b.E.length, 'timeline entry', 'timeline entries')}, ${pl(o.map ? b.P.length : 0, 'map pin')}, ${pl(b.src.length, 'source')}.${unc ? ` ${pl(unc, 'finding or event is', 'findings or events are')} not verified and will be labelled.` : ''} ${n ? `${n} picture${n > 1 ? 's go' : ' goes'} into your media library, where anyone with the link can see ${n > 1 ? 'them' : 'it'} straight away, even while the investigation is a draft.` : 'No pictures.'}`, 'Send draft')) return;
    sendB.disabled = true; sendB.textContent = 'Sending';
    try {
      const media = []; if (b.hero) media.push(await heroMap(b.main)); for (const e of b.Q) media.push(await photo(e));
      const r = await post('/api/wp', { case_id: c.id, ...x, media, post: { title: plain(F.title.el.value.trim()), excerpt: plain(F.excerpt.el.value.trim()), region: plain(F.region.el.value.trim()), content: b.content, featured: b.hero ? 'hero' : b.Q[0]?.id, meta: { antherra_topic: F.topic.el.value.trim(), antherra_finding: F.finding.el.value, antherra_authors: F.authors.el.value.trim(), antherra_coords: b.coords } } });
      if (r.conflict) { const a = await confirmBox('Replace the edited draft?', r.conflict + ' Replacing it discards those edits. WordPress keeps them under Revisions.', 'Replace it', true); if (a) return send({ force: true }); return; }
      S.docs.set(c.id, r.case); S.case = r.case; const done = h('div.stack', h('p', r.updated ? 'The draft was updated.' : 'A new draft is waiting in WordPress.'), r.warnings.map(w => h('p.err', w)), h('p', 'Next: preview it, complete the checklist, and publish it there.'), ext(r.edit, 'Open the draft in WordPress'));
      drawSide(); await dialog('Draft sent', done, [{ label: 'Done', primary: true }]);
    } catch (e) { const d = (await get('/api/case/' + c.id)).find(x => x.kind === 'case'); if (d) { S.docs.set(c.id, d); S.case = d; } throw e; } finally { sendB.disabled = false; sendB.textContent = 'Send draft to WordPress'; }
  }
  const sendB = btn('Send draft to WordPress', () => send(), 'primary');

  // ---- left: the draft
  const ck = (k, n, extra) => h('label.row', { style: { gap: '8px' } }, h('input', { type: 'checkbox', checked: o[k], onchange: e => { o[k] = e.target.checked; draw(); } }), n, extra);
  const prev = h('div');
  function draw() {
    const b = build(), im = evd().filter(e => /^image\/(?!svg)/.test(e.mime)), hidden = o.verified ? [...all('finding'), ...all('event'), ...all('evidence'), ...all('entity')].filter(d => d.status !== 'verified').length : 0;
    prev.replaceChildren(
      h('h2', { style: { margin: '30px 0 10px' } }, 'What goes in'),
      h('div.stack', ck('verified', 'Verified only', hidden ? h('small', `${pl(hidden, 'unverified item')} left out`) : null), ck('findings', 'Key findings', h('small', `${finds().length}`)), ck('map', 'Interactive map', h('small', pl(pins().length, 'pin'))), ck('hero', 'Map picture at the top', h('small', b.hero ? `uploaded, centred on ${b.main.label}` : 'needs a located item')), ck('timeline', 'Timeline', h('small', pl(evs().length, 'entry', 'entries'))), ck('sources', 'Sources', h('small', `${sources().length}`)),
        h('label.row', { style: { gap: '8px' } }, 'Location precision', h('select', { style: { width: '200px' }, onchange: e => { o.prec = e.target.value; draw(); } }, [['5', 'Exact'], ['2', 'About 1 km'], ['1', 'About 10 km']].map(([v, n]) => h('option', { value: v, selected: v === o.prec }, n))))),
      im.length ? h('div', { style: { marginTop: '24px' } }, h('span.label', 'Pictures to show as exhibits'), h('p', { style: { margin: '4px 0 8px' } }, h('small', 'Tick only what you have the right to publish and what cannot put anyone at risk. Camera metadata is removed.')), h('ul.lines', im.map(e => h('li', h('div.row', { style: { flexWrap: 'nowrap', gap: '14px' } }, h('input', { type: 'checkbox', checked: o.pics.has(e.id), 'aria-label': e.title, onchange: ev => { ev.target.checked ? o.pics.add(e.id) : o.pics.delete(e.id); draw(); } }), h('img', { src: blobUrl(e.sha256, e.mime), alt: '', style: { width: '84px', height: '56px', objectFit: 'cover', borderRadius: '6px' } }), h('div.grow', h('div.row', e.title, tag(e.status)), o.pics.has(e.id) && h('input', { placeholder: 'Describe the picture for readers who cannot see it', 'aria-label': 'Description', value: o['alt' + e.id] || '', style: { marginTop: '6px' }, oninput: ev => o['alt' + e.id] = ev.target.value }))))))) : null,
      !finds().length && !b.E.length && !b.P.length ? h('p.tint', { style: { marginTop: '22px' } }, 'The draft would be almost empty. Mark items as verified, or untick “Verified only”.') : null);
    drawSide(b);
  }
  // ---- right: connection and checks
  const PII = /[\w.+-]+@[\w-]+\.[\w.]+|(?:\+|\b00)\d[\d ().-]{7,16}\d/g;
  function drawSide(b = build()) {
    const last = S.case.wp?.id && S.case.wp.site === wp?.site ? S.case.wp : null, rows = [], add = (ok, t) => rows.push(h('li', { style: { padding: '9px 0' } }, h('div.row', { style: { flexWrap: 'nowrap', alignItems: 'flex-start' } }, h('span.tag', { class: ok ? 'tag-verified' : 'tag-contradicted' }, ok ? 'ok' : 'check'), h('span', t))));
    const unc = [...finds(), ...b.E].filter(d => d.status !== 'verified'), na = b.src.filter(s => s.url && !s.archiveUrl).length, pii = [...new Set([F.excerpt.el.value, ...finds().map(f => f.title), ...b.E.map(e => e.title + ' ' + (e.text || '')), ...b.Q.map(e => e.notes || '')].join('\n').match(PII) || [])], acc = all('entity').filter(keep).filter(e => ['person', 'email', 'phone', 'username'].includes(e.type) && e.lat != null);
    add(!unc.length, unc.length ? `${pl(unc.length, 'included item is', 'included items are')} not verified and will be labelled.` : 'Every finding and event is verified.');
    if (o.sources) add(!na, na ? `${pl(na, 'source has', 'sources have')} no archived copy. Archive them in WordPress or from the evidence record.` : 'Every linked source has an archived copy.');
    add(!pii.length, pii.length ? `Possible personal details in the text: ${pii.slice(0, 4).join(', ')}` : 'No emails or phone numbers found in the text.');
    if (acc.length && (o.map || o.hero)) add(false, `The map would show a location for ${acc.slice(0, 3).map(e => e.title).join(', ')}. Remove it or lower the precision if that could put someone at risk.`);
    if (S.case.sample) add(false, 'This is the sample case, not your reporting.');
    side.replaceChildren(wp?.site ? h('div.tint', h('h3', 'Connected'), h('p.mute', { style: { margin: '4px 0 12px' } }, `${wp.site.replace(/^https?:\/\//, '')} as ${wp.name || wp.user}`), h('div.row', sendB, last && btn('Start a separate draft', () => send({ separate: true }).catch(oops), 'small')), last && h('p', { style: { marginTop: '12px' } }, h('small', 'Last sent ', h('span.dot', stamp(last.at)), '. ', ext(last.edit, 'Open in WordPress'))), h('div', { style: { marginTop: '10px' } }, btn('Disconnect', async () => { await api('DELETE', '/api/wp'); wp = {}; drawSide(); }, 'link small'))) : connectBox(),
      h('div', h('h2', { style: { marginBottom: '8px' } }, 'Before you send'), h('ul.lines', rows)), h('p', h('small', 'The sign-off checklist (archived sources, second analyst, right of reply, safety, image rights) is left for a person to complete in WordPress.')));
  }
  function connectBox() {
    const s = field({ label: 'Site' }, 'https://thestudentstatesman.com'), u = field({ label: 'WordPress username' }), p = field({ label: 'Application password', type: 'password' }), er = h('p.err', { hidden: true }), b = h('button.primary', { type: 'submit' }, 'Connect');
    const url = () => { try { return new URL(/^https?:/.test(s.el.value) ? s.el.value : 'https://' + s.el.value).href.replace(/\/$/, '') + '/wp-admin/authorize-application.php?app_name=Antherra'; } catch { return null; } };
    const link = h('a', { href: url(), target: '_blank', rel: 'noopener' }, 'Create one on your site'); s.el.addEventListener('input', () => { const x = url(); if (x) link.href = x; });
    return h('form.tint.stack', { onsubmit: async e => { e.preventDefault(); b.disabled = true; er.hidden = true; try { wp = await putj('/api/wp', { site: s.el.value, user: u.el.value, password: p.el.value }); drawSide(); loadRegions(); } catch (x) { er.textContent = x.message; er.hidden = false; } finally { b.disabled = false; p.el.value = ''; } } }, h('h3', 'Connect to WordPress'), h('p', { style: { fontSize: '14px' } }, 'Use an application password, not your normal one. You can revoke it at any time in your WordPress profile. ', link, '.'), s.node, u.node, p.node, er, h('div', b), h('small', 'Saved in a file only your account on this computer can read. Sent only to your site, over https.'));
  }
  const loadRegions = () => get('/api/wpregions').then(r => { $dl.replaceChildren(...r.map(n => h('option', { value: n }))); }).catch(() => { });
  const $dl = h('datalist', { id: 'wpregions' });
  pane.replaceChildren(h('div.grid2', F.title.node, F.excerpt.node, F.region.node, F.topic.node, F.finding.node, F.authors.node), $dl, prev);
  Object.values(F).forEach(f => f.el.addEventListener('input', () => { o.topic = F.topic.el.value; clearTimeout(o.t); o.t = setTimeout(() => drawSide(), 400); }));
  get('/api/wp').then(r => { wp = r; draw(); if (wp.site) loadRegions(); }).catch(oops);
  return { refresh: () => { if (wp) draw(); } };
}
