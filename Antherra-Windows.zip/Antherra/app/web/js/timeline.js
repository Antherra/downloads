import { h, svg, S, all, byId, fmt, t0, t1, tag, btn, empty, norm, download, slug, pickFile, toast, STATUS, safe, ext } from './core.js';
import { openDoc, editEvent } from './drawer.js';
import { csv, parseCsv, importRows } from './io.js';
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], DAY = 864e5;
const LC = ['#a8dcff', '#c9c5e8', '#c9e7b3', '#f0d98c', '#8fe0cf', '#d8d6dd'];
export function timeline(box) {
  let q = '', ent = '', status = '', view = null;
  const chart = h('div.exhibit.round', { style: { margin: '0 0 10px', touchAction: 'pan-y' } }), list = h('div'), entSel = h('select', { 'aria-label': 'Entity', onchange: e => { ent = e.target.value; draw(); } });
  box.replaceChildren(h('div.page', h('div.pagehead', h('div', h('h1', 'Timeline'), h('p', 'What happened, when, and how precisely we know. Times are UTC.')), h('div.row', btn('Import CSV', async () => { const [f] = await pickFile('.csv,text/csv'); if (f) toast(await importRows(parseCsv(await f.text()))); }), btn('Export CSV', () => download(slug(S.case.title) + '-timeline.csv', csv(evs().map(e => ({ date: e.date, end: e.end, title: e.title, status: e.status, lane: e.lane, place: e.place, lat: e.lat, lon: e.lon, who: (e.entities || []).map(i => byId(i)?.title).join('; '), url: e.url, notes: e.text }))), 'text/csv')), btn('Add event', () => editEvent(), 'primary', 'plus'))),
    h('div.row', { style: { marginBottom: '14px' } }, h('input', { placeholder: 'Filter', 'aria-label': 'Filter', style: { width: '220px' }, oninput: e => { q = norm(e.target.value); draw(); } }), h('div', { style: { width: '220px' } }, entSel), h('div', { style: { width: '160px' } }, h('select', { 'aria-label': 'Status', onchange: e => { status = e.target.value; draw(); } }, h('option', { value: '' }, 'Any status'), STATUS.map(s => h('option', { value: s }, s))))),
    chart, list));
  const evs = () => all('event').filter(e => isFinite(t0(e.date)) && (!ent || (e.entities || []).includes(ent)) && (!status || e.status === status) && (!q || norm([e.title, e.text, e.place, e.lane].join(' ')).includes(q))).sort((a, b) => t0(a.date) - t0(b.date) || (a.date.length - b.date.length));
  const color = {}; const laneCol = n => color[n] ||= LC[Object.keys(color).length % LC.length];

  function drawChart(E) {
    chart.hidden = E.length < 2; if (chart.hidden) return;
    const a = t0(E[0].date), b = Math.max(...E.map(e => t1(e.end || e.date))), pad = Math.max((b - a) * .04, DAY / 24); view ||= [a - pad, b + pad];
    const W = Math.max(320, chart.clientWidth || 900), left = 112, lanes = [...new Set(E.map(e => e.lane || 'Events'))], X = t => left + (t - view[0]) / (view[1] - view[0]) * (W - left - 16);
    const rows = lanes.map(n => { const ends = [], it = E.filter(e => (e.lane || 'Events') === n).map(e => { const x0 = X(t0(e.date)), x1 = X(t1(e.end || e.date)); const bar = e.end || e.date.length < 10; const w = bar ? Math.max(10, x1 - x0) : 10; let k = ends.findIndex(v => v < x0 - 4); if (k < 0) k = ends.length; const room = Math.min(190, e.title.length * 6.3 + 18); ends[k] = x0 + Math.max(w, room); return { e, x0, w, bar, k }; }); return { n, it, hgt: Math.max(1, ends.length) * 26 + 16 }; });
    const H = 34 + rows.reduce((s, r) => s + r.hgt, 0) + 6, g = svg('svg', { width: W, height: Math.min(H, 460), viewBox: `0 0 ${W} ${Math.min(H, 460)}`, style: 'display:block', role: 'img', 'aria-label': 'Timeline chart' });
    const span = view[1] - view[0], steps = [DAY / 24, DAY / 4, DAY, DAY * 7]; const tk = [];
    if (span < DAY * 60) { const st = steps.find(s => span / s < 12) || DAY * 7; for (let t = Math.ceil(view[0] / st) * st; t < view[1]; t += st) { const d = new Date(t); tk.push([t, st < DAY ? d.toISOString().slice(11, 16) + (d.getUTCHours() ? '' : ` ${d.getUTCDate()} ${MON[d.getUTCMonth()]}`) : `${String(d.getUTCDate()).padStart(2, 0)}.${String(d.getUTCMonth() + 1).padStart(2, 0)}`]); } }
    else if (span < DAY * 365 * 4) { const s = [1, 2, 3, 6].find(s => span / DAY / 30.4 / s < 13) || 6; const d = new Date(view[0]); for (let y = d.getUTCFullYear(), m = Math.ceil(d.getUTCMonth() / s) * s; Date.UTC(y, m) < view[1]; m += s) { const D = new Date(Date.UTC(y, m)); tk.push([+D, D.getUTCMonth() ? `${String(D.getUTCMonth() + 1).padStart(2, 0)}.${D.getUTCFullYear()}` : String(D.getUTCFullYear())]); } }
    else { const yrs = span / DAY / 365, s = [1, 2, 5, 10, 20, 50, 100, 500].find(s => yrs / s < 13) || 1000; for (let y = Math.ceil(new Date(view[0]).getUTCFullYear() / s) * s; t0(String(y)) < view[1]; y += s) tk.push([t0(String(y)), String(y)]); }
    const clip = svg('clipPath', { id: 'tlc' }, svg('rect', { x: left - 2, y: 0, width: W - left, height: 460 })); g.append(svg('defs', {}, clip));
    tk.filter(t => X(t[0]) > left).forEach(([t, l]) => g.append(svg('path', { d: `M${X(t)} 28V${H}`, stroke: '#a8dcff', 'stroke-opacity': .1 }), svg('text', { x: X(t) + 4, y: 20, fill: '#9c9ba4', style: 'font:800 13px Doto' }, l)));
    let y = 34; const body = svg('g', { 'clip-path': 'url(#tlc)' });
    rows.forEach(r => {
      g.append(svg('path', { d: `M0 ${y}H${W}`, stroke: '#26252d' }), svg('text', { x: 14, y: y + 24, fill: '#cfced6', style: 'font:700 13px Manrope' }, r.n.length > 14 ? r.n.slice(0, 13) + '…' : r.n));
      r.it.forEach(({ e, x0, w, bar, k }) => { const cy = y + 20 + k * 26, c = laneCol(r.n), sure = e.status === 'verified'; const G = svg('g', { tabindex: 0, role: 'button', style: 'cursor:pointer', 'aria-label': `${fmt(e.date)} ${e.title}`, onclick: () => openDoc(e), onkeydown: ev => ev.key === 'Enter' && openDoc(e) }, svg('title', {}, `${fmt(e.date)}${e.end ? ' to ' + fmt(e.end) : ''}: ${e.title} (${e.status})`)); G.append(bar ? svg('rect', { x: x0, y: cy - 6, width: w, height: 12, rx: 6, fill: c, 'fill-opacity': sure ? .95 : .28, stroke: c }) : svg('circle', { cx: x0 + 5, cy, r: 5.5, fill: sure ? c : '#0f0e13', stroke: c, 'stroke-width': 2 })); const tx = Math.max(x0 + (bar ? 4 : 16), bar && w > 60 ? Math.max(x0 + 8, left + 4) : 0) ; if (!bar || w < 60) G.append(svg('text', { x: (bar ? x0 + w : x0 + 10) + 6, y: cy + 4, fill: '#fff', style: 'font:500 12px Manrope' }, e.title.length > 28 ? e.title.slice(0, 27) + '…' : e.title)); else G.append(svg('text', { x: tx, y: cy + 4, fill: sure ? '#0f0e13' : '#fff', style: 'font:700 12px Manrope' }, e.title.slice(0, Math.max(3, Math.floor((w - 16) / 7))))); body.append(G); });
      y += r.hgt;
    });
    g.append(body);
    const ctl = h('div.row', { style: { position: 'absolute', right: '10px', bottom: '8px' } }, [['−', 1.6], ['+', .625]].map(([s, k]) => h('button.small', { style: { background: 'rgba(0,0,0,.7)', color: '#fff', borderColor: '#2c2b34' }, 'aria-label': k > 1 ? 'Zoom out' : 'Zoom in', onclick: () => zoom(k, .5) }, s)), h('button.small', { style: { background: 'rgba(0,0,0,.7)', color: '#fff', borderColor: '#2c2b34' }, onclick: () => { view = null; draw(); } }, 'All'));
    chart.replaceChildren(h('div', { style: { maxHeight: '460px', overflow: 'auto' } }, g), ctl);
    g.setAttribute('height', H); g.setAttribute('viewBox', `0 0 ${W} ${H}`);
    g.onwheel = ev => { if (!(ev.ctrlKey || ev.metaKey || Math.abs(ev.deltaX) > Math.abs(ev.deltaY))) return; ev.preventDefault(); if (ev.ctrlKey || ev.metaKey) zoom(Math.exp(ev.deltaY * .004), (ev.offsetX - left) / (W - left)); else shift(ev.deltaX / W); };
    g.onpointerdown = ev => { if (ev.target.closest('[role=button]')) return; const x = ev.clientX, v = [...view]; const mv = m => { const d = (x - m.clientX) / (W - left) * (v[1] - v[0]); view = [v[0] + d, v[1] + d]; drawChart(E); }; const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); }; addEventListener('pointermove', mv); addEventListener('pointerup', up); };
  }
  const zoom = (k, at) => { const s = view[1] - view[0], n = Math.max(DAY / 48, Math.min(s * k, DAY * 365 * 3000)), c = view[0] + s * at; view = [c - n * at, c + n * (1 - at)]; drawChart(evs()); };
  const shift = f => { const d = (view[1] - view[0]) * f; view = [view[0] + d, view[1] + d]; drawChart(evs()); };
  function draw() {
    const A = all('event'), E = evs();
    entSel.replaceChildren(h('option', { value: '' }, 'Anyone or anything'), ...all('entity').filter(e => A.some(x => (x.entities || []).includes(e.id))).sort((a, b) => a.title.localeCompare(b.title)).map(e => h('option', { value: e.id, selected: e.id === ent }, e.title)));
    drawChart(E);
    if (!A.length) return list.replaceChildren(empty('No events yet', 'Add one, or tick the dates offered beside lookup results.'));
    const out = []; let yr = null, prev = null;
    E.forEach(e => {
      const y = e.date.slice(0, 4); if (y !== yr) { out.push(h('li.year', y)); yr = y; }
      if (prev && e.date.length >= 10 && prev.date.length >= 10) { const g = Math.round((t0(e.date) - t1(prev.end || prev.date)) / DAY); if (g >= 14) out.push(h('li.gap', `${g} days with no entry`)); } prev = e;
      out.push(h('li', h('span.when', fmt(e.date), e.end && h('div', { style: { fontSize: '14px', color: 'var(--muted)' } }, 'to ' + fmt(e.end))), h('div.bodyx', h('div.row', h('h3', h('button.link', { style: { font: 'inherit', whiteSpace: 'normal', textAlign: 'left', textDecoration: 'none' }, onclick: () => openDoc(e) }, e.title)), tag(e.status)), e.text && h('p', e.text), h('div.chips', e.place && h('span.mute', { style: { fontSize: '13px' } }, e.place), (e.entities || []).map(byId).filter(Boolean).map(x => h('button.chip', { onclick: () => openDoc(x) }, x.title))), safe(e.url) && h('small', { style: { display: 'block', marginTop: '6px' } }, ext(e.url, new URL(e.url).hostname)))));
    });
    list.replaceChildren(h('ul.tl', out), !E.length ? h('p.mute', 'No event matches those filters.') : '');
  }
  draw(); const ro = new ResizeObserver(() => drawChart(evs())); let w = 0; const rz = () => { if (chart.clientWidth !== w) { w = chart.clientWidth; drawChart(evs()); } }; addEventListener('resize', rz);
  return { refresh: draw, cleanup: () => { removeEventListener('resize', rz); ro.disconnect(); } };
}
