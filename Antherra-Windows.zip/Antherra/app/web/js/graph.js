import { h, S, all, byId, save, saveAll, btn, empty, tcol, TYPES, GROUP, GROUPN, iconPath, icon, norm, toast, tname, oops, fmt, t0 } from './core.js';
import { openDoc, linkDialog, editEntity } from './drawer.js';
export function graph(box, params) {
  const cv = h('canvas.draw', { tabindex: 0, 'aria-label': 'Link chart. Use the Entities list for a text version.' }), wrap = h('div.exhibit.grow', cv), ctx = cv.getContext('2d'), info = h('span.mute'), hidden = new Set();
  let N = [], E = [], k = 1, ox = 0, oy = 0, heat = 1, drag = null, hover = null, mode = null, first = null, path = null, focus = params.get('id'), raf = 0, dead = false, labels = true, moved = false, only = false;
  const P = {}; Object.keys(TYPES).forEach(t => P[t] = new Path2D(iconPath(t)));
  const bs = {}, setMode = m => { mode = mode === m ? null : m; first = null; path = null; Object.entries(bs).forEach(([a, b]) => b.classList.toggle('on', a === mode)); info.textContent = { link: 'Click the first entity, then the second.', path: 'Click two entities to find the shortest chain between them.' }[mode] || ''; tick(); };
  const legend = h('div.row', { style: { gap: '6px 14px', fontSize: '13px' } }), onlyB = btn('Neighbours only', () => { only = !only; onlyB.classList.toggle('on', only); if (only && !focus) toast('Click an entity first.'); tick(); }, 'small');
  box.replaceChildren(h('div.full-page', h('div.tools', btn('Add entity', () => editEntity(), 'small', 'plus'), bs.link = btn('Draw link', () => setMode('link'), 'small'), bs.path = btn('Find path', () => setMode('path'), 'small'), onlyB, btn('Labels', () => { labels = !labels; tick(); }, 'small'), btn('Tidy', () => { N.forEach(n => { n.pin = false; }); heat = 1; loop(); }, 'small'), btn('Fit', fit, 'small'), btn('Save picture', () => { const a = h('a', { href: cv.toDataURL('image/png'), download: 'links.png' }); a.click(); }, 'small'), info, h('span.grow'), legend), wrap));
  function build() {
    const old = new Map(N.map(n => [n.id, n]));
    N = all('entity').map((e, i) => { const o = old.get(e.id), a = i * 2.4, r = 40 + 18 * Math.sqrt(i); return Object.assign(o || { x: e._x ?? Math.cos(a) * r, y: e._y ?? Math.sin(a) * r, vx: 0, vy: 0, pin: e._x != null }, { id: e.id, e }); });
    const ix = new Map(N.map(n => [n.id, n])); E = all('link').map(l => ({ l, a: ix.get(l.a), b: ix.get(l.b) })).filter(x => x.a && x.b); N.forEach(n => n.deg = 0); E.forEach(x => { x.a.deg++; x.b.deg++; });
    const pair = {}; E.forEach(x => { const key = [x.a.id, x.b.id].sort().join(); x.i = (pair[key] = (pair[key] || 0) + 1) - 1; });
    const gs = [...new Set(N.map(n => (TYPES[n.e.type] || ['', 'docs'])[1]))]; legend.replaceChildren(...gs.map(g => h('label.row', { style: { gap: '6px' } }, h('input', { type: 'checkbox', checked: !hidden.has(g), onchange: e => { e.target.checked ? hidden.delete(g) : hidden.add(g); tick(); } }), h('span.ty', h('i', { style: { background: GROUP[g] } }), GROUPN[g]))));
    heat = Math.max(heat, old.size ? .25 : 1); if (!N.length) wrap.replaceChildren(h('div', { style: { padding: '30px' } }, h('p', 'No entities to connect yet. Add some, or file them from a lookup.'))); else if (!cv.isConnected) wrap.replaceChildren(cv);
  }
  const near = () => { const s = new Set([focus]); E.forEach(x => { if (x.a.id === focus) s.add(x.b.id); if (x.b.id === focus) s.add(x.a.id); }); return s; };
  const vis = n => !hidden.has((TYPES[n.e.type] || ['', 'docs'])[1]) && (!only || !focus || near().has(n.id));
  const rad = n => 13 + Math.min(9, n.deg * 1.3);
  function sim() {
    const V = N.filter(vis); for (let i = 0; i < V.length; i++) { const a = V[i]; a.vx -= a.x * .0025 * heat; a.vy -= a.y * .004 * heat; for (let j = i + 1; j < V.length; j++) { const b = V[j]; let dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy || 1; if (d2 > 3e5) continue; const f = 9500 / d2 * heat, d = Math.sqrt(d2); dx /= d; dy /= d; a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f; } }
    E.forEach(({ a, b }) => { if (!vis(a) || !vis(b)) return; const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1, f = (d - 150) * .02 * heat; a.vx += dx / d * f; a.vy += dy / d * f; b.vx -= dx / d * f; b.vy -= dy / d * f; });
    V.forEach(n => { if (n.pin || n === drag) { n.vx = n.vy = 0; return; } n.vx *= .82; n.vy *= .82; n.x += Math.max(-30, Math.min(30, n.vx)); n.y += Math.max(-30, Math.min(30, n.vy)); }); heat *= .985;
  }
  const W = () => cv.clientWidth, Ht = () => cv.clientHeight, sx = n => W() / 2 + ox + n.x * k, sy = n => Ht() / 2 + oy + n.y * k;
  function tick() {
    const r = devicePixelRatio || 1, w = W(), ht = Ht(); if (!w) return; if (cv.width !== Math.round(w * r) || cv.height !== Math.round(ht * r)) { cv.width = Math.round(w * r); cv.height = Math.round(ht * r); }
    ctx.setTransform(r, 0, 0, r, 0, 0); ctx.fillStyle = '#0f0e13'; ctx.fillRect(0, 0, w, ht); ctx.strokeStyle = 'rgba(168,220,255,.055)'; ctx.lineWidth = 1; ctx.beginPath(); for (let x = (w / 2 + ox) % 56; x < w; x += 56) { ctx.moveTo(x, 0); ctx.lineTo(x, ht); } for (let y = (ht / 2 + oy) % 56; y < ht; y += 56) { ctx.moveTo(0, y); ctx.lineTo(w, y); } ctx.stroke();
    const nb = focus ? near() : null, on = path ? new Set(path) : null, dim = n => on ? !on.has(n.id) : nb ? !nb.has(n.id) : false;
    ctx.font = '500 11px Manrope'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    E.forEach(({ l, a, b, i }) => {
      if (!vis(a) || !vis(b)) return; const ax = sx(a), ay = sy(a), bx = sx(b), by = sy(b), d = Math.hypot(bx - ax, by - ay) || 1, nx = -(by - ay) / d, ny = (bx - ax) / d, off = i ? (i % 2 ? 1 : -1) * Math.ceil(i / 2) * 26 : 0, mx = (ax + bx) / 2 + nx * off, my = (ay + by) / 2 + ny * off;
      const pth = on && on.has(a.id) && on.has(b.id) && Math.abs(path.indexOf(a.id) - path.indexOf(b.id)) === 1, hot = pth || (focus && !on && (a.id === focus || b.id === focus)); ctx.globalAlpha = (dim(a) || dim(b)) && !hot ? .13 : 1; ctx.strokeStyle = hot ? '#a8dcff' : '#6a6974'; ctx.lineWidth = hot ? 1.8 : 1.1; ctx.setLineDash(l.status === 'verified' ? [] : [4, 4]); ctx.beginPath(); ctx.moveTo(ax, ay); ctx.quadraticCurveTo(mx + nx * off * .5, my + ny * off * .5, bx, by); ctx.stroke(); ctx.setLineDash([]);
      if (l.directed !== false) { const rr = rad(b) * Math.sqrt(k) + 4, ux = (bx - mx) / (Math.hypot(bx - mx, by - my) || 1), uy = (by - my) / (Math.hypot(bx - mx, by - my) || 1), tx = bx - ux * rr, ty = by - uy * rr; ctx.fillStyle = ctx.strokeStyle; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx - ux * 8 - uy * 4, ty - uy * 8 + ux * 4); ctx.lineTo(tx - ux * 8 + uy * 4, ty - uy * 8 - ux * 4); ctx.fill(); }
      if (labels && l.rel && (d > 120 || hot) && (k > .75 || hot)) { const t = l.rel.length > 30 ? l.rel.slice(0, 29) + '…' : l.rel, tw = ctx.measureText(t).width; ctx.fillStyle = '#0f0e13'; ctx.fillRect(mx - tw / 2 - 3, my - 8, tw + 6, 16); ctx.fillStyle = hot ? '#a8dcff' : '#9c9ba4'; ctx.fillText(t, mx, my); }
    }); ctx.globalAlpha = 1;
    N.filter(vis).forEach(n => {
      const x = sx(n), y = sy(n), R = rad(n) * Math.sqrt(k), c = tcol(n.e.type), sel = n.id === focus || n === first || (on && on.has(n.id)); ctx.globalAlpha = dim(n) ? .2 : 1; if (sel || n === hover) { ctx.fillStyle = 'rgba(168,220,255,.16)'; ctx.beginPath(); ctx.arc(x, y, R + 7, 0, 7); ctx.fill(); }
      ctx.fillStyle = n.e.status === 'verified' ? c : '#17161d'; ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, R, 0, 7); ctx.fill(); ctx.stroke(); ctx.save(); const s = R / 13; ctx.translate(x - 10 * s * .8, y - 10 * s * .8); ctx.scale(s * .8, s * .8); ctx.strokeStyle = n.e.status === 'verified' ? '#0f0e13' : c; ctx.lineWidth = 1.5; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(P[n.e.type] || P.text); ctx.restore();
      if (labels || sel || n === hover) { ctx.font = '700 12px Manrope'; const t = n.e.title.length > 30 && n !== hover ? n.e.title.slice(0, 29) + '…' : n.e.title, tw = ctx.measureText(t).width; ctx.fillStyle = 'rgba(15,14,19,.8)'; ctx.fillRect(x - tw / 2 - 4, y + R + 5, tw + 8, 17); ctx.fillStyle = '#fff'; ctx.fillText(t, x, y + R + 14); ctx.font = '500 11px Manrope'; }
    }); ctx.globalAlpha = 1;
  }
  function loop() { cancelAnimationFrame(raf); const f = () => { if (dead) return; if (heat > .02) { sim(); tick(); raf = requestAnimationFrame(f); } else tick(); }; f(); }
  function fit() { const V = N.filter(vis); if (!V.length) return; const x = V.map(n => n.x), y = V.map(n => n.y), w = Math.max(...x) - Math.min(...x) + 180, t = Math.max(...y) - Math.min(...y) + 120; k = Math.max(.25, Math.min(1.5, W() / w, Ht() / t)); ox = -(Math.max(...x) + Math.min(...x)) / 2 * k; oy = -(Math.max(...y) + Math.min(...y)) / 2 * k; tick(); }
  const at = ev => { const r = cv.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top; return [...N].reverse().find(n => vis(n) && Math.hypot(sx(n) - x, sy(n) - y) < rad(n) * Math.sqrt(k) + 4); };
  function bfs(a, b) { const prev = { [a]: null }, q = [a]; while (q.length) { const c = q.shift(); if (c === b) { const p = []; for (let x = b; x; x = prev[x]) p.unshift(x); return p; } E.forEach(({ a: m, b: n }) => { const o = m.id === c ? n.id : n.id === c ? m.id : null; if (o && !(o in prev)) { prev[o] = c; q.push(o); } }); } return null; }
  cv.onpointerdown = ev => { cv.setPointerCapture(ev.pointerId); const n = at(ev); moved = false; drag = n || { pan: true, x0: ev.clientX - ox, y0: ev.clientY - oy }; drag.sx = ev.clientX; drag.sy = ev.clientY; };
  cv.onpointermove = ev => {
    if (!drag) { const n = at(ev); if (n !== hover) { hover = n; cv.style.cursor = n ? 'pointer' : 'grab'; if (heat <= .02) tick(); } return; }
    if (Math.hypot(ev.clientX - drag.sx, ev.clientY - drag.sy) > 4) moved = true; if (!moved) return;
    if (drag.pan) { ox = ev.clientX - drag.x0; oy = ev.clientY - drag.y0; tick(); } else { const r = cv.getBoundingClientRect(); drag.x = (ev.clientX - r.left - W() / 2 - ox) / k; drag.y = (ev.clientY - r.top - Ht() / 2 - oy) / k; heat = Math.max(heat, .12); loop(); }
  };
  cv.onpointerup = ev => {
    const d = drag; drag = null; if (!d) return;
    if (!d.pan && moved) { d.pin = true; save({ ...byId(d.id), _x: Math.round(d.x), _y: Math.round(d.y) }, true).catch(oops); return; }
    if (moved) return; if (d.pan) { focus = null; path = null; return tick(); }
    if (mode && !first) { first = d; return tick(); }
    if (mode === 'link' && first !== d) { const a = first; setMode('link'); linkDialog(a.e, d.e).catch(oops); return; }
    if (mode === 'path' && first !== d) { const p = bfs(first.id, d.id); setMode('path'); path = p; focus = null; info.textContent = p ? `${p.length - 1} step${p.length > 2 ? 's' : ''}: ${p.map(i => byId(i).title).join(' → ')}` : 'No chain of links connects those two.'; return tick(); }
    focus = d.id; path = null; tick(); openDoc(d.e);
  };
  cv.onwheel = ev => { ev.preventDefault(); const r = cv.getBoundingClientRect(), x = ev.clientX - r.left - W() / 2 - ox, y = ev.clientY - r.top - Ht() / 2 - oy, f = Math.exp(-ev.deltaY * .0016), nk = Math.max(.15, Math.min(4, k * f)); ox -= x * (nk / k - 1); oy -= y * (nk / k - 1); k = nk; tick(); };
  build(); for (let i = 0; i < 160 && N.length < 400; i++) sim(); const ro = new ResizeObserver(() => tick()); ro.observe(wrap); requestAnimationFrame(() => { fit(); loop(); }); document.fonts.ready.then(() => !dead && tick());
  return { refresh: () => { build(); loop(); }, cleanup: () => { dead = true; cancelAnimationFrame(raf); ro.disconnect(); } };
}
