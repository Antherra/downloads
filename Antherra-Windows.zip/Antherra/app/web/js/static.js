// A still map for previews and reports: real tiles in Web Mercator with the case's points on top.
import { h, svg, S, AUTH, coord } from './core.js';
const T = 256, rad = Math.PI / 180;
const world = (la, lo) => [(lo + 180) / 360, (1 - Math.asinh(Math.tan(Math.max(-85, Math.min(85, la)) * rad)) / Math.PI) / 2];
export const tileUrl = t => `/tile/${t.style}/${t.z}/${t.tx}/${t.ty}${t.style === 'osm' ? '' : '@2x'}.png?t=${encodeURIComponent(AUTH.v)}`;
// Which tiles show these points in a w by ht frame, and where everything lands in it.
export function view(pts, w, ht, o = {}) {
  const { ax = .5, ay = .5, fx = .66, fy = .58, one = 10 } = o;
  const P = pts.map(p => world(...p)), lo = i => Math.min(...P.map(p => p[i])), hi = i => Math.max(...P.map(p => p[i]));
  const fit = Math.log2(Math.min(w * fx / Math.max(hi(0) - lo(0), 1e-9), ht * fy / Math.max(hi(1) - lo(1), 1e-9)) / T);
  const z = Math.max(1, Math.min(pts.length > 1 ? 14 : one, Math.floor(fit))), n = 2 ** z, k = T * n, x0 = (lo(0) + hi(0)) / 2 * k - w * ax;
  let y0 = (lo(1) + hi(1)) / 2 * k - ht * ay; if (k > ht) y0 = Math.max(0, Math.min(k - ht, y0)); // stay off the poles
  const tiles = [], style = S.settings?.keys?.carto ? 'dark' : 'osm';
  for (let ty = Math.max(0, Math.floor(y0 / T)); ty <= Math.min(n - 1, Math.floor((y0 + ht - .01) / T)); ty++) for (let tx = Math.floor(x0 / T); tx <= Math.floor((x0 + w - .01) / T); tx++) tiles.push({ style, z, tx: ((tx % n) + n) % n, ty, x: tx * T - x0, y: ty * T - y0 });
  return { tiles, at: P.map(p => [p[0] * k - x0, p[1] * k - y0]) };
}
export function still(points, w = 640, ht = 360) {
  const pts = points.filter(p => isFinite(p[0]) && isFinite(p[1])), box = h('span.media');
  if (!pts.length) { box.append(h('span.mapgrid'), h('span.stampbox.dot', 'no places yet')); return box; }
  const v = view(pts, w, ht), carto = S.settings?.keys?.carto, layer = h('span.tiles', { class: carto ? '' : 'osm-night' }), pc = (a, b) => (a / b * 100).toFixed(4) + '%';
  v.tiles.forEach(t => layer.append(h('img', { src: tileUrl(t), alt: '', loading: 'lazy', onerror: e => e.target.remove(), style: { left: pc(t.x, w), top: pc(t.y, ht), width: pc(T + .6, w), height: pc(T + .6, ht) } })));
  const g = svg('svg', { viewBox: `0 0 ${w} ${ht}`, 'aria-hidden': 'true' }), r = Math.max(8, w / 40), seen = new Set();
  v.at.forEach(([x, y]) => { const key = Math.round(x / 3) + ',' + Math.round(y / 3); if (seen.has(key)) return; seen.add(key); g.append(svg('circle', { cx: x, cy: y, r, fill: 'none', stroke: '#a8dcff', 'stroke-width': Math.max(1.6, w / 320) }), svg('circle', { cx: x, cy: y, r: Math.max(1.4, w / 260), fill: '#a8dcff' })); });
  box.append(h('span.frame', { style: { aspectRatio: `${w} / ${ht}` } }, layer, h('span.mapgrid'), g)); // kept in proportion; the box may crop it
  if (w > 400) box.append(h('span.stampbox.dot', coord(...pts[0])), h('span.credit', carto ? '© OpenStreetMap © CARTO' : '© OpenStreetMap contributors'));
  else box.title = carto ? '© OpenStreetMap © CARTO' : '© OpenStreetMap contributors';
  return box;
}

// A map that fills its box at the box's real size, so nothing is stretched or cropped. Redrawn when the box changes.
export function fillMap(points) {
  const box = h('div.fillmap', { 'aria-hidden': 'true' }), pts = points.filter(p => isFinite(p[0]) && isFinite(p[1])); let last = '', t = 0;
  const draw = () => {
    const w = Math.ceil(box.clientWidth / 40) * 40, ht = Math.ceil(box.clientHeight / 40) * 40, key = w + 'x' + ht; if (!w || !ht || key === last) return; last = key;
    if (!pts.length) return box.replaceChildren(h('span.mapgrid'));
    const wide = box.clientWidth > 760, v = view(pts, w, ht, wide ? { ax: .68, ay: .42, fx: .42, fy: .44, one: 11 } : { ax: .62, ay: Math.min(.36, 150 / ht), fx: .5, fy: .22, one: 10 }), carto = S.settings?.keys?.carto;
    const layer = h('span.tiles', { class: carto ? '' : 'osm-night' }, v.tiles.map(t => h('img', { src: tileUrl(t), alt: '', onerror: e => e.target.remove(), style: { left: t.x + 'px', top: t.y + 'px', width: T + .6 + 'px', height: T + .6 + 'px' } })));
    const g = svg('svg', { width: w, height: ht, viewBox: `0 0 ${w} ${ht}` }), seen = new Set(), r = pts.length > 1 ? 14 : wide ? 30 : 24;
    v.at.forEach(([x, y]) => { const k = Math.round(x / 8) + ',' + Math.round(y / 8); if (seen.has(k)) return; seen.add(k); g.append(svg('circle', { cx: x, cy: y, r: r + 5, fill: 'none', stroke: '#a8dcff', 'stroke-opacity': .16, 'stroke-width': 6 }), svg('circle', { cx: x, cy: y, r, fill: 'none', stroke: '#a8dcff', 'stroke-width': 2 }), svg('circle', { cx: x, cy: y, r: 2.5, fill: '#a8dcff' })); });
    box.replaceChildren(layer, h('span.mapgrid'), g, v.at.length === 1 && wide ? h('span.at.dot', { style: { left: v.at[0][0] + r + 12 + 'px', top: v.at[0][1] - 13 + 'px' } }, coord(...pts[0])) : '');
  };
  const ro = new ResizeObserver(() => { clearTimeout(t); t = setTimeout(draw, last ? 120 : 0); }); ro.observe(box); setTimeout(draw, 30); // the observer alone waits for a painted frame
  box.stop = () => ro.disconnect();
  return box;
}
