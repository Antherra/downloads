// Coordinate formats and solar position. Pure functions.
const R = Math.PI / 180;
export const dms = (a, b) => { const f = (v, p, n) => { let s = Math.round(Math.abs(v) * 36000) / 10, d = Math.floor(s / 3600), m = Math.floor((s - d * 3600) / 60); return `${d}°${String(m).padStart(2, 0)}′${(s - d * 3600 - m * 60).toFixed(1).padStart(4, 0)}″${v < 0 ? n : p}`; }; return f(a, 'N', 'S') + ' ' + f(b, 'E', 'W'); };
export function utm(lat, lon) {
  if (lat < -80 || lat > 84) return null;
  let z = Math.floor((lon + 180) / 6) % 60 + 1;
  if (lat >= 56 && lat < 64 && lon >= 3 && lon < 12) z = 32;
  if (lat >= 72) { if (lon >= 0 && lon < 9) z = 31; else if (lon >= 9 && lon < 21) z = 33; else if (lon >= 21 && lon < 33) z = 35; else if (lon >= 33 && lon < 42) z = 37; }
  const a = 6378137, f = 1 / 298.257223563, e2 = f * (2 - f), ep = e2 / (1 - e2), k0 = .9996, p = lat * R, l = (lon - (z * 6 - 183)) * R;
  const N = a / Math.sqrt(1 - e2 * Math.sin(p) ** 2), T = Math.tan(p) ** 2, C = ep * Math.cos(p) ** 2, A = Math.cos(p) * l;
  const M = a * ((1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256) * p - (3 * e2 / 8 + 3 * e2 ** 2 / 32 + 45 * e2 ** 3 / 1024) * Math.sin(2 * p) + (15 * e2 ** 2 / 256 + 45 * e2 ** 3 / 1024) * Math.sin(4 * p) - 35 * e2 ** 3 / 3072 * Math.sin(6 * p));
  const E = k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep) * A ** 5 / 120) + 500000;
  let Nn = k0 * (M + N * Math.tan(p) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep) * A ** 6 / 720)); if (lat < 0) Nn += 1e7;
  return { z, band: 'CDEFGHJKLMNPQRSTUVWXX'[Math.floor((lat + 80) / 8)], e: E, n: Nn };
}
export const utmStr = (a, b) => { const u = utm(a, b); return u ? `${u.z}${u.band} ${u.e.toFixed(0)} ${u.n.toFixed(0)}` : 'outside UTM'; };
export function mgrs(a, b) {
  const u = utm(a, b); if (!u) return 'outside MGRS'; const col = 'ABCDEFGHJKLMNPQRSTUVWXYZ'[((u.z - 1) % 3) * 8 + Math.floor(u.e / 1e5) - 1], row = 'ABCDEFGHJKLMNPQRSTUV'[(Math.floor(u.n / 1e5) + (u.z % 2 ? 0 : 5)) % 20], p = v => String(Math.floor(v % 1e5)).padStart(5, 0);
  return `${u.z}${u.band} ${col}${row} ${p(u.e)} ${p(u.n)}`;
}
export function pluscode(lat, lon) {
  const A = '23456789CFGHJMPQRVWX'; let a = Math.min(179.9999999, lat + 90), b = ((lon + 180) % 360 + 360) % 360, s = '', r = 20;
  for (let i = 0; i < 5; i++) { const x = Math.floor(a / r + 1e-10), y = Math.floor(b / r + 1e-10); s += A[x] + A[y]; a -= x * r; b -= y * r; r /= 20; if (i === 3) s += '+'; } return s;
}
export function geohash(lat, lon, n = 10) { const B = '0123456789bcdefghjkmnpqrstuvwxyz'; let a = [-90, 90], o = [-180, 180], s = '', bit = 0, ch = 0, ev = true; while (s.length < n) { const r = ev ? o : a, v = ev ? lon : lat, m = (r[0] + r[1]) / 2; ch <<= 1; if (v >= m) { ch |= 1; r[0] = m; } else r[1] = m; ev = !ev; if (++bit === 5) { s += B[ch]; bit = ch = 0; } } return s; }
// NOAA solar equations. ms = UTC epoch. Returns degrees: azimuth from north, altitude above horizon.
export function sun(ms, lat, lon) {
  const jc = (ms / 864e5 + 2440587.5 - 2451545) / 36525, L0 = (280.46646 + jc * (36000.76983 + jc * .0003032)) % 360, M = 357.52911 + jc * (35999.05029 - .0001537 * jc), e = .016708634 - jc * (.000042037 + .0000001267 * jc);
  const C = Math.sin(M * R) * (1.914602 - jc * (.004817 + .000014 * jc)) + Math.sin(2 * M * R) * (.019993 - .000101 * jc) + Math.sin(3 * M * R) * .000289, lam = L0 + C - .00569 - .00478 * Math.sin((125.04 - 1934.136 * jc) * R);
  const ob = 23 + (26 + (21.448 - jc * (46.815 + jc * (.00059 - jc * .001813))) / 60) / 60 + .00256 * Math.cos((125.04 - 1934.136 * jc) * R), dec = Math.asin(Math.sin(ob * R) * Math.sin(lam * R)), y = Math.tan(ob * R / 2) ** 2;
  const eq = 4 / R * (y * Math.sin(2 * L0 * R) - 2 * e * Math.sin(M * R) + 4 * e * y * Math.sin(M * R) * Math.cos(2 * L0 * R) - .5 * y * y * Math.sin(4 * L0 * R) - 1.25 * e * e * Math.sin(2 * M * R));
  const min = (ms % 864e5 + 864e5) % 864e5 / 6e4, tst = ((min + eq + 4 * lon) % 1440 + 1440) % 1440, ha = (tst / 4 - 180) * R, p = lat * R;
  let alt = Math.asin(Math.max(-1, Math.min(1, Math.sin(p) * Math.sin(dec) + Math.cos(p) * Math.cos(dec) * Math.cos(ha)))) / R;
  const az = (Math.atan2(Math.sin(ha), Math.cos(ha) * Math.sin(p) - Math.tan(dec) * Math.cos(p)) / R + 180 + 360) % 360;
  if (alt > -1) alt += alt > 85 ? 0 : (1.02 / Math.tan((alt + 10.3 / (alt + 5.11)) * R)) / 60; // refraction
  return { az, alt };
}
