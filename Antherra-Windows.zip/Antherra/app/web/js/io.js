import { saveAll, isDate, TYPES, findEntity } from './core.js';
const q = v => { let s = v == null ? '' : String(v); if (/^[=+\-@\t]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s; return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
export const csv = rows => { if (!rows.length) return ''; const k = Object.keys(rows[0]); return [k, ...rows.map(r => k.map(x => r[x]))].map(r => r.map(q).join(',')).join('\n'); };
export function parseCsv(t) {
  const rows = [[]]; let c = '', inq = false; t = t.replace(/^﻿/, ''); const sep = (t.split('\n')[0].match(/;/g) || []).length > (t.split('\n')[0].match(/,/g) || []).length ? ';' : ',';
  for (let i = 0; i < t.length; i++) { const x = t[i]; if (inq) { if (x === '"') { if (t[i + 1] === '"') { c += '"'; i++; } else inq = false; } else c += x; } else if (x === '"') inq = true; else if (x === sep) { rows.at(-1).push(c); c = ''; } else if (x === '\n') { rows.at(-1).push(c.replace(/\r$/, '')); c = ''; rows.push([]); } else c += x; }
  rows.at(-1).push(c); const hd = rows.shift().map(s => s.trim().toLowerCase()); return rows.filter(r => r.some(x => x)).map(r => Object.fromEntries(hd.map((k, i) => [k, (r[i] || '').trim()])));
}
const pick = (r, ...ks) => { for (const k of ks) if (r[k]) return r[k]; };
// Rows with a date become events; rows without become entities.
export async function importRows(rows) {
  const out = []; let dup = 0, odd = 0;
  for (const r of rows) {
    const title = pick(r, 'name', 'title', 'label', 'event', 'headline', 'what'), date = pick(r, 'date', 'when', 'start', 'timestamp'), lat = parseFloat(pick(r, 'lat', 'latitude', 'y')), lon = parseFloat(pick(r, 'lon', 'lng', 'long', 'longitude', 'x'));
    if (!title) continue; const loc = isFinite(lat) && isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180 ? { lat, lon } : {};
    const d = (date || '').replace(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/, (_, a, b, c) => `${c}-${b.padStart(2, 0)}-${a.padStart(2, 0)}`).replace(' ', 'T').slice(0, 16);
    const base = { title, status: 'unverified', text: pick(r, 'notes', 'description', 'text', 'detail'), url: pick(r, 'url', 'link', 'source'), sources: [{ name: 'Imported file', at: new Date().toISOString() }], ...loc };
    if (date && !isDate(d)) odd++;
    if (isDate(d)) out.push({ kind: 'event', ...base, date: d, place: r.place, lane: r.lane });
    else { const type = TYPES[(r.type || '').toLowerCase()] ? r.type.toLowerCase() : loc.lat != null ? 'place' : 'text'; if (findEntity(type, title)) { dup++; continue; } out.push({ kind: 'entity', type, fields: [], ...base }); }
  }
  for (let i = 0; i < out.length; i += 300) await saveAll(out.slice(i, i + 300));
  return out.length ? `Imported ${out.filter(x => x.kind === 'event').length} events and ${out.filter(x => x.kind === 'entity').length} entities${dup ? `; skipped ${dup} already filed` : ''}.${odd ? ` ${odd} had a date Antherra could not read and were not put on the timeline; use 2020-07-25 or 25.07.2020.` : ''}` : 'No usable rows. The file needs a name or title column.';
}
export async function importGeo(name, text) {
  const pts = [], shapes = [];
  if (/\.(geo)?json$/i.test(name)) {
    const g = JSON.parse(text), walk = f => { if (!f) return; if (f.features) return f.features.forEach(walk); const geo = f.geometry || f, p = f.properties || {}, title = String(p.name || p.title || p.Name || 'Imported point'), date = p.date; const go = geo => { if (!geo) return; const c = geo.coordinates; if (geo.type === 'Point') pts.push({ name: title, lat: c[1], lon: c[0], date, notes: p.description }); else if (geo.type === 'LineString') shapes.push({ geom: 'line', title, points: c.map(x => [x[1], x[0]]) }); else if (geo.type === 'Polygon') shapes.push({ geom: 'area', title, points: c[0].map(x => [x[1], x[0]]) }); else if (/^Multi/.test(geo.type)) c.forEach(x => go({ type: geo.type.slice(5), coordinates: x })); else (geo.geometries || []).forEach(go); }; go(geo); }; walk(g);
  } else {
    const x = new DOMParser().parseFromString(text, 'text/xml'); if (x.querySelector('parsererror')) throw new Error('That file is not readable XML.');
    const T = (e, n) => e.getElementsByTagName(n)[0]?.textContent.trim(), cs = s => s.trim().split(/\s+/).map(c => c.split(',').map(Number)).map(c => [c[1], c[0]]);
    for (const p of x.getElementsByTagName('Placemark')) { const n = T(p, 'name') || 'Imported', pt = p.getElementsByTagName('Point')[0], ln = p.getElementsByTagName('LineString')[0], po = p.getElementsByTagName('Polygon')[0]; if (pt) { const [a, b] = cs(T(pt, 'coordinates'))[0]; pts.push({ name: n, lat: a, lon: b, notes: T(p, 'description'), date: T(p, 'when') }); } if (ln) shapes.push({ geom: 'line', title: n, points: cs(T(ln, 'coordinates')) }); if (po) shapes.push({ geom: 'area', title: n, points: cs(T(po, 'coordinates')) }); }
    for (const w of x.getElementsByTagName('wpt')) pts.push({ name: T(w, 'name') || 'Waypoint', lat: w.getAttribute('lat'), lon: w.getAttribute('lon'), date: T(w, 'time') });
    for (const t of [...x.getElementsByTagName('trkseg'), ...x.getElementsByTagName('rte')]) shapes.push({ geom: 'line', title: 'Track', points: [...t.querySelectorAll('trkpt,rtept')].map(p => [+p.getAttribute('lat'), +p.getAttribute('lon')]) });
  }
  if (shapes.length) await saveAll(shapes.filter(s => s.points.length > 1).map(s => ({ kind: 'shape', ...s })));
  const m = pts.length ? await importRows(pts.map(p => ({ ...p, lat: String(p.lat), lon: String(p.lon) }))) : '';
  return (m + (shapes.length ? ` ${shapes.length} lines or areas added.` : '')).trim() || 'Nothing on a map in that file.';
}
