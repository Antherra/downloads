import { h, $, S, AUTH, all, byId, save, saveAll, remove, get, btn, icon, iconPath, svg, tcol, fmt, t0, t1, coord, form, toast, oops, guard, go, caseUrl, ext, today, pickFile, download, slug, dialog, parseCoord, isDate, TYPES, ensureEntity, changed, addFiles, safe } from './core.js';
import { openDoc, editEntity, editEvent } from './drawer.js';
import { importGeo, importRows, parseCsv } from './io.js';
import { mgrs, dms } from './geo.js';
import { nasaDay } from './imagery.js';
const L = window.L;
let mem = {}; // view per case, for this session
// OSM's tile policy asks for a referrer; only this app's local origin is sent.
const osm = className => L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, className, attribution: '© OpenStreetMap contributors', referrerPolicy: 'strict-origin-when-cross-origin' });
const BASES = {
  night: ['Night', () => osm('osm-night')],
  day: ['Day', () => osm('osm-day')],
  sat: ['Satellite', () => L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Imagery © Esri, Maxar, Earthstar Geographics' })],
  street: ['Street', () => osm('')],
  daily: ['Daily satellite (NASA)', d => L.tileLayer(`/tile/gibs/${nasaDay(d)}/${d}/{z}/{x}/{y}.img?t=${encodeURIComponent(AUTH.v)}`, { maxNativeZoom: 9, maxZoom: 13, attribution: 'NASA EOSDIS GIBS' })],
};
const carto = s => L.tileLayer(`/tile/${s}/{z}/{x}/{y}{r}.png?t=${encodeURIComponent(AUTH.v)}`, { maxZoom: 20, attribution: '© OpenStreetMap © CARTO' });
const CARTO = { cdark: ['Night (CARTO)', () => carto('dark')], clight: ['Day (CARTO)', () => carto('light')], cvoy: ['Voyager (CARTO)', () => carto('voyager')] };
const bases = () => S.settings.keys.carto ? { ...CARTO, ...BASES } : BASES;
const KM = { line: 'Route', area: 'Area', circle: 'Radius' };
export const launch = (a, b) => [['Google Maps', `https://www.google.com/maps/@${a},${b},17z/data=!3m1!1e3`], ['Street View', `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${a},${b}`], ['Yandex Maps', `https://yandex.com/maps/?ll=${b}%2C${a}&z=17&l=sat`], ['Copernicus Browser', `https://browser.dataspace.copernicus.eu/?zoom=14&lat=${a}&lng=${b}`], ['Esri Wayback', `https://livingatlas.arcgis.com/wayback/#mapCenter=${b},${a},16`], ['Mapillary', `https://www.mapillary.com/app/?lat=${a}&lng=${b}&z=16`], ['Wikimapia', `https://wikimapia.org/#lang=en&lat=${a}&lon=${b}&z=16`]];

export function mapView(box, params) {
  const st = mem[S.case.id] ||= { base: S.settings.keys.carto ? 'cdark' : 'night', day: new Date(Date.now() - 864e5).toISOString().slice(0, 10), live: {}, tags: true, links: false, events: true, evidence: true, time: null };
  const canvas = h('div', { style: { position: 'absolute', inset: 0 } }), read = h('div.readout.dot', ''), wrap = h('div.exhibit.grow', { style: { position: 'relative' } }, canvas, h('div.mapgrid'), read);
  const side = h('div.mapside', { hidden: !st.side }), timebar = h('div.timebar');
  const find = h('input', { placeholder: 'Go to a place or coordinates', 'aria-label': 'Go to', style: { width: '230px' } });
  let mode = null, tmp = [], tmpL = null, playing = null;
  const hint = h('span.mute', '');
  const toolB = {}, setMode = m => { mode = mode === m ? null : m; tmp = []; tmpL?.remove(); tmpL = null; Object.entries(toolB).forEach(([k, b]) => b.classList.toggle('on', k === mode)); canvas.style.cursor = mode ? 'crosshair' : ''; map.doubleClickZoom[mode ? 'disable' : 'enable'](); hint.textContent = { point: 'Click to place a point.', measure: 'Click along the line. Double-click to finish.', line: 'Click along the route. Double-click to finish.', area: 'Click the corners. Double-click to finish.', circle: 'Click the centre, then the edge.' }[mode] || ''; };
  box.replaceChildren(h('div.full-page', h('div.tools', h('form', { onsubmit: guard(async e => { e.preventDefault(); const c = parseCoord(find.value); if (c) return menu(L.latLng(c), true); const r = await get('/api/geocode?q=' + encodeURIComponent(find.value)); if (!r.length) return toast('No such place found.'); map.setView([r[0].lat, r[0].lon], 14); popup(L.latLng(r[0].lat, r[0].lon), r[0].sub, r[0].title); }) }, find),
    h('span.sep'), ...[['point', 'Point'], ['line', 'Route'], ['area', 'Area'], ['circle', 'Radius'], ['measure', 'Measure']].map(([k, n]) => toolB[k] = btn(n, () => setMode(k), 'small')), hint, h('span.grow'),
    btn('Fit', () => fit(), 'small'), btn('Import', async () => { for (const f of await pickFile('.geojson,.json,.kml,.gpx,.csv', true)) toast(/\.csv$/i.test(f.name) ? await importRows(parseCsv(await f.text())) : await importGeo(f.name, await f.text())); fit(); }, 'small'), btn('Export', exportGeo, 'small'), btn('Layers', () => { st.side = side.hidden; side.hidden = !side.hidden; }, 'small')), wrap, timebar));
  wrap.append(side);
  const map = L.map(canvas, { zoomControl: false, fadeAnimation: false, worldCopyJump: true, zoomSnap: .5 }).setView(st.c || [20, 10], st.z || 2.5);
  L.control.zoom({ position: 'bottomright' }).addTo(map); map.attributionControl.setPrefix(false);
  let base; const setBase = () => { base?.remove(); if (!bases()[st.base]) st.base = 'night'; base = bases()[st.base][1](st.day).addTo(map); base.bringToBack(); canvas.classList.toggle('day', ['day', 'street', 'clight', 'cvoy'].includes(st.base)); };
  setBase();
  const pins = L.markerClusterGroup({ showCoverageOnHover: false, maxClusterRadius: 26, disableClusteringAtZoom: 15, iconCreateFunction: c => L.divIcon({ html: h('div', String(c.getChildCount())), className: 'clus' }) }).addTo(map), shapes = L.layerGroup().addTo(map), lines = L.layerGroup().addTo(map), liveG = L.layerGroup().addTo(map);
  map.on('moveend', () => { st.c = map.getCenter(); st.z = map.getZoom(); });
  map.on('mousemove', e => { const w = e.latlng.wrap(); read.textContent = `${coord(w.lat, w.lng)}  z${map.getZoom()}`; });

  // ---- drawing tools
  const km = m => m < 1000 ? m.toFixed(0) + ' m' : (m / 1000).toFixed(m < 1e5 ? 2 : 0) + ' km';
  const len = p => p.slice(1).reduce((n, x, i) => n + map.distance(p[i], x), 0);
  function sketch(extra) { tmpL?.remove(); const p = extra ? [...tmp, extra] : tmp; if (!p.length) return; const o = { color: '#a8dcff', weight: 2, dashArray: '5 5', interactive: false }; tmpL = mode === 'circle' ? L.circle(tmp[0], { ...o, radius: p[1] ? map.distance(tmp[0], p[1]) : 1 }) : mode === 'area' ? L.polygon(p, o) : L.polyline(p, o); tmpL.addTo(map); const r = p.length > 1 ? (mode === 'circle' ? map.distance(tmp[0], p[1]) : len(p)) : 0; if (r) hint.textContent = km(r); }
  async function finish() {
    const p = tmp.filter((x, i) => !i || map.distance(x, tmp[i - 1]) > .5).map(x => [+x.lat.toFixed(6), +x.lng.toFixed(6)]), m = mode;
    if (m === 'measure') { if (p.length > 1) toast('Distance: ' + km(len(p.map(x => L.latLng(x))))); return setMode(m); }
    if (p.length < (m === 'area' ? 3 : 2)) return setMode(m);
    const d = { kind: 'shape', geom: m, points: m === 'circle' ? [p[0]] : p, radius: m === 'circle' ? Math.round(map.distance(p[0], p[1])) : undefined }; setMode(m);
    const v = await form('Name this ' + KM[m].toLowerCase(), [{ k: 'title', label: 'Name', req: true, full: true }, { k: 'text', label: 'Note', full: true }]); if (v) save({ ...d, ...v });
  }
  map.on('click', guard(async e => {
    const ll = e.latlng.wrap();
    if (!mode) return menu(ll);
    if (mode === 'point') { setMode('point'); return editEntity(null, { type: 'place', lat: +ll.lat.toFixed(6), lon: +ll.lng.toFixed(6) }); }
    tmp.push(ll); sketch(); if (mode === 'circle' && tmp.length === 2) finish();
  }));
  map.on('mousemove', e => { if (mode && tmp.length) sketch(e.latlng.wrap()); });
  map.on('dblclick', e => { if (mode && mode !== 'point' && mode !== 'circle') finish(); });

  function popup(ll, sub, title) {
    const a = +ll.lat.toFixed(6), b = +ll.lng.toFixed(6), q = `lat=${a}&lon=${b}`;
    L.popup({ maxWidth: 320 }).setLatLng(ll).setContent(h('div', title && h('h3', { style: { marginBottom: '4px' } }, title), sub && h('p.mute', sub), h('p.dot', coord(a, b)), h('p.mute', { style: { fontSize: '12px' } }, dms(a, b), h('br'), mgrs(a, b)),
      h('div.row', { style: { margin: '8px 0' } }, btn('Add place', () => editEntity(null, { type: 'place', title: title || '', lat: a, lon: b }), 'small primary'), btn('Add event', () => editEvent(null, { lat: a, lon: b, place: title || '' }), 'small'), btn('What is here', () => go(`${caseUrl('lookup')}?q=${a},${b}&type=coords`), 'small'), btn('Imagery', () => go(`${caseUrl('imagery')}?${q}`), 'small'), btn('Sun', () => go(`${caseUrl('verify')}?tool=sun&${q}`), 'small'), btn('Weather', () => go(`${caseUrl('verify')}?tool=weather&${q}`), 'small')),
      h('div.row', { style: { gap: '4px 12px', fontSize: '13px' } }, launch(a, b).map(([n, u]) => ext(u, n))))).openOn(map);
  }
  const menu = (ll, zoom) => { if (zoom) map.setView(ll, Math.max(map.getZoom(), 14)); popup(ll); };

  // ---- case data
  const located = () => [...all('entity'), ...(st.events ? all('event') : []), ...(st.evidence ? all('evidence') : [])].filter(d => d.lat != null && d.lon != null);
  // With a time set, dated items show only inside it; undated things stay, since we do not know.
  const inTime = d => { if (st.time == null) return true; if (d.kind === 'event') return t0(d.date) <= st.time; if (d.kind === 'entity') { const ev = all('event').filter(e => (e.entities || []).includes(d.id)); return !ev.length || ev.some(e => t0(e.date) <= st.time); } return !d.date || t0(d.date) <= st.time; };
  const mk = (d, o = {}) => { const e = h('div', h('i'), h('b', d.kind === 'event' ? `${fmt(d.date)} ${d.title}` : d.title)); e.style.setProperty('--c', d.kind === 'event' ? '#fff' : d.kind === 'evidence' ? '#d8d6dd' : tcol(d.type)); return L.marker([d.lat, d.lon], { icon: L.divIcon({ html: e, className: 'pin', iconSize: [0, 0] }), title: d.title, alt: d.title, draggable: false, ...o }); };
  function draw() {
    pins.clearLayers(); shapes.clearLayers(); lines.clearLayers(); wrap.classList.toggle('notags', !st.tags);
    const vis = located().filter(inTime); pins.addLayers(vis.map(d => mk(d).on('click', () => openDoc(d))));
    all('shape').forEach(s => { const o = { color: '#a8dcff', weight: 2, fillOpacity: .12 }, l = s.geom === 'circle' ? L.circle(s.points[0], { ...o, radius: s.radius }) : s.geom === 'area' ? L.polygon(s.points, o) : L.polyline(s.points, o); l.addTo(shapes).on('click', ev => { if (mode) return; L.DomEvent.stop(ev); L.popup().setLatLng(ev.latlng).setContent(h('div', h('h3', s.title || 'Shape'), s.text && h('p.mute', s.text), h('p.dot', s.geom === 'circle' ? 'Radius ' + km(s.radius) : 'Length ' + km(len(s.points.map(x => L.latLng(x))))), h('div.row', btn('Rename', async () => { const v = await form('Edit', [{ k: 'title', label: 'Name', req: true, full: true }, { k: 'text', label: 'Note', full: true }], s); if (v) save({ ...s, ...v }); }, 'small'), btn('Remove', () => { map.closePopup(); remove(s); }, 'small quiet')))).openOn(map); }); });
    if (st.links) all('link').forEach(l => { const a = byId(l.a), b = byId(l.b); if (a?.lat != null && b?.lat != null) L.polyline([[a.lat, a.lon], [b.lat, b.lon]], { color: '#fff', weight: 1.2, opacity: .55, dashArray: '2 5' }).bindTooltip(h('span', `${a.title} ${l.rel} ${b.title}`)).addTo(lines); });
    drawTime();
  }
  const fit = () => { const p = [...located().map(d => [d.lat, d.lon]), ...all('shape').flatMap(s => s.points)]; if (p.length) map.fitBounds(L.latLngBounds(p).pad(.25), { maxZoom: 14 }); };
  function drawTime() {
    const ev = all('event').filter(e => isFinite(t0(e.date))).sort((a, b) => t0(a.date) - t0(b.date)); if (ev.length < 2) { timebar.hidden = true; return; } timebar.hidden = false;
    const a = t0(ev[0].date), b = Math.max(...ev.map(e => t1(e.end || e.date))), cur = ev.filter(e => st.time != null && t0(e.date) <= st.time).at(-1);
    const r = h('input.grow', { type: 'range', min: 0, max: 1000, value: st.time == null ? 1000 : Math.round((st.time - a) / (b - a) * 1000), 'aria-label': 'Show the case up to this moment', oninput: e => { st.time = +e.target.value >= 1000 ? null : a + (b - a) * e.target.value / 1000; draw(); $('input[type=range]', timebar)?.focus(); } });
    timebar.replaceChildren(h('button.sq', { 'aria-label': playing ? 'Pause' : 'Play through time', onclick: () => { if (playing) { clearInterval(playing); playing = null; return drawTime(); } let i = 0; const step = () => { if (i >= ev.length) { clearInterval(playing); playing = null; st.time = null; return draw(); } st.time = t0(ev[i].date) + 1; const e = ev[i++]; if (e.lat != null) map.panTo([e.lat, e.lon]); draw(); }; playing = setInterval(step, 1400); step(); } }, icon(playing ? 'pause' : 'play', 15)), h('span.dot', fmt(ev[0].date)), r, h('span.dot', st.time == null ? 'all dates' : fmt(new Date(st.time).toISOString().slice(0, 10))), cur && h('span.mute', { style: { maxWidth: '34ch', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, cur.title));
  }
  // ---- live layers
  const LIVE = { aircraft: 'Aircraft now', quakes: 'Earthquakes, 7 days', hazards: 'Fires, storms, volcanoes', photos: 'Geotagged photos at centre' };
  const loadLive = guard(async k => {
    const b = map.getBounds(), c = map.getCenter(), r = await get(`/api/live/${k}?s=${b.getSouth()}&n=${b.getNorth()}&w=${b.getWest()}&e=${b.getEast()}&lat=${c.lat}&lon=${c.lng}`); if (!st.live[k]) return;
    (st.live[k] = L.layerGroup()).addTo(liveG); if (!r.length) toast(LIVE[k] + ': nothing in view.');
    r.forEach(d => { const col = { aircraft: '#f0d98c', quakes: '#ffb48c', hazards: '#ff8f6b', photos: '#c9e7b3' }[k], e = h('div', k === 'aircraft' ? svg('svg', { viewBox: '0 0 20 20', width: 20, height: 20, style: `transform:rotate(${+d.heading || 0}deg)` }, svg('path', { d: 'M10 1l1.500 6 7 4v2l-7-2-.5 4.500 2 1.500v1.500l-3-1-3 1V17l2-1.500-.5-4.500-7 2v-2l7-4z', fill: col, stroke: '#0f0e13', 'stroke-width': .8 })) : h('i'), h('b', d.title)); e.style.setProperty('--c', col);
      L.marker([d.lat, d.lon], { icon: L.divIcon({ html: e, className: 'pin live', iconSize: [0, 0] }), alt: d.title }).bindPopup(() => h('div', d.thumb && h('img', { src: d.thumb, alt: '', style: { width: '100%', borderRadius: '8px', marginBottom: '8px' }, referrerpolicy: 'no-referrer' }), h('h3', d.title), h('dl.kv', { style: { margin: '8px 0' } }, (d.fields || []).map(([a, b]) => [h('dt', a), h('dd', b)])), h('div.row', btn('Add to case', async () => { const now = new Date().toISOString(), src = [{ name: LIVE[k], url: d.url, at: now }]; if (k === 'quakes' || k === 'hazards') await save({ kind: 'event', title: d.title, date: d.date, lat: d.lat, lon: d.lon, status: 'unverified', url: d.url, sources: src, lane: 'Natural events' }); else { const x = await ensureEntity(k === 'aircraft' ? 'aircraft' : 'document', k === 'aircraft' ? (d.fields.find(f => f[0] === 'Registration') || [0, d.title])[1] : d.title, { url: d.url, lat: d.lat, lon: d.lon, fields: d.fields, sources: src }); if (k === 'aircraft') await save({ kind: 'event', title: `${x.title} seen over ${coord(d.lat, d.lon)}`, date: now.slice(0, 16), lat: d.lat, lon: d.lon, entities: [x.id], status: 'unverified', url: d.url, sources: src, lane: 'Sightings' }); } changed(); toast('Filed ' + d.title); }, 'small primary'), ext(d.url, 'Source')))).addTo(st.live[k]); });
  });
  function drawSide() {
    const ck = (k, n) => h('label', h('input', { type: 'checkbox', checked: st[k], onchange: e => { st[k] = e.target.checked; draw(); } }), n);
    side.replaceChildren(h('span.label', 'Base map'), h('select', { 'aria-label': 'Base map', onchange: e => { st.base = e.target.value; setBase(); drawSide(); } }, Object.entries(bases()).map(([k, [n]]) => h('option', { value: k, selected: k === st.base }, n))), st.base === 'daily' && h('input', { type: 'date', value: st.day, max: today(), min: '2000-02-24', 'aria-label': 'Imagery date', style: { marginTop: '6px' }, onchange: e => { if (e.target.value) { st.day = e.target.value; setBase(); } } }), h('span.label', 'Case'), ck('events', 'Events'), ck('evidence', 'Evidence'), ck('links', 'Links between places'), ck('tags', 'Labels'),
      h('span.label', 'Live'), Object.entries(LIVE).map(([k, n]) => h('label', h('input', { type: 'checkbox', checked: !!st.live[k], onchange: e => { if (e.target.checked) { st.live[k] = true; loadLive(k); } else { if (st.live[k].remove) st.live[k].remove(); delete st.live[k]; } } }), n)), btn('Refresh live layers', () => { for (const k of Object.keys(st.live)) { st.live[k].remove?.(); st.live[k] = true; loadLive(k); } }, 'small quiet'));
  }
  function exportGeo() {
    const f = [...located().map(d => ({ type: 'Feature', geometry: { type: 'Point', coordinates: [d.lon, d.lat] }, properties: { name: d.title, kind: d.kind, type: d.type, date: d.date, status: d.status, description: d.text, url: d.url } })), ...all('shape').map(s => ({ type: 'Feature', geometry: s.geom === 'line' ? { type: 'LineString', coordinates: s.points.map(p => [p[1], p[0]]) } : s.geom === 'area' ? { type: 'Polygon', coordinates: [[...s.points, s.points[0]].map(p => [p[1], p[0]])] } : { type: 'Point', coordinates: [s.points[0][1], s.points[0][0]] }, properties: { name: s.title, radius_m: s.radius } }))];
    download(slug(S.case.title) + '.geojson', JSON.stringify({ type: 'FeatureCollection', features: f }, null, 1), 'application/geo+json');
  }
  st.live = {}; drawSide(); draw();
  const t = byId(params.get('id'));
  const ro = new ResizeObserver(() => map.invalidateSize()); ro.observe(canvas);
  if (t?.lat != null) { map.setView([t.lat, t.lon], Math.max(st.z || 0, 13)); } else if (!st.c) fit();
  return { refresh: draw, cleanup: () => { clearInterval(playing); ro.disconnect(); map.remove(); } };
}
