import { h, S, AUTH, detect, QT, btn, ext, safe, icon, stamp, blobUrl, ensureEntity, ensureLink, findEntity, save, all, toast, tname, coord, guard, empty, changed, isDate, putj, caseUrl, oops, parseCoord, norm, TYPES } from './core.js';
import { openDoc, typeTag } from './drawer.js';
const CLEAN = { url: q => q, domain: q => q.toLowerCase(), email: q => q.toLowerCase(), username: q => q.replace(/^@/, ''), coords: q => parseCoord(q)?.join(',') || q, siren: q => q.replace(/\s/g, ''), vessel: q => q };
const history = []; let last = null; // survives switching tabs within a session
const entType = t => ({ coords: 'place', lei: 'company', siren: 'company' }[t] || t);

export function lookup(box, params) {
  let type = params.get('type') || '', ctl = null, dead = false;
  const inp = h('input', { placeholder: 'A name, domain, address, number or place', 'aria-label': 'Look up', autocomplete: 'off', spellcheck: 'false', value: params.get('q') || last?.q || '', oninput: () => { if (!pinned) auto(); } });
  const sel = h('select', { 'aria-label': 'Kind', onchange: () => { pinned = true; type = sel.value; srcs(); } }, Object.entries(QT).map(([k, v]) => h('option', { value: k }, v)));
  let pinned = !!type;
  const chips = h('div.srcs'), out = h('div', { style: { marginTop: '26px' } }), go = h('button.primary', { type: 'submit' }, 'Look up');
  const off = new Set(S.settings.off);
  const auto = () => { const t = detect(inp.value); if (t !== type) { type = t; srcs(); } };
  const avail = () => S.settings.sources.filter(s => s.types.includes(type));
  const srcs = () => {
    sel.value = type; const g = {}; avail().forEach(s => (g[s.group] ||= []).push(s));
    chips.replaceChildren(...Object.entries(g).flatMap(([n, l]) => [h('b', n), ...l.map(s => { const nokey = s.key && !S.settings.keys[s.key], need = s.id === 'sanctions' && !Object.keys(S.settings.sanctions).length; return h('label', { title: s.local ? 'Runs on this computer; nothing is sent' : s.direct ? 'Visits the site you are investigating' : 'Your search term is sent to ' + s.host }, h('input', { type: 'checkbox', checked: !off.has(s.id) && !nokey && !need, disabled: nokey || need, 'data-id': s.id, onchange: e => { e.target.checked ? off.delete(s.id) : off.add(s.id); S.settings.off = [...off]; putj('/api/settings', { off: [...off] }).catch(oops); } }), h('span', s.name), nokey ? h('small', 'needs a key') : need ? h('small', 'lists not downloaded') : s.direct ? h('span.tag.tag-contradicted', 'contacts the target') : s.local ? h('small', 'stays here') : h('small', s.host)); })]));
  };
  const form = h('form', { onsubmit: e => { e.preventDefault(); run(); } }, h('div.ask', inp, sel, go), chips);
  box.replaceChildren(h('div.page', h('div.pagehead', h('div', h('h1', 'Look up'), h('p', 'Ask public registers, archives and networks at once. Every answer keeps its source and time.'))), form, out));

  async function run() {
    const raw = inp.value.trim(); if (!raw) return;
    const q = (CLEAN[type] || (x => x))(raw), ids = [...chips.querySelectorAll('input:checked')].map(i => i.dataset.id);
    if (!ids.length) return toast('Tick at least one source.');
    ctl?.abort(); ctl = new AbortController(); last = { q: raw, type, res: [], case: S.case.id, ids };
    const me = last; let wait = new Set(ids); go.disabled = true; show(me, wait);
    try {
      const r = await fetch('/api/lookup', { method: 'POST', signal: ctl.signal, headers: { 'X-Antherra-Token': AUTH.t, 'Content-Type': 'application/json' }, body: JSON.stringify({ q, type, sources: ids, case_id: S.case.id }) });
      if (!r.ok) throw new Error((await r.json()).error);
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
      for (; ;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); let i; while ((i = buf.indexOf('\n')) >= 0) { const x = JSON.parse(buf.slice(0, i)); buf = buf.slice(i + 1); me.res.push(x); wait.delete(x.id); if (!dead && last === me) show(me, wait); } }
    } catch (e) { if (e.name !== 'AbortError') oops(e); } finally { go.disabled = false; wait.clear(); if (!dead && last === me) show(me, wait); }
  }
  async function add(src, it, withRel, separate) {
    const me = last, cite = { name: src.name, url: it.url, at: src.at, raw_sha: src.raw_sha, query: me.q };
    const val = it.value || it.title, e = await ensureEntity(it.type, it.type === 'document' || it.type === 'url' ? it.title : val, { separate, url: it.url, lat: it.lat ?? null, lon: it.lon ?? null, fields: it.fields || [], sources: [cite] });
    const seedT = entType(me.type), seed = all('entity').find(x => norm(x.title) === norm(me.q) && x.id !== e.id) || findEntity(seedT, me.q.replace(/^@/, ''));
    if (seed && seed.id !== e.id && it.type === 'document') await ensureLink(e.id, seed.id, 'mentions', [cite]);
    const namesakes = []; for (const r of withRel) { const was = r.type === 'person' && findEntity('person', r.title); if (was && was.id !== e.id) namesakes.push(was.title); const o = await ensureEntity(r.type, r.title, { url: r.url, sources: [cite] }); await ensureLink(e.id, o.id, r.rel, [cite]); }
    changed(); if (namesakes.length) toast(`Linked to ${[...new Set(namesakes)].join(', ')}, already in the case under the same name. Check it is the same person.`, null, null, true); return e;
  }
  const dates = async (src, it, d, e) => { await save({ kind: 'event', title: d.title, date: d.date, status: 'unverified', url: it.url, entities: e ? [e.id] : [], sources: [{ name: src.name, url: it.url, at: src.at, raw_sha: src.raw_sha, query: last.q }] }); };
  function hit(src, it) {
    const have = findEntity(it.type, it.type === 'document' || it.type === 'url' ? it.title : it.value || it.title, it.url), rel = it.related || [], ticks = new Set(), dt = new Set(), dl = (it.dates || []).filter(d => isDate(d.date)), D = it.date && it.type === 'document' && isDate(it.date) ? [{ date: it.date, title: it.title }, ...dl] : dl;
    const b = btn(have ? 'Open' : 'Add to case', async () => { if (have) return openDoc(have); const e = await add(src, it, rel.filter((_, i) => ticks.has(i))); for (const i of dt) await dates(src, it, D[i], e); changed(); b.replaceWith(btn('Open', () => openDoc(e), 'small')); toast('Filed ' + e.title + (ticks.size ? ` and ${ticks.size} linked` : '') + (dt.size ? `, ${dt.size} dated` : '')); }, have ? 'small' : 'small primary');
    const kv = h('dl.kv', (it.fields || []).map(([k, v]) => [h('dt', k), h('dd', safe(v) ? ext(v) : v)]));
    const pivot = r => ({ domain: 1, ip: 1, email: 1, username: 1, person: 1, company: 1, btc: 1, eth: 1, place: 1 }[r.type]) && h('button.link', { title: 'Look this up', onclick: () => { inp.value = r.title.replace(/^\*\./, ''); type = r.type; pinned = true; srcs(); run(); } }, icon('search', 13));
    const sep = have && ['person', 'company'].includes(it.type) && it.url && have.url !== it.url && !(have.sources || []).some(s => s.url === it.url) ? btn('Add as separate', async () => { const e = await add(src, it, rel.filter((_, i) => ticks.has(i)), true); sep.remove(); openDoc(e); toast('Filed separately.'); }, 'small') : null;
    return h('div.hit', h('div', h('h4', it.title), h('div.row.mute', { style: { fontSize: '14px', marginTop: '2px' } }, typeTag(it.type), it.sub && h('span', { style: { overflowWrap: 'anywhere' } }, it.sub))), h('div.row', { style: { alignItems: 'flex-start', justifyContent: 'flex-end' } }, sep, b),
      h('div.body.stack', it.thumb ? h('img', { src: it.thumb, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' }) : null, it.fields?.length ? kv : null,
        rel.length ? h('div', h('span.label', { style: { marginBottom: '4px' } }, 'File with it'), h('div.row', { style: { gap: '4px 16px' } }, rel.map((r, i) => h('span.row', { style: { gap: '6px', fontSize: '14px' } }, h('label.row', { style: { gap: '6px' } }, h('input', { type: 'checkbox', onchange: e => e.target.checked ? ticks.add(i) : ticks.delete(i) }), h('span.mute', r.rel), h('span', { style: { overflowWrap: 'anywhere' } }, r.title)), pivot(r))), have && btn('File ticked', async () => { const n = ticks.size; if (!n) return toast('Tick something first.'); await add(src, it, rel.filter((_, i) => ticks.has(i))); toast(`Filed ${n}.`); }, 'small'))) : null,
        D.length ? h('div', h('span.label', { style: { marginBottom: '4px' } }, 'Add to timeline'), h('div.row', { style: { gap: '4px 16px' } }, D.map((d, i) => h('label.row', { style: { gap: '6px', fontSize: '14px' } }, h('input', { type: 'checkbox', onchange: async e => { if (have) { if (e.target.checked) { e.target.disabled = true; await dates(src, it, d, have).then(() => toast('Added to timeline.')).catch(oops); changed(); } } else e.target.checked ? dt.add(i) : dt.delete(i); } }), h('span.dot', d.date.split('-').reverse().join('.')), h('span.mute', d.title))))) : null,
        it.url ? h('small', ext(it.url, 'View at source')) : null));
  }
  function show(me, wait) {
    const order = { ok: 0, error: 1, empty: 2 }, full = me.res.filter(r => r.status === 'ok'), err = me.res.filter(r => r.status === 'error'), none = me.res.filter(r => r.status === 'empty');
    const total = full.reduce((n, r) => n + r.items.length, 0), seedT = entType(me.type), have = findEntity(seedT, me.q.replace(/^@/, ''));
    out.replaceChildren(h('div.row.between', { style: { marginBottom: '14px' } }, h('div.row', h('h2', me.q), h('span.mute', `${total} results from ${full.length} of ${me.ids.length} sources`), wait.size ? h('span.row.mute', h('span.spin'), `waiting for ${wait.size}`) : null), TYPES[seedT] && me.type !== 'coords' ? (have ? btn('Open in case', () => openDoc(have), 'small') : btn('File the search term itself', async () => { const e = await ensureEntity(seedT, me.q.replace(/^@/, '')); changed(); openDoc(e); }, 'small')) : null),
      ...full.map(r => h('section.src', h('header', h('h3', r.name), h('small', r.host), h('div', h('small', h('span.dot', stamp(r.at)))), r.raw_sha && h('small', h('a', { href: blobUrl(r.raw_sha, 'application/json'), target: '_blank' }, 'raw answer'))), h('div', r.items.map(i => hit(r, i)), r.notes.map(n => h('p.mute', { style: { paddingTop: '8px' } }, n))))),
      err.length ? h('section.src', h('header', h('h3', 'Could not answer')), h('ul', err.map(r => h('li', h('b', r.name), ': ', r.error)))) : '', none.length ? h('section.src', h('header', h('h3', 'Nothing found')), h('p.mute', none.map(r => r.name).join(', ') + '. Absence here is not proof of absence.', none.flatMap(r => r.notes).join(' '))) : '');
  }
  if (!pinned) auto(); else srcs();
  if (params.get('q')) run(); else if (last && last.case === S.case.id) { type = last.type; srcs(); show(last, new Set()); } else inp.value = '', auto();
  inp.focus();
  return { cleanup: () => { dead = true; } };
}
