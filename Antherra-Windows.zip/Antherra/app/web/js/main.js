import { h, $, S, AUTH, loadCase, icon, mark, go, get, putj, oops, guard, ext } from './core.js';
import { desk, overview, how } from './desk.js';
import { lookup } from './lookup.js';
import { entities } from './entities.js';
import { mapView } from './map.js';
import { imageryView } from './imagery.js';
import { timeline } from './timeline.js';
import { graph } from './graph.js';
import { evidence } from './evidence.js';
import { verify } from './verify.js';
import { report } from './report.js';
import { publish } from './publish.js';
import { logView, settingsView } from './settings.js';
import { guideView, help } from './guide.js';
import { enter, watch, locked, lockNow } from './lock.js';
import { closeDrawer, closePanel, refreshDrawer } from './drawer.js';

const VIEWS = { overview: ['Overview', overview], lookup: ['Look up', lookup], entities: ['Entities', entities], map: ['Map', mapView], imagery: ['Imagery', imageryView], timeline: ['Timeline', timeline], links: ['Links', graph], evidence: ['Evidence', evidence], verify: ['Verify', verify], report: ['Report', report], publish: ['Publish', publish], log: ['Log', logView], guide: ['Guide', guideView] };
let cleanup = null, refresh = null, seq = 0;

const themeBtn = () => { const dark = document.documentElement.dataset.theme === 'dark'; return h('button.sq', { 'aria-label': dark ? 'Light theme' : 'Dark theme', onclick: () => { const t = dark ? 'light' : 'dark'; document.documentElement.dataset.theme = t; try { localStorage.setItem('theme', t); } catch { } putj('/api/settings', { theme: t }).catch(() => { }); head(); dispatchEvent(new Event('theme')); } }, icon(dark ? 'sun' : 'moon')); };
const lockBtn = () => h('button.sq', { 'aria-label': 'Lock Antherra', title: 'Lock', onclick: lockNow }, icon('lock'));
const quick = () => h('form.quick', { onsubmit: e => { e.preventDefault(); const q = e.target.q.value.trim(); if (q) go(`#/case/${S.case.id}/lookup?q=${encodeURIComponent(q)}`); } }, icon('search', 18), h('input', { name: 'q', id: 'quick', placeholder: 'Look up anything', 'aria-label': 'Look up anything', title: 'Press / to jump here', autocomplete: 'off', spellcheck: 'false' }));
let cur = {};
function head() {
  const { id, view } = cur, H = $('#head'); document.body.classList.toggle('reception', !(id && S.case)); document.body.classList.toggle('home', !(id && S.case) && !cur.page);
  if (id && S.case) {
    H.replaceChildren(h('div.bar', h('a.home', { href: '#/', 'aria-label': 'All investigations' }, mark(30)), h('div.grow', h('h1', S.case.title), h('span.tag', { class: S.case.state === 'closed' ? '' : 'tag-blue' }, S.case.state || 'ongoing')), quick(), view === 'guide' ? null : h('button.sq', { 'aria-label': 'Help with this page', title: 'How to use this page', onclick: () => help(view, new URLSearchParams(location.hash.split('?')[1] || '').get('tool')) }, '?'), themeBtn(), lockBtn()),
      h('nav.tabs', { 'aria-label': 'Case' }, Object.entries(VIEWS).map(([k, [n]]) => h('a', { href: `#/case/${id}/${k}`, 'aria-current': k === view ? 'page' : null }, n))));
  } else {
    const tabs = [['', 'Investigations'], ['guide', 'Guide'], ['how', 'How we work'], ['settings', 'Settings']];
    H.replaceChildren(h('div.front', h('a.home', { href: '#/' }, mark(34), h('span', h('b', 'Antherra'), h('small', 'The investigations desk of The Student Statesman'))), h('nav', { 'aria-label': 'Main' }, tabs.map(([k, n]) => h('a', { href: '#/' + k, 'aria-current': k === (cur.page || '') ? 'page' : null }, n))), h('div.row', themeBtn(), lockBtn())));
  }
}

async function route() {
  const my = ++seq, [path, qs] = location.hash.replace(/^#\//, '').split('?'), p = path.split('/'), q = new URLSearchParams(qs || '');
  if (cleanup) { try { cleanup(); } catch (e) { console.error(e); } } cleanup = refresh = null;
  const V = $('#view'); closePanel();
  try {
    if (p[0] === 'case') {
      const view = VIEWS[p[2]] ? p[2] : 'overview';
      if (cur.id !== p[1]) closeDrawer();
      if (S.case?.id !== p[1]) { S.case = null; await loadCase(p[1]); }
      if (my !== seq) return;
      if (!S.case) return go('#/');
      cur = { id: p[1], view }; document.title = `${S.case.title} · Antherra`; head();
      const box = h('div', { style: { height: '100%' } }); V.replaceChildren(box); V.scrollTop = 0;
      const r = VIEWS[view][1](box, q) || {}; cleanup = r.cleanup; refresh = r.refresh;
    } else {
      closeDrawer(); S.case = null; S.docs = new Map(); cur = { page: p[0] || '' }; document.title = 'Antherra'; head();
      const box = h('div'); V.replaceChildren(box); V.scrollTop = 0; scrollTo(0, 0);
      const r = ({ settings: settingsView, how, guide: guideView }[p[0]] || desk)(box, q) || {}; cleanup = r.cleanup; refresh = r.refresh;
    }
  } catch (e) { oops(e); }
}
S.subs.add(() => { if (cur.id && S.case) { const a = document.activeElement?.id; if (a !== 'quick') head(); } if (refresh) refresh(); refreshDrawer(); });
addEventListener('hashchange', () => { if (S.settings) route(); });
addEventListener('keydown', e => {
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName) || document.querySelector('dialog[open]')) return;
  if (e.key === '/') { const i = $('#quick'); if (i) { e.preventDefault(); i.focus(); } }
  if (e.key === 'Escape') closeDrawer();
});
addEventListener('unhandledrejection', e => oops(e.reason || new Error('Something failed')));
async function start() {
  try { S.settings = await get('/api/settings'); } catch (e) { return AUTH.t ? oops(e) : enter(start); }
  if (S.settings.theme) document.documentElement.dataset.theme = S.settings.theme;
  document.body.className = ''; AUTH.locked = locked; watch(); route();
}
if (AUTH.t) { AUTH.locked = locked; start(); } else enter(start);
