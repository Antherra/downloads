// Case archives: protected by their own passphrase, so a case can be handed over without handing over anything else.
import { h, AUTH, post, api, dialog, pickFile, toast } from './core.js';
const input = auto => h('input', { type: 'password', autocomplete: auto, spellcheck: 'false' });
export async function exportCase(c) {
  const a = input('new-password'), b = input('new-password'), plain = h('input', { type: 'checkbox' }), err = h('p.err', { hidden: true });
  const body = h('div.stack', h('p', 'The archive holds everything in this case. Choose a passphrase for it, different from your own, and give it to the other person separately from the file.'), h('label.field', h('span', 'Archive passphrase'), a), h('label.field', h('span', 'Type it again'), b),
    h('label.row', { style: { flexWrap: 'nowrap' } }, plain, h('span', 'Export without protection. Anyone who gets the file can read it.')), err);
  const ok = await dialog('Export case', body, [{ label: 'Cancel' }, { label: 'Export', primary: true, fn: () => { const m = plain.checked ? '' : a.value !== b.value ? 'The two passphrases do not match.' : a.value.length < 12 ? 'Use at least 12 characters.' : ''; err.textContent = m; err.hidden = !m; return !m; } }]);
  if (!ok) return;
  const r = await fetch('/api/export/' + c.id, { method: 'POST', headers: { 'X-Antherra-Token': AUTH.t, 'Content-Type': 'application/json' }, body: JSON.stringify(plain.checked ? {} : { passphrase: a.value }) });
  a.value = b.value = '';
  if (r.status === 423) return AUTH.locked();
  if (!r.ok) throw new Error((await r.json()).error);
  const l = h('a', { href: URL.createObjectURL(await r.blob()), download: r.headers.get('X-Filename') }); document.body.append(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(l.href), 60000);
}
export async function openArchive() {
  const [f] = await pickFile('.antherra,.zip'); if (!f) return null;
  try { return (await post('/api/import', f)).id; } catch (e) { if (e.need !== 'passphrase') throw e; }
  const a = input('off'), err = h('p.err', { hidden: true }); let id = null;
  await dialog('Open case archive', h('div.stack', h('p', 'This archive is protected. Enter the passphrase you were given with it.'), h('label.field', h('span', 'Archive passphrase'), a), err), [{ label: 'Cancel' }, { label: 'Open', primary: true, fn: async () => {
    try { id = (await api('POST', '/api/import', f, { 'X-Passphrase': encodeURIComponent(a.value) })).id; toast('Opened.'); } catch (e) { err.textContent = e.message; err.hidden = false; return false; }
  } }]);
  return id;
}
