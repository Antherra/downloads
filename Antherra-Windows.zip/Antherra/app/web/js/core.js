// Shared helpers: DOM building, API, case store, dialogs, dates, types.
export const AUTH = { t: '', v: '', locked: () => { } }; // session keys, given only after the passphrase (lock.js)
export const $ = (s, r = document) => r.querySelector(s);

// h() only ever sets text and attributes, so data from the web cannot become markup.
export function h(tag, props, ...kids) {
  const [name, ...cls] = tag.split('.');
  const e = document.createElement(name || 'div');
  if (cls.length) e.className = cls.join(' ');
  if (props != null && props !== false && (props instanceof Node || Array.isArray(props) || typeof props !== 'object')) { kids.unshift(props); props = null; }
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'class') e.className += ' ' + v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'selected') e[k] = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  const add = k => { if (k == null || k === false) return; if (Array.isArray(k)) k.forEach(add); else e.append(k instanceof Node ? k : String(k)); };
  kids.forEach(add);
  return e;
}
// Same forgiving rules as h(): nested lists are flattened, null/false are skipped.
const nativeReplace = Element.prototype.replaceChildren;
Element.prototype.replaceChildren = function (...k) { return nativeReplace.apply(this, k.flat(Infinity).filter(x => x != null && x !== false && x !== '')); };
export const safe = u => /^https?:\/\//i.test(u || '') ? u : null;
export const ext = (url, label, cls) => safe(url) ? h('a', { href: url, target: '_blank', rel: 'noopener noreferrer', class: cls }, label || url) : h('span', label || url || '');
export function svg(tag, props, ...kids) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(props || {})) { if (v == null) continue; if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); }
  kids.flat().forEach(k => k != null && e.append(k));
  return e;
}
const I = { // 20x20 stroke icons
  search: 'M9 3a6 6 0 1 0 0 12A6 6 0 0 0 9 3m4.5 10.5L17 17', sun: 'M10 6.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7M10 2v2m0 12v2M2 10h2m12 0h2M4.3 4.3l1.5 1.5m8.4 8.4 1.5 1.5m0-11.4-1.5 1.5m-8.4 8.4-1.5 1.5', moon: 'M16 12.5A6.5 6.5 0 0 1 7.500 4 6.500 6.500 0 1 0 16 12.500',
  x: 'M5 5l10 10M15 5 5 15', plus: 'M10 4v12M4 10h12', person: 'M10 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6M4 17c0-3.500 2.700-5 6-5s6 1.500 6 5', company: 'M4 17V5l7-2v14m0-9h5v9M2.500 17h15M7 7v0m0 4v0m0 3v0',
  place: 'M10 17.500s5.500-5 5.500-9a5.500 5.500 0 1 0-11 0c0 4 5.500 9 5.500 9M10 6.500a2 2 0 1 0 0 4 2 2 0 0 0 0-4', domain: 'M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14M3 10h14M10 3c2.500 2.500 2.500 11.500 0 14-2.500-2.500-2.500-11.500 0-14', ip: 'M3 4h14v5H3zM3 11h14v5H3zM6 6.500h0M6 13.500h0',
  email: 'M3 5h14v10H3zM3 5.500l7 5.500 7-5.500', username: 'M10 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6m3 0v4.500c0 2 3.500 2 3.500-1.500a6.500 6.500 0 1 0-2.500 5', phone: 'M5 3h3l1.500 4-2 1.500a9 9 0 0 0 4 4l1.500-2 4 1.500v3c0 1-1 2-2 2C9 17 3 11 3 5c0-1 1-2 2-2',
  btc: 'M7 4h4.500a2.700 2.700 0 0 1 0 5.500H7zm0 5.500h5.500a3 3 0 0 1 0 6H7zM9 2.500V4m0 11.500V17', eth: 'M10 2l5 8-5 3-5-3zM5 12l5 6 5-6', vessel: 'M3 11h14l-2 5H5zM6 11V6h8v5M10 6V3', aircraft: 'M10 2v16M10 8l7.500 4M10 8l-7.500 4M10 15l3 2m-3-2-3 2', document: 'M5 2.500h7l3 3v12H5zM12 2.500v3h3M7.500 9h5m-5 3h5', url: 'M8.500 11.500l3-3M9 6l2-2a3.500 3.500 0 0 1 5 5l-2 2M11 14l-2 2a3.500 3.500 0 0 1-5-5l2-2',
  tracker: 'M10 4a6 6 0 1 0 0 12 6 6 0 0 0 0-12m0 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4M10 1v3m0 12v3M1 10h3m12 0h3', text: 'M4 5h12M4 10h12M4 15h7', event: 'M3 5h14v12H3zM3 9h14M7 3v4m6-4v4', vehicle: 'M3 13v-3l2-4h10l2 4v3zM5.500 13a1.500 1.500 0 1 0 0 3 1.500 1.500 0 0 0 0-3m9 0a1.500 1.500 0 1 0 0 3 1.500 1.500 0 0 0 0-3', quake: 'M2 10h4l2-5 3 10 2-5h5', hazard: 'M10 3l8 14H2zM10 8v4m0 2.500v0', check: 'M4 10.500l4 4 8-9', play: 'M6 4l10 6-10 6z', pause: 'M7 4v12m6-12v12', lock: 'M5 9h10v8H5zM7 9V6.500a3 3 0 0 1 6 0V9M10 12v2',
};
export const icon = (n, size = 18) => svg('svg', { viewBox: '0 0 20 20', width: size, height: size, 'aria-hidden': 'true', class: 'icon' }, svg('path', { d: I[n] || I.text, fill: 'none', stroke: 'currentColor', 'stroke-width': 1.5, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
export const iconPath = n => I[n] || I.text;
export const mark = (w = 40) => svg('svg', { viewBox: '0 0 120 108', width: w, height: w * .9, 'aria-hidden': 'true', class: 'mark' }, svg('path', { fill: 'currentColor', d: 'M60 0 114 26v6H6v-6zM17 37h86v8H17zM22 49h10l2 40H20zM45 49h10l1 40H43zM66 49h10l1 40H64zM88 49h10l2 40H86zM14 92h92v6h6v5h8v5H0v-5h8v-5h6z' }));

// ---- API
export async function api(method, path, body, headers) {
  const raw = body instanceof Blob || body instanceof ArrayBuffer;
  const r = await fetch(path, { method, headers: { 'X-Antherra-Token': AUTH.t, ...(raw ? {} : body ? { 'Content-Type': 'application/json' } : {}), ...headers }, body: raw ? body : body ? JSON.stringify(body) : undefined })
    .catch(() => { throw new Error('Antherra is not running any more. Start it again and reload.'); });
  const j = await r.json().catch(() => ({ error: 'unreadable answer' }));
  if (r.status === 423) AUTH.locked();
  if (!r.ok) throw Object.assign(new Error(j.error || 'HTTP ' + r.status), { need: j.need });
  return j;
}
export const get = p => api('GET', p), post = (p, b, hd) => api('POST', p, b, hd), putj = (p, b) => api('PUT', p, b);
export const blobUrl = (sha, type, dl) => `/blob/${sha}?t=${encodeURIComponent(AUTH.v)}${type ? '&type=' + encodeURIComponent(type) : ''}${dl ? '&dl=' + encodeURIComponent(dl) : ''}`;

// ---- types and statuses
export const TYPES = {
  person: ['Person', 'people'], company: ['Organisation', 'orgs'], place: ['Place', 'places'], vessel: ['Vessel', 'transport'], aircraft: ['Aircraft', 'transport'], vehicle: ['Vehicle', 'transport'], domain: ['Domain', 'infra'], ip: ['IP address', 'infra'], url: ['Web page', 'infra'],
  email: ['Email', 'people'], username: ['Username', 'people'], phone: ['Phone', 'people'], btc: ['Bitcoin address', 'money'], eth: ['Ethereum address', 'money'], document: ['Document', 'docs'], tracker: ['Tracking ID', 'infra'], text: ['Topic', 'docs'],
};
export const tname = t => (TYPES[t] || [t || 'Item'])[0];
export const GROUP = { people: '#ffb48c', orgs: '#a8dcff', places: '#c9e7b3', transport: '#f0d98c', infra: '#c9c5e8', money: '#8fe0cf', docs: '#d8d6dd' };
export const GROUPN = { people: 'People and accounts', orgs: 'Organisations', places: 'Places', transport: 'Transport', infra: 'Infrastructure', money: 'Money', docs: 'Documents and topics' };
export const tcol = t => GROUP[(TYPES[t] || ['', 'docs'])[1]];
export const STATUS = ['unverified', 'verified', 'contradicted', 'misattributed', 'updated'];
export const tag = s => h('span.tag', { class: 'tag-' + (s || 'unverified') }, s || 'unverified');
export const REL = { A: 'completely reliable', B: 'usually reliable', C: 'fairly reliable', D: 'not usually reliable', E: 'unreliable', F: 'reliability unknown' };
export const CRED = { 1: 'confirmed', 2: 'probably true', 3: 'possibly true', 4: 'doubtful', 5: 'improbable', 6: 'cannot be judged' };

// ---- dates: partial ISO strings (2024, 2024-03, 2024-03-09, 2024-03-09T14:05)
export const fmt = d => { if (!d) return ''; const m = /^(-?\d{1,6})(?:-(\d\d))?(?:-(\d\d))?(?:T(\d\d:\d\d))?/.exec(d); if (!m) return d; return [m[3], m[2], m[1]].filter(Boolean).join('.') + (m[4] ? ' ' + m[4] : ''); };
export const isDate = s => { const m = /^(\d{4})(?:-(0[1-9]|1[0-2])(?:-(0[1-9]|[12]\d|3[01])(?:T([01]\d|2[0-3]):[0-5]\d)?)?)?$/.exec(s || ''); if (!m) return false; return !m[3] || +m[3] <= new Date(Date.UTC(+m[1], +m[2], 0)).getUTCDate(); };
export const t0 = d => { const m = /^(\d{4})(?:-(\d\d))?(?:-(\d\d))?(?:T(\d\d):(\d\d))?/.exec(d || ''); if (!m) return NaN; const x = new Date(0); x.setUTCFullYear(+m[1], (m[2] || 1) - 1, +(m[3] || 1)); x.setUTCHours(+(m[4] || 0), +(m[5] || 0)); return +x; };
export const t1 = d => { const m = /^(\d{4})(?:-(\d\d))?(?:-(\d\d))?(T)?/.exec(d || ''); if (!m) return NaN; if (m[4]) return t0(d); if (m[3]) return t0(d) + 864e5; const x = new Date(t0(d)); if (m[2]) x.setUTCMonth(x.getUTCMonth() + 1); else x.setUTCFullYear(x.getUTCFullYear() + 1); return +x; };
export const today = () => new Date().toISOString().slice(0, 10);
export const stamp = s => s ? fmt(s.slice(0, 16)) + ' UTC' : '';

// ---- case store
export const S = { case: null, docs: new Map(), settings: null, subs: new Set() };
export const all = k => [...S.docs.values()].filter(d => d.kind === k);
export const byId = id => S.docs.get(id);
export const changed = () => S.subs.forEach(f => f());
export async function loadCase(id) {
  const docs = await get('/api/case/' + id);
  S.docs = new Map(docs.map(d => [d.id, d])); S.case = S.docs.get(id) || null;
  return S.case;
}
const keep = d => { S.docs.set(d.id, d); if (d.kind === 'case') S.case = d; return d; };
export async function save(d, quiet) { const r = keep(await putj('/api/doc', { ...d, case_id: d.case_id || S.case?.id })); if (!quiet) changed(); return r; }
export async function saveAll(list) { if (!list.length) return []; const r = (await post('/api/batch', list.map(d => ({ ...d, case_id: S.case.id })))).map(keep); changed(); return r; }
export async function remove(d) {
  const links = d.kind === 'entity' ? all('link').filter(l => l.a === d.id || l.b === d.id) : [];
  await api('DELETE', '/api/doc/' + d.id); [d, ...links].forEach(x => S.docs.delete(x.id)); changed();
  toast('Removed ' + (d.title || d.kind), 'Undo', async () => { for (const x of [d, ...links]) keep(await post('/api/restore/' + x.id)); changed(); });
}
export const norm = s => (s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const BY_URL = ['document', 'url']; // many filings and pages share a title, so these match on address too
export const findEntity = (type, title, url) => all('entity').find(e => e.type === type && (norm(e.title) === norm(title) || (e.aliases || []).some(a => norm(a) === norm(title))) && !(BY_URL.includes(type) && url && e.url && e.url !== url));
export async function ensureEntity(type, title, extra = {}) {
  const old = extra.separate ? null : findEntity(type, title, extra.url); delete extra.separate;
  if (!old) return save({ kind: 'entity', type, title, status: 'unverified', fields: [], sources: [], ...extra }, true);
  const f = [...(old.fields || [])];
  (extra.fields || []).forEach(([k, v]) => { if (!f.some(x => x[0] === k && x[1] === v)) f.push([k, v]); });
  const s = [...(old.sources || [])];
  (extra.sources || []).forEach(x => { if (!s.some(y => y.name === x.name && y.url === x.url)) s.push(x); });
  const up = { ...old, fields: f, sources: s };
  if (up.lat == null && extra.lat != null) { up.lat = extra.lat; up.lon = extra.lon; }
  if (!up.url && extra.url) up.url = extra.url;
  return save(up, true);
}
export async function ensureLink(a, b, rel, sources) {
  if (a === b) return null;
  return all('link').find(l => ((l.a === a && l.b === b) || (l.a === b && l.b === a)) && l.rel === rel) || save({ kind: 'link', a, b, rel, status: 'unverified', sources: sources || [] }, true);
}

// ---- feedback
export function toast(msg, act, fn, bad) {
  const t = h('div.toast', { class: bad ? 'bad' : '' }, h('span', msg), act && h('button.link', { onclick: () => { t.remove(); fn(); } }, act));
  $('#toasts').append(t); setTimeout(() => t.remove(), act ? 8000 : bad ? 7000 : 3500);
}
export const oops = e => { console.error(e); toast(e.message || String(e), null, null, true); };
export const guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { oops(e); } };

export function dialog(title, body, actions, wide) {
  return new Promise(res => {
    const d = h('dialog', { class: wide ? 'wide' : '' }, h('form', { method: 'dialog', onsubmit: async e => { e.preventDefault(); const b = actions.find(a => a.primary); if (b) { const v = b.fn ? await b.fn() : true; if (v !== false) { d.close(); res(v); } } } },
      h('h2', title), body, h('div.row.end', actions.map(a => h('button', { type: a.primary ? 'submit' : 'button', class: a.primary ? 'primary' + (a.danger ? ' danger' : '') : 'quiet', onclick: a.primary ? null : () => { d.close(); res(null); } }, a.label)))));
    d.addEventListener('cancel', () => res(null)); d.addEventListener('close', () => setTimeout(() => d.remove(), 0));
    document.body.append(d); d.showModal(); (d.querySelector('[autofocus]') || d.querySelector('input,textarea,select'))?.focus();
  });
}
export const confirmBox = (title, text, label, danger) => dialog(title, h('p', text), [{ label: 'Cancel' }, { label, primary: true, danger }]);
export function field(f, val) {
  const id = 'f' + Math.random().toString(36).slice(2, 8); let el;
  if (f.type === 'area') el = h('textarea', { id, rows: f.rows || 4, placeholder: f.ph, value: val || '' });
  else if (f.type === 'select') el = h('select', { id }, f.options.map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return h('option', { value: v, selected: v === val }, l); }));
  else el = h('input', { id, type: f.type || 'text', placeholder: f.ph, value: val ?? '', list: f.list, step: f.step, autocomplete: 'off', spellcheck: f.spell ? 'true' : 'false' });
  return { el, node: h('label.field', { for: id }, h('span', f.label), el, f.hint && h('small', f.hint)) };
}
export function form(title, fields, vals = {}, label = 'Save', check, exact) {
  const fs = fields.map(f => ({ ...f, ...field(f, vals[f.k]) })), err = h('p.err', { hidden: true });
  return dialog(title, h('div', h('div.grid2', fs.map(f => { if (f.full) f.node.classList.add('full'); return f.node; })), err), [{ label: 'Cancel' }, { label, primary: true, fn: () => {
    const v = {}; fs.forEach(f => v[f.k] = exact ? f.el.value : f.el.value.trim());
    const bad = fs.find(f => f.req && !v[f.k]); const m = bad ? bad.label + ' is needed.' : check && check(v);
    if (m) { err.textContent = m; err.hidden = false; return false; }
    return v;
  } }]);
}
export const btn = (label, fn, cls, ic) => h('button', { type: 'button', class: cls || '', onclick: guard(fn) }, ic && icon(ic, 16), label);
export const empty = (title, text, ...acts) => h('div.empty', h('h3', title), h('p', text), acts.length ? h('div.row', acts) : null);
export function download(name, text, type = 'text/plain') {
  const a = h('a', { href: URL.createObjectURL(new Blob([text], { type })), download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 60000);
}
export const slug = s => norm(s).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'case';
export const coord = (a, b) => `${Math.abs(a).toFixed(4)}° ${a < 0 ? 'S' : 'N'}, ${Math.abs(b).toFixed(4)}° ${b < 0 ? 'W' : 'E'}`;
export const go = p => { location.hash = p; };
export const caseUrl = v => `#/case/${S.case.id}/${v}`;
export async function pickFile(accept, multiple) { return new Promise(r => { const i = h('input', { type: 'file', accept, multiple }); i.onchange = () => r([...i.files]); i.click(); }); }
export async function addFiles(files) {
  const out = [];
  for (const f of files) { const d = keep(await post(`/api/upload?case=${S.case.id}&name=${encodeURIComponent(f.name)}`, f, { 'Content-Type': f.type || 'application/octet-stream' })); out.push(d); }
  changed(); return out;
}

// ---- what kind of thing is this?
export function detect(q) {
  q = q.trim();
  if (!q) return 'text';
  if (parseCoord(q)) return 'coords';
  if (/^https?:\/\//i.test(q)) return 'url';
  if (/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(q)) return 'email';
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(q) && q.split('.').every(x => +x < 256)) return 'ip';
  if (/^[0-9a-f:]+:[0-9a-f:]+$/i.test(q) && q.split(':').length > 2) return 'ip';
  if (/^0x[0-9a-f]{40}$/i.test(q)) return 'eth';
  if (/^(bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(q)) return 'btc';
  if (/^[A-Z0-9]{18}\d\d$/.test(q)) return 'lei';
  if (/^imo\s?\d{7}$/i.test(q)) return 'vessel';
  if (/^\+[\d\s().-]{7,20}$|^00\d[\d\s.-]{7,18}$/.test(q)) return 'phone';
  if (/^\d{3}\s?\d{3}\s?\d{3}$/.test(q)) return 'siren';
  if (/^@[\w.-]+$/.test(q)) return 'username';
  if (/^([a-z0-9-]+\.)+[a-z]{2,24}$/i.test(q)) return 'domain';
  if (/^([A-Z]{1,2}-[A-Z0-9]{3,5}|N\d{1,5}[A-Z]{0,2})$/.test(q)) return 'aircraft';
  if (/\b(ltd|limited|plc|inc|llc|gmbh|sarl|sas|s\.?a\.?|corp|company|group|holdings?|bank|sci)\b\.?$/i.test(q)) return 'company';
  return 'text';
}
export function parseCoord(s) {
  s = (s || '').trim(); let m, la, lo;
  if ((m = /@(-?\d+\.\d+),(-?\d+\.\d+)/.exec(s)) || (m = /[?&](?:q|ll|query)=(-?\d+\.\d+),(-?\d+\.\d+)/.exec(s)) || (m = /^\(?\s*(-?\d{1,2}(?:\.\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:\.\d+)?)\s*\)?$/.exec(s))) { la = +m[1]; lo = +m[2]; if (!/\./.test(m[0]) && !/,/.test(m[0])) return null; }
  else if ((m = /^(\d{1,2}(?:\.\d+)?)\s*°?\s*(?:(\d{1,2}(?:\.\d+)?)\s*['′])?\s*(?:(\d{1,2}(?:\.\d+)?)\s*["″])?\s*([NS])[,\s]*(\d{1,3}(?:\.\d+)?)\s*°?\s*(?:(\d{1,2}(?:\.\d+)?)\s*['′])?\s*(?:(\d{1,2}(?:\.\d+)?)\s*["″])?\s*([EW])$/i.exec(s))) {
    la = (+m[1] + (+m[2] || 0) / 60 + (+m[3] || 0) / 3600) * (/s/i.test(m[4]) ? -1 : 1); lo = (+m[5] + (+m[6] || 0) / 60 + (+m[7] || 0) / 3600) * (/w/i.test(m[8]) ? -1 : 1);
  } else return null;
  return Math.abs(la) <= 90 && Math.abs(lo) <= 180 ? [la, lo] : null;
}
export const QT = { text: 'Any text', person: 'Person', company: 'Organisation', place: 'Place', domain: 'Domain', url: 'Web address', ip: 'IP address', email: 'Email', username: 'Username', phone: 'Phone', coords: 'Coordinates', vessel: 'Vessel (name or IMO)', aircraft: 'Aircraft', btc: 'Bitcoin address', eth: 'Ethereum address', lei: 'LEI code', siren: 'SIREN number' };
