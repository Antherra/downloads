// The lock: choosing a passphrase, unlocking, and locking again.
import { h, $, mark, AUTH, S, toast, dialog, download } from './core.js';

const call = async (path, body) => {
  const r = await fetch('/open/' + path, { method: body ? 'POST' : 'GET', headers: { 'X-Antherra': '1', ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body && JSON.stringify(body) }).catch(() => { throw new Error('Antherra is not running any more. Open it again.'); });
  const j = await r.json().catch(() => ({ error: 'unreadable answer' }));
  if (!r.ok) throw new Error(j.error || 'HTTP ' + r.status); return j;
};
const keepSession = r => { AUTH.t = r.token; AUTH.v = r.view; try { sessionStorage.setItem('session', JSON.stringify([r.token, r.view])); } catch { } };
export function drop() { AUTH.t = AUTH.v = ''; try { sessionStorage.clear(); } catch { } }

// The address the window opens with carries a one-time code that allows the first passphrase to be set. It leaves the address bar at once.
let code = '';
{ const m = /^#k=([\w-]+)$/.exec(location.hash); try { if (m) { sessionStorage.setItem('code', m[1]); history.replaceState(null, '', '/'); } code = sessionStorage.getItem('code') || ''; [AUTH.t, AUTH.v] = JSON.parse(sessionStorage.getItem('session') || '["",""]'); } catch { } }

const pw = (label, auto) => { const i = h('input', { type: 'password', autocomplete: auto, spellcheck: 'false', autocapitalize: 'off', maxlength: 1000 }); return [i, h('label.field', h('span', label), i)]; };
export function showCode(c, box) {
  const ok = h('input', { type: 'checkbox' });
  return h('div.stack', h('p', 'Write this recovery code down and keep it away from this computer. It is the only way in if the passphrase is forgotten, and it opens everything by itself. It is shown once.'),
    h('code.recovery', c), h('label.row', { style: { flexWrap: 'nowrap' } }, ok, h('span', 'I have written it down.')), box && box(ok));
}
export async function codeDialog(c) {
  let ok; const body = showCode(c, x => { ok = x; return null; });
  while (!await dialog('New recovery code', body, [{ label: 'Done', primary: true, fn: () => { if (!ok.checked) { toast('Write it down, then tick the box.'); return false; } } }]));
}
function gate(...kids) {
  document.title = 'Antherra'; document.body.className = 'locked'; $('#head').replaceChildren(); $('#drawer').hidden = true; $('#drawer').replaceChildren(); $('#toasts').replaceChildren();
  document.querySelectorAll('dialog').forEach(d => d.remove());
  $('#view').replaceChildren(h('div.gate', h('div.gate-in', mark(44), ...kids)));
  $('#view').querySelector('input')?.focus();
}
const formOf = (kids, label, fn) => {
  const err = h('p.err', { hidden: true, role: 'alert' }), go = h('button.primary', { type: 'submit' }, label);
  return h('form.stack', { onsubmit: async e => { e.preventDefault(); err.hidden = true; go.disabled = true; try { await fn(); } catch (x) { err.textContent = x.message; err.hidden = false; go.disabled = false; } } }, kids, err, h('div.row', go));
};
const check = (a, b) => { if (a.value !== b.value) throw new Error('The two passphrases do not match.'); };

function setup(st, done) {
  if (!code) return gate(h('h1', 'Set a passphrase'), h('p', 'Close Antherra and open it again. The passphrase can only be set in the window Antherra opens itself.'));
  const [a, fa] = pw('Passphrase', 'new-password'), [b, fb] = pw('Type it again', 'new-password');
  gate(h('h1', 'Set a passphrase'), h('p', `Everything you file is encrypted with it. Use at least ${st.min} characters: four or five random words work well. Antherra cannot look it up or reset it.`),
    st.legacy && h('p', h('b', 'Your existing cases, evidence and keys will be encrypted. '), 'Everything is checked first, then the unencrypted copies are removed. Copies made elsewhere, such as Time Machine, stay as they are.'),
    formOf([fa, fb], 'Encrypt and continue', async () => {
      check(a, b); const r = await call('setup', { code, passphrase: a.value }); keepSession(r); try { sessionStorage.removeItem('code'); } catch { } a.value = b.value = '';
      recovery(r.recovery, done);
    }));
}
function recovery(c, done) { gate(h('h1', 'Your recovery code'), showCode(c, ok => h('div.row', h('button.primary', { type: 'button', onclick: () => ok.checked ? done() : toast('Write it down, then tick the box.') }, 'Continue')))); }
function unlock(done, why) {
  const [a, fa] = pw('Passphrase', 'current-password');
  gate(h('h1', 'Antherra is locked'), why && h('p', why), formOf([fa], 'Unlock', async () => { try { keepSession(await call('unlock', { passphrase: a.value })); } finally { a.value = ''; a.focus(); } done(); }),
    h('button.link.small', { type: 'button', onclick: () => forgot(done) }, 'Use the recovery code'));
}
function forgot(done) {
  const c = h('input', { type: 'text', autocomplete: 'off', spellcheck: 'false', maxlength: 60 }), [a, fa] = pw('New passphrase', 'new-password'), [b, fb] = pw('Type it again', 'new-password');
  gate(h('h1', 'Use the recovery code'), h('p', 'This sets a new passphrase and gives you a new code. The old ones stop working.'), formOf([h('label.field', h('span', 'Recovery code'), c), fa, fb], 'Set new passphrase', async () => {
    check(a, b); const r = await call('recover', { recovery: c.value, passphrase: a.value }); keepSession(r); a.value = b.value = c.value = ''; recovery(r.recovery, done);
  }), h('button.link.small', { type: 'button', onclick: () => unlock(done) }, 'Back'));
}
export async function enter(done, why) {
  try { const st = await call('state'); st.set ? unlock(done, why) : setup(st, done); } catch (e) { gate(h('h1', 'Antherra cannot start'), h('p', e.message)); }
}

// ---- locking again
let timer = null, warned = false, last = Date.now(), gone = false;
export async function lockNow() {
  if (gone) return; gone = true;
  try { await fetch('/api/lock', { method: 'POST', headers: { 'X-Antherra-Token': AUTH.t }, keepalive: true }); } catch { }
  drop(); location.replace('/'); setTimeout(() => location.reload(), 30); // a fresh page, so nothing readable is left in this one
}
export function watch() {
  const touch = () => { last = Date.now(); warned = false; };
  ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart'].forEach(e => addEventListener(e, touch, { passive: true, capture: true }));
  clearInterval(timer); last = Date.now();
  let beat = 0;
  timer = setInterval(() => {
    const left = (S.settings?.lock_minutes || 10) * 60000 - (Date.now() - last);
    if (left <= 0) return lockNow();
    if (left < 60000 && !warned) { warned = true; toast('Antherra locks in a minute. Unsaved typing will be lost.', 'Stay open', touch); }
    if (Date.now() - last < 60000 && Date.now() - beat > 45000) { beat = Date.now(); fetch('/api/recent', { headers: { 'X-Antherra-Token': AUTH.t } }).then(r => { if (r.status === 423) locked(); }).catch(() => { }); } // reading without clicking still counts as being here
  }, 2000);
}
export function locked() { if (gone || !AUTH.t) return; gone = true; drop(); location.replace('/'); setTimeout(() => location.reload(), 30); }
window.antherraLock = lockNow; // the Mac app calls this when the screen locks or the Mac sleeps
